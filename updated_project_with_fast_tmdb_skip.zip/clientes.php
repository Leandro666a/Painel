<?php
session_start();
require_once("menu.php");
?>
<h4 class="align-items-center d-flex justify-content-between mb-4 text-muted text-uppercase">
  LISTAR Clientes
  <div class="d-flex gap-2">
    <!-- Botão para adicionar novo cliente -->
    <button type="button" class="btn btn-outline-success fa-plus fas" onclick='modal_master("api/clientes.php", "adicionar_clientes", "add")'></button>
    <!-- Botão global para migrar clientes de outro servidor -->
    <button type="button" id="btnMigrarClientes" class="btn btn-outline-secondary">
      <i class="fa fa-exchange-alt"></i> Migrar
    </button>
  </div>

</h4>
<table id="data_table" class="display overflow-auto table" style="width: 100%;">
  <thead class="table-dark">
    <tr><!--<th></th> descomentar para usar childs -->
      <th style="min-width: 75px;">#</th>
      <th>Nome</th>
      <th>Usuario</th>
      <th>Indicados</th>
      <th>Status</th>
      <th style="font-size: small;">Vencimento</th>
      <th style="min-width: 191px;">Ações</th>
    </tr>
  </thead>
</table>


<script src="//cdn.datatables.net/2.0.7/js/dataTables.js"></script>
<script src="./js/sweetalert2.js"></script>
<script src="./js/datatableclientes.js?sfd"></script>
<script src="./js/custom.js"></script>

</div>
</main>

<!-- Modal master -->
<div class="modal fade" id="modal_master" tabindex="-1" aria-labelledby="modal_master" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="d-block modal-header" id="modal_master-header">
        <h5 class="float-start modal-title" id="modal_master-titulo"></h5>
        <button type="button" class="fa btn text-white fa-close fs-6 float-end" data-bs-dismiss="modal" aria-label="Close"></button>
        </button>
      </div>
      <form id="modal_master_form" onsubmit="event.preventDefault();" autocomplete="off">
        <div id="modal_master-body" class="modal-body overflow-auto" style="max-height: 421px;"></div>
        <div id="modal_master-footer" class="modal-footer"></div>
      </form>
    </div>
  </div>
</div>
<!-- Modal master Fim-->

<!-- Modal de Ações do Cliente -->
<div class="modal fade" id="clienteModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Ações do Cliente</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="d-flex flex-wrap gap-2 justify-content-start">
          <!-- Ações disponíveis para o cliente -->
          <button id="btnModoAleatorio" type="button" class="btn btn-outline-secondary rounded">
            <i class="fa fa-random"></i> Modo Aleatório
          </button>
          <button id="btnTela" type="button" class="btn btn-outline-secondary rounded">
            <i class="fa fa-tv"></i> Gerenciar Telas
          </button>
          <button id="btnLinks" type="button" class="btn btn-outline-secondary rounded">
            <i class="fa fa-link"></i> Copiar Links
          </button>
          <button id="btnEditarData" type="button" class="btn btn-outline-secondary rounded">
            <i class="fa fa-calendar-alt"></i> Editar Data
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Fim Modal de Ações do Cliente -->

<script>
function copyText(elementId) {
  var preElement = document.getElementById(elementId);
  var range = document.createRange();
  range.selectNodeContents(preElement);
  var selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  document.execCommand('copy');
  selection.removeAllRanges();
  //alert('Texto copiado para a área de transferência!');
  SweetAlert3('Texto copiado para a área de transferência!', 'success');
}
</script>

</body>
</html>
