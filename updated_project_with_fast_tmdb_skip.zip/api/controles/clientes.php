<?php
/**
 * Exibe um modal de detalhes do cliente com uma grade de ações.
 * Inspirado no layout do painel sem xtream, este método apresenta
 * informações básicas do cliente e permite realizar operações
 * adicionais como editar, renovar, alterar conexões, ativar modo
 * aleatório, definir múltiplos servidores e bloquear/desbloquear.
 *
 * @param int $id ID do cliente
 * @return array Estrutura de resposta contendo cabeçalho, corpo e rodapé do modal
 */
function info_cliente($id)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.*
            FROM clientes c
            LEFT JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Extrai todas as colunas para variáveis
        extract($row);

        // Determina estado de bloqueio e textos/ícones para o botão
        $bloqueadoFlag  = (int)$bloqueado === 1;
        $novoStatus     = $bloqueadoFlag ? 0 : 1;
        $textoBloqueio  = $bloqueadoFlag ? 'Desbloquear' : 'Bloquear';
        $iconeBloqueio  = $bloqueadoFlag ? 'fa-toggle-off' : 'fa-toggle-on';

        // Determina estado do modo aleatório
        $modoAleatorioFlag = (int)$modo_aleatorio === 1;
        $novoAleatorio     = $modoAleatorioFlag ? 0 : 1;
        $textoAleatorio    = $modoAleatorioFlag ? 'Desativar Aleatório' : 'Ativar Aleatório';
        $iconeAleatorio    = $modoAleatorioFlag ? 'fa-random' : 'fa-random';

        // Prepara variáveis JavaScript seguras
        $id_js      = htmlspecialchars($id, ENT_QUOTES, 'UTF-8');
        $usuario_js = htmlspecialchars($usuario, ENT_QUOTES, 'UTF-8');
        $nome_js    = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');

        // Constrói strings de callback para modal_master.  Utilizando variáveis intermediárias
        // evita problemas com aspas na construção do HTML dos botões.
        $onclick_editar      = "modal_master('api/clientes.php','edite_cliente','{$id_js}')";
        $onclick_renovar     = "modal_master('api/clientes.php','renovar_cliente','{$id_js}','usuario','{$usuario_js}')";
        $onclick_mais_telas  = "modal_master('api/clientes.php','mais_telas_cliente','{$id_js}','usuario','{$usuario_js}')";
        $onclick_bloquear    = "modal_master('api/clientes.php','toggle_bloqueado_cliente','{$id_js}')";
        $onclick_links       = "modal_master('api/clientes.php','info_links','{$id_js}')";
        $onclick_excluir     = "modal_master('api/clientes.php','delete_cliente','{$id_js}','usuario','{$usuario_js}')";

        // Monta o corpo do modal com informações e grade de botões
        $modal_body  = '<div class="container-fluid">';
        $modal_body .= '<div class="mb-3">';
        $modal_body .= '<h5 class="text-center">' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '</h5>';
        $modal_body .= '<p class="mb-1"><strong>Usuário:</strong> ' . htmlspecialchars($usuario, ENT_QUOTES, 'UTF-8') . '</p>';
        $modal_body .= '<p class="mb-1"><strong>Senha:</strong> ' . htmlspecialchars($senha, ENT_QUOTES, 'UTF-8') . '</p>';
        $modal_body .= '<p class="mb-1"><strong>Conexões:</strong> ' . (int)$conexoes . '</p>';
        $modal_body .= '<p class="mb-1"><strong>Máx. Telas:</strong> ' . (int)$conexoes_max . '</p>';
        $modal_body .= '<p class="mb-1"><strong>Vencimento:</strong> ' . date('d/m/Y', strtotime($Vencimento)) . '</p>';
        $modal_body .= '</div>';
        $modal_body .= '<div class="row row-cols-2 row-cols-md-3 g-2">';
        // Botão Editar
        $modal_body .= '<div class="col text-center">';
        $modal_body .= '<button type="button" class="btn btn-secondary w-100 py-2" '
                     . 'onclick="modal_master(\'api/clientes.php\', \'edite_cliente\', \'" . $id_js . "\')">'
                     . '<i class="fa fa-pencil-alt fa-lg"></i><br>Editar</button>';
        $modal_body .= '</div>';
        // Botão Renovar
        $modal_body .= '<div class="col text-center">';
        $modal_body .= '<button type="button" class="btn btn-warning w-100 py-2" '
                     . 'onclick="modal_master(\'api/clientes.php\', \'renovar_cliente\', \'" . $id_js . "\', \'usuario\', \'" . $usuario_js . "\')">'
                     . '<i class="fa fa-redo fa-lg"></i><br>Renovar</button>';
        $modal_body .= '</div>';
        // Botão Mais Telas – permite aumentar limite de conexões até 50
        $modal_body .= '<div class="col text-center">';
        $modal_body .= '<button type="button" class="btn btn-primary w-100 py-2" '
                     . 'onclick="modal_master(\'api/clientes.php\', \'mais_telas_cliente\', \'" . $id_js . "\', \'usuario\', \'" . $usuario_js . "\')">'
                     . '<i class="fa fa-tv fa-lg"></i><br>Adicionar Telas</button>';
        $modal_body .= '</div>';
        // Os botões de Modo Aleatório e de Multi Servidores foram removidos conforme solicitado
        // Botão Bloquear/Desbloquear
        $modal_body .= '<div class="col text-center">';
        $modal_body .= '<button type="button" class="btn ' . ($bloqueadoFlag ? 'btn-success' : 'btn-danger') . ' w-100 py-2" '
                     . 'onclick="modal_master(\'api/clientes.php\', \'toggle_bloqueado_cliente\', \'" . $id_js . "\')">'
                     . '<i class="fa ' . $iconeBloqueio . ' fa-lg"></i><br>' . $textoBloqueio . '</button>';
        $modal_body .= '</div>';
        // Botão Links
        $modal_body .= '<div class="col text-center">';
        $modal_body .= '<button type="button" class="btn btn-success w-100 py-2" '
                     . 'onclick="modal_master(\'api/clientes.php\', \'info_links\', \'" . $id_js . "\')">'
                     . '<i class="fa fa-link fa-lg"></i><br>Links</button>';
        $modal_body .= '</div>';
        // Botão Excluir
        $modal_body .= '<div class="col text-center">';
        $modal_body .= '<button type="button" class="btn btn-danger w-100 py-2" '
                     . 'onclick="modal_master(\'api/clientes.php\', \'delete_cliente\', \'" . $id_js . "\', \'usuario\', \'" . $usuario_js . "\')">'
                     . '<i class="fa fa-trash fa-lg"></i><br>Excluir</button>';
        $modal_body .= '</div>';
        $modal_body .= '</div>';
        $modal_body .= '</div>';

        // Rodapé com botão fechar
        $modal_footer = "<button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Fechar</button>";

        return [
            'modal_header_class' => 'd-block modal-header bg-dark text-white',
            'modal_titulo'      => 'Detalhes do Cliente',
            'modal_body'        => $modal_body,
            'modal_footer'      => $modal_footer
        ];
    }
    return 0;
}

/**
 * Exibe links M3U/HLS do cliente em formato de texto com botão de cópia.
 * Esta função preserva o comportamento original de info_cliente antes da
 * reformulação do layout.  Utilizada pela opção "Links" na grade de ações.
 *
 * @param int $id  ID do cliente
 * @return array   Estrutura de resposta para o modal_master
 */
function info_links($id)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.*
            FROM clientes c
            LEFT JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);

        $modal_body = '<pre class="pre-unique text-wrap" id="pre-' . $id . '" >';
        $modal_body .= '✅ *Usuário:* ' . $usuario . '<br>';
        $modal_body .= '✅ *Senha:* ' . $senha . '<br>';
        $modal_body .= '🟠 *URL/Port:*  http://' . $_SERVER['HTTP_HOST'] . '<br>';
        $modal_body .= '📶 *Máximo de conexões:* ' . $conexoes . '<br>';
        $modal_body .= '🗓 *Data de Criado:* ' . date('d-m-Y H:i:s', strtotime($Criado_em)) . '<br>';
        $modal_body .= '🗓 *Data de validade:* ' . date('d-m-Y H:i:s', strtotime($Vencimento)) . '<br>';
        $modal_body .= '<br>';
        $modal_body .= '🟢 *Link (M3U):* <br> http://' . $_SERVER['HTTP_HOST'] . '/get.php?username=' . $usuario . '&password=' . $senha . '&type=m3u_plus&amp;output=ts<br>';
        $modal_body .= '🟢 *Link (HLS):* <br> http://' . $_SERVER['HTTP_HOST'] . '/get.php?username=' . $usuario . '&password=' . $senha . '&type=m3u_plus&amp;output=m3u8<br>';
        $modal_body .= '<br>';
        $modal_body .= '🟢 *Link (M3U Encurtado):* <br> http://' . $_SERVER['HTTP_HOST'] . '/m3u-ts/' . $usuario . '/' . $senha . '<br>';
        $modal_body .= '🟢 *Link (HLS Encurtado):* <br> http://' . $_SERVER['HTTP_HOST'] . '/m3u-m3u8/' . $usuario . '/' . $senha . '<br>';
        $modal_body .= '<br>';
        $modal_body .= '🟢 *Link (M3U SSIPTV Encurtado):* <br> http://' . $_SERVER['HTTP_HOST'] . '/ss-ts/' . $usuario . '/' . $senha . '<br>';
        $modal_body .= '🟢 *Link (HLS SSIPTV Encurtado):* <br> http://' . $_SERVER['HTTP_HOST'] . '/ss-m3u8/' . $usuario . '/' . $senha . '<br>';
        $modal_body .= '<br>';
        $modal_body .= '♦️ *DNS STB:* Indisponivel <br>';
        $modal_body .= '</pre>';

        $modal_footer = "<button type='button' class='btn btn-info waves-effect waves-light j_copy_clipboard' onclick='copyText(\"pre-" . $id . "\")'>Copiar</button>";

        return [
            'modal_header_class' => 'd-block modal-header bg-info text-white',
            'modal_titulo'      => 'Links do usuário (' . $usuario . ')',
            'modal_body'        => $modal_body,
            'modal_footer'      => $modal_footer
        ];
    }
    return 0;
}

/**
 * Formulário para definir a quantidade máxima de telas (conexoes_max) para um cliente.
 * Apresenta um campo de seleção entre 1 e 50 com o valor atual pré‑selecionado.
 *
 * @param int $id ID do cliente
 * @param string|null $usuario Nome de usuário (opcional)
 * @return array Estrutura de resposta para modal_master
 */
function mais_telas_cliente($id)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.conexoes_max, c.usuario
            FROM clientes c
            LEFT JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $conexoes_max_atual = (int)$row['conexoes_max'];

        // Constrói as opções do select de 1 a 50
        $options = '';
        for ($i = 1; $i <= 50; $i++) {
            $selected = ($i === $conexoes_max_atual) ? 'selected' : '';
            $options .= '<option value="' . $i . '" ' . $selected . '>' . $i . '</option>';
        }

        $modal_body  = '';
        $modal_body .= '<input type="hidden" name="confirme_mais_telas_cliente" value="' . $id . '">';
        $modal_body .= '<div class="form-group">';
        $modal_body .= '<label for="conexoes_max">Quantidade de telas:</label>';
        $modal_body .= '<select class="form-control form-select" id="conexoes_max" name="conexoes_max">' . $options . '</select>';
        $modal_body .= '</div>';

        // Build footer buttons: call enviardados() with proper quoting inside attributes.
        $modal_footer  = '<button type="button" onclick="enviardados(\'modal_master_form\', \'clientes.php\')" class="btn btn-info">Salvar</button>';
        $modal_footer .= '<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>';

        return [
            'modal_header_class' => 'd-block modal-header bg-dark text-white',
            'modal_titulo'      => 'Definir número de telas',
            'modal_body'        => $modal_body,
            'modal_footer'      => $modal_footer
        ];
    }
    return 0;
}

/**
 * Atualiza a quantidade máxima de conexões para um cliente e retorna mensagem de status.
 *
 * @param int $id ID do cliente
 * @param int $conexoes_max Nova quantidade máxima de conexões
 * @return array
 */
function confirme_mais_telas_cliente($id, $conexoes_max)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    // Garante que o valor esteja dentro do intervalo permitido
    $conexoes_max = (int)$conexoes_max;
    if ($conexoes_max < 1) {
        $conexoes_max = 1;
    }
    if ($conexoes_max > 50) {
        $conexoes_max = 50;
    }

    /*
     * Ao ajustar a quantidade máxima de telas para um cliente, precisamos verificar se
     * o revendedor tem créditos suficientes para cobrir o aumento. Caso o novo
     * valor seja maior que o atual, calculamos a diferença e debitamos essa
     * quantidade de créditos. Se o admin for master (a.admin = 1), não é
     * necessário deduzir créditos. Caso contrário, verificamos o saldo antes
     * de atualizar.
     */
    // Obtem informações do cliente e do administrador (revendedor)
    $sqlInfo = "SELECT c.conexoes_max AS atual, a.id AS admin_id, a.admin, a.creditos
                FROM clientes c
                JOIN admin a ON c.admin_id = a.id
                WHERE c.id = :id AND a.token = :token";
    $stmtInfo = $conexao->prepare($sqlInfo);
    $stmtInfo->bindParam(':id', $id, PDO::PARAM_INT);
    $stmtInfo->bindParam(':token', $token);
    $stmtInfo->execute();
    $info = $stmtInfo->fetch(PDO::FETCH_ASSOC);
    if (!$info) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Cliente não encontrado.',
            'icon'  => 'error'
        ];
    }
    $conexoesAtual   = (int)$info['atual'];
    $adminId         = (int)$info['admin_id'];
    $adminLevel      = (int)$info['admin'];
    $creditos        = (int)$info['creditos'];

    $diferenca = $conexoes_max - $conexoesAtual;
    // Se não houver aumento (diferenca <= 0), apenas atualiza sem cobrar
    if ($diferenca <= 0 || $adminLevel == 1) {
        $sqlUpdate = "UPDATE clientes c
                      JOIN admin a ON c.admin_id = a.id
                      SET c.conexoes_max = :conexoes_max
                      WHERE c.id = :id AND a.token = :token";
        $stmtUpdate = $conexao->prepare($sqlUpdate);
        $stmtUpdate->bindParam(':conexoes_max', $conexoes_max, PDO::PARAM_INT);
        $stmtUpdate->bindParam(':id', $id, PDO::PARAM_INT);
        $stmtUpdate->bindParam(':token', $token);
        if ($stmtUpdate->execute()) {
            return [
                'title' => 'Concluído!',
                'msg'   => 'Quantidade de telas atualizada com sucesso.',
                'icon'  => 'success',
                'modal' => 'hide',
                'data_table' => 'atualizar'
            ];
        } else {
            return [
                'title' => 'Erro!',
                'msg'   => 'Não foi possível atualizar as telas.',
                'icon'  => 'error'
            ];
        }
    }
    // Caso seja um revendedor (adminLevel != 1) e seja necessário aumentar as telas
    if ($diferenca > 0) {
        if ($creditos < $diferenca) {
            return [
                'title' => 'Erro!',
                'msg'   => 'Você não possui créditos suficientes para adicionar mais telas.',
                'icon'  => 'error'
            ];
        }
        // Realiza atualização de telas e desconta créditos
        try {
            $conexao->beginTransaction();
            // Atualiza o valor de conexoes_max
            $sqlUpdate = "UPDATE clientes SET conexoes_max = :conexoes_max WHERE id = :id";
            $stmtUpdate = $conexao->prepare($sqlUpdate);
            $stmtUpdate->bindParam(':conexoes_max', $conexoes_max, PDO::PARAM_INT);
            $stmtUpdate->bindParam(':id', $id, PDO::PARAM_INT);
            $stmtUpdate->execute();
            // Deduz créditos do admin
            $sqlCredito = "UPDATE admin SET creditos = creditos - :diff WHERE id = :admin_id";
            $stmtCredito = $conexao->prepare($sqlCredito);
            $stmtCredito->bindParam(':diff', $diferenca, PDO::PARAM_INT);
            $stmtCredito->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
            $stmtCredito->execute();
            $conexao->commit();
            return [
                'title' => 'Concluído!',
                'msg'   => 'Quantidade de telas atualizada com sucesso.',
                'icon'  => 'success',
                'modal' => 'hide',
                'data_table' => 'atualizar'
            ];
        } catch (Exception $e) {
            $conexao->rollBack();
            return [
                'title' => 'Erro!',
                'msg'   => 'Não foi possível atualizar as telas.',
                'icon'  => 'error'
            ];
        }
    }
    // Fallback – não deveria chegar aqui
    return [
        'title' => 'Erro!',
        'msg'   => 'Operação inválida.',
        'icon'  => 'error'
    ];
}

/**
 * Alterna o modo aleatório (modo_aleatorio) de um cliente.
 * Quando ativado, as conexões serão distribuídas de forma randômica
 * entre os servidores configurados. O valor é simplesmente alternado
 * entre 0 e 1.
 *
 * @param int $id ID do cliente
 * @return array
 */
function toggle_modo_aleatorio_cliente($id)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    // Obtém o valor atual
    $sql = "SELECT c.modo_aleatorio
            FROM clientes c
            JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Cliente não encontrado.',
            'icon'  => 'error'
        ];
    }
    $novoValor = ($row['modo_aleatorio'] == 1) ? 0 : 1;

    $sql2 = "UPDATE clientes c
             JOIN admin a ON c.admin_id = a.id
             SET c.modo_aleatorio = :novo
             WHERE c.id = :id AND a.token = :token";
    $stmt2 = $conexao->prepare($sql2);
    $stmt2->bindParam(':novo', $novoValor, PDO::PARAM_INT);
    $stmt2->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt2->bindParam(':token', $token);

    if ($stmt2->execute()) {
        return [
            'title' => 'Concluído!',
            'msg'   => 'Modo aleatório alterado com sucesso.',
            'icon'  => 'success',
            'modal' => 'hide'
        ];
    }
    return [
        'title' => 'Erro!',
        'msg'   => 'Não foi possível alterar o modo aleatório.',
        'icon'  => 'error'
    ];
}

/**
 * Formulário para configurar múltiplos servidores para um cliente.
 * Permite inserir uma lista separada por vírgulas de IDs ou apelidos de servidores.
 *
 * @param int $id ID do cliente
 * @return array
 */
function multi_servidor_cliente($id)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.servidores
            FROM clientes c
            JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $servidores_atual = $row['servidores'];
        $modal_body  = '';
        $modal_body .= '<input type="hidden" name="confirme_multi_servidor_cliente" value="' . $id . '">';
        $modal_body .= '<div class="form-group">';
        $modal_body .= '<label for="servidores">Lista de servidores (separados por vírgula):</label>';
        $modal_body .= '<textarea class="form-control" id="servidores" name="servidores" rows="3" placeholder="Ex: 1,2,3">' . htmlspecialchars($servidores_atual ?? '', ENT_QUOTES, 'UTF-8') . '</textarea>';
        $modal_body .= '</div>';

        // Build footer buttons: call enviardados() with proper quoting inside attributes.
        $modal_footer  = '<button type="button" onclick="enviardados(\'modal_master_form\', \'clientes.php\')" class="btn btn-info">Salvar</button>';
        $modal_footer .= '<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>';

        return [
            'modal_header_class' => 'd-block modal-header bg-dark text-white',
            'modal_titulo'      => 'Configurar servidores',
            'modal_body'        => $modal_body,
            'modal_footer'      => $modal_footer
        ];
    }
    return 0;
}

/**
 * Atualiza a lista de servidores atribuída a um cliente.
 *
 * @param int $id ID do cliente
 * @param string $servidores Lista de servidores separados por vírgula
 * @return array
 */
function confirme_multi_servidor_cliente($id, $servidores)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    // Sanitiza a string removendo espaços extras
    $servidores = trim($servidores);

    $sql = "UPDATE clientes c
            JOIN admin a ON c.admin_id = a.id
            SET c.servidores = :servidores
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':servidores', $servidores, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);

    if ($stmt->execute()) {
        return [
            'title' => 'Concluído!',
            'msg'   => 'Servidores atualizados com sucesso.',
            'icon'  => 'success',
            'modal' => 'hide'
        ];
    }
    return [
        'title' => 'Erro!',
        'msg'   => 'Não foi possível atualizar servidores.',
        'icon'  => 'error'
    ];
}

/**
 * Exibe um formulário para migrar clientes de outro servidor.  O modal
 * apresenta um campo de texto onde cada linha deve conter os dados de
 * um cliente no formato: usuario,senha,vencimento(AAAA-MM-DD),telas_max.
 * Campos opcionais de vencimento e telas podem ser omitidos; caso
 * ausentes, será aplicada a data de vencimento padrão (30 dias a partir
 * da data atual) e uma tela (conexoes_max = 1).
 *
 * @return array Estrutura para o modal_master
 */
function migrar_clientes()
{
    $modal_body  = '';
    $modal_body .= '<input type="hidden" name="confirme_migrar_clientes" value="1">';
    $modal_body .= '<div class="form-group">';
    $modal_body .= '<label for="lista_clientes">Lista de clientes a migrar:</label>';
    $modal_body .= '<small class="d-block mb-2">Insira cada cliente em uma nova linha seguindo o formato:<br>usuario,senha,vencimento(AAAA-MM-DD),telas_max</small>';
    $modal_body .= '<textarea class="form-control" id="lista_clientes" name="lista_clientes" rows="8" placeholder="Exemplo:\nuser1,pass1,2025-12-31,2\nuser2,pass2"></textarea>';
    $modal_body .= '</div>';

    $modal_footer  = '<button type="button" onclick="enviardados(\'modal_master_form\', \'clientes.php\')" class="btn btn-info">Migrar</button>';
    $modal_footer .= '<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>';

    return [
        'modal_header_class' => 'd-block modal-header bg-dark text-white',
        'modal_titulo'      => 'Migrar Clientes',
        'modal_body'        => $modal_body,
        'modal_footer'      => $modal_footer
    ];
}

/**
 * Processa a migração de clientes a partir de uma lista de entrada.
 * Cada linha da lista deve conter os campos separados por vírgula
 * conforme o padrão: usuario,senha,vencimento(AAAA-MM-DD),telas_max.
 * Usuários duplicados (já existentes na base local) são ignorados.
 * Para cada cliente criado, define o plano padrão como 1 e associa
 * o registro ao admin logado. Vencimento e telas máximas são
 * opcionais; se ausentes, aplica‑se vencimento +30 dias e uma tela.
 *
 * @param string $lista  Texto contendo a lista de clientes
 * @return array         Resposta para exibir notificação ao usuário
 */
function confirme_migrar_clientes($lista)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";
    $adminId = isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : 0;
    if (!$conexao) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Falha na conexão com o banco de dados.',
            'icon'  => 'error'
        ];
    }
    // Valida token com admin e obtém um plano padrão (o primeiro disponível).
    try {
        $stmtAdmin = $conexao->prepare('SELECT id FROM admin WHERE id = :admin_id AND token = :token');
        $stmtAdmin->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
        $stmtAdmin->bindParam(':token', $token, PDO::PARAM_STR);
        $stmtAdmin->execute();
        if (!$stmtAdmin->fetch(PDO::FETCH_ASSOC)) {
            return [
                'title' => 'Erro!',
                'msg'   => 'Admin não encontrado ou sessão expirada.',
                'icon'  => 'error'
            ];
        }
        // Obtém um plano padrão disponível (menor id)
        $stmtPlano = $conexao->prepare('SELECT id FROM planos ORDER BY id ASC LIMIT 1');
        $stmtPlano->execute();
        $planoRow = $stmtPlano->fetch(PDO::FETCH_ASSOC);
        $planoId  = $planoRow ? (int)$planoRow['id'] : 1;
    } catch (Exception $e) {
        $planoId = 1;
    }
    $linhas      = preg_split("/\r?\n/", trim($lista));
    $importados  = 0;
    $duplicados  = 0;
    foreach ($linhas as $linha) {
        $linha = trim($linha);
        if ($linha === '') {
            continue;
        }
        // Inicializa variáveis padrão
        $usr   = '';
        $pwd   = '';
        $venc  = '';
        $telas = 1;
        // Se a linha parecer ser uma URL (M3U), tenta extrair usuario e senha
        if (stripos($linha, 'http') !== false) {
            // Tenta extrair com username e password na query string
            if (preg_match('/username=([^&]+)/i', $linha, $mUser)) {
                $usr = trim($mUser[1]);
            }
            if (preg_match('/password=([^&]+)/i', $linha, $mPass)) {
                $pwd = trim($mPass[1]);
            }
            // Se ainda não conseguiu via query, tenta via segmentos da URL
            if ($usr === '' || $pwd === '') {
                $path = parse_url($linha, PHP_URL_PATH);
                if ($path) {
                    // Remove barras iniciais/finais e divide em segmentos
                    $segments = array_values(array_filter(explode('/', trim($path, '/'))));
                    // Procura padrões do tipo live/usuario/senha ou get.php/usuario/senha
                    // Procura por um segmento que contenha usuario e o seguinte contendo senha
                    if (count($segments) >= 3) {
                        // Tenta localizar segmentos que não sejam 'live', 'movie', 'series', 'get.php' etc.
                        for ($i = 0; $i < count($segments) - 1; $i++) {
                            $segU = $segments[$i];
                            $segP = $segments[$i + 1];
                            // Considera pares de segmentos com letras ou números
                            if ($segU && $segP && preg_match('/^[A-Za-z0-9_]+$/', $segU) && preg_match('/^[A-Za-z0-9_]+$/', $segP)) {
                                $usr = $segU;
                                $pwd = $segP;
                                break;
                            }
                        }
                    }
                }
            }
        }
        // Se não foi possível extrair de URL, tenta formato CSV (usuario,senha,vencimento,telas)
        if ($usr === '' || $pwd === '') {
            $cols = array_map('trim', explode(',', $linha));
            // Precisa de pelo menos usuário e senha
            if (count($cols) >= 2) {
                $usr  = $cols[0];
                $pwd  = $cols[1];
                $venc = isset($cols[2]) && $cols[2] !== '' ? $cols[2] : '';
                $telas = isset($cols[3]) && is_numeric($cols[3]) ? (int)$cols[3] : 1;
            } else {
                // Linha inválida, ignora
                continue;
            }
        }
        // Se usuário ou senha ainda estiverem vazios, ignora a linha
        if ($usr === '' || $pwd === '') {
            continue;
        }
        // Verifica duplicidade
        $stmtCheck = $conexao->prepare('SELECT id FROM clientes WHERE usuario = :usr');
        $stmtCheck->bindParam(':usr', $usr, PDO::PARAM_STR);
        $stmtCheck->execute();
        if ($stmtCheck->fetch(PDO::FETCH_ASSOC)) {
            $duplicados++;
            continue;
        }
        // Define vencimento: se fornecido, tenta parsear, senão +30 dias
        $vencimentoSQL = '';
        if ($venc !== '') {
            $vencNorm   = str_replace('/', '-', $venc);
            $timestamp  = strtotime($vencNorm);
            if ($timestamp && $timestamp > 0) {
                $vencimentoSQL = date('Y-m-d 23:59:59', $timestamp);
            }
        }
        if ($vencimentoSQL === '') {
            $vencimentoSQL = date('Y-m-d 23:59:59', strtotime('+30 days'));
        }
        // Prepara e executa inserção
        try {
            $sqlInsert = "INSERT INTO clientes (name, usuario, senha, Criado_em, Ultimo_pagamento, Vencimento, is_trial, adulto, conexoes, conexoes_max, bloqueado, admin_id, plano, Dispositivo, App) VALUES (:name, :usuario, :senha, NOW(), NOW(), :vencimento, 0, 0, :conexoes, :conexoes_max, 0, :admin_id, :plano, :dispositivo, :app)";
            $stmtIns   = $conexao->prepare($sqlInsert);
            $nomeCliente = $usr;
            $conexoesAtual = $telas > 0 ? $telas : 1;
            $stmtIns->bindParam(':name', $nomeCliente, PDO::PARAM_STR);
            $stmtIns->bindParam(':usuario', $usr, PDO::PARAM_STR);
            $stmtIns->bindParam(':senha', $pwd, PDO::PARAM_STR);
            $stmtIns->bindParam(':vencimento', $vencimentoSQL, PDO::PARAM_STR);
            $stmtIns->bindParam(':conexoes', $conexoesAtual, PDO::PARAM_INT);
            $stmtIns->bindParam(':conexoes_max', $telas, PDO::PARAM_INT);
            $stmtIns->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
            $stmtIns->bindParam(':plano', $planoId, PDO::PARAM_INT);
            $dispositivo = 'Migrado';
            $app         = 'Migrado';
            $stmtIns->bindParam(':dispositivo', $dispositivo, PDO::PARAM_STR);
            $stmtIns->bindParam(':app', $app, PDO::PARAM_STR);
            $stmtIns->execute();
            $importados++;
        } catch (Exception $e) {
            // Falha nesta linha, ignora e segue
            continue;
        }
    }
    $mensagem  = $importados . ' cliente(s) migrado(s) com sucesso.';
    if ($duplicados > 0) {
        $mensagem .= ' ' . $duplicados . ' duplicado(s) foram ignorados.';
    }
    return [
        'title' => 'Concluído!',
        'msg'   => $mensagem,
        'icon'  => 'success',
        'modal' => 'hide'
    ];
}

/**
 * Alterna o estado de bloqueio de um cliente (bloqueado).
 * Quando bloqueado, o cliente não tem acesso até ser desbloqueado manualmente.
 *
 * @param int $id ID do cliente
 * @return array
 */
function toggle_bloqueado_cliente($id)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    // Obtém valor atual
    $sql = "SELECT c.bloqueado
            FROM clientes c
            JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Cliente não encontrado.',
            'icon'  => 'error'
        ];
    }
    $novoValor = ($row['bloqueado'] == 1) ? 0 : 1;

    $sql2 = "UPDATE clientes c
             JOIN admin a ON c.admin_id = a.id
             SET c.bloqueado = :novo
             WHERE c.id = :id AND a.token = :token";
    $stmt2 = $conexao->prepare($sql2);
    $stmt2->bindParam(':novo', $novoValor, PDO::PARAM_INT);
    $stmt2->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt2->bindParam(':token', $token);

    if ($stmt2->execute()) {
        return [
            'title' => 'Concluído!',
            'msg'   => 'Estado de bloqueio alterado com sucesso.',
            'icon'  => 'success',
            'modal' => 'hide'
        ];
    }
    return [
        'title' => 'Erro!',
        'msg'   => 'Não foi possível alterar bloqueio.',
        'icon'  => 'error'
    ];
}

function edite_cliente($id)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.*
            FROM clientes c 
            LEFT JOIN admin a ON c.admin_id = a.id 
            WHERE c.id = :id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

        extract($row);

        $plano1 = $conexao->query("SELECT * FROM planos WHERE admin_id = '$admin_id'");
        $planoOptions = "";
        $planoOptions2 = "";
        while ($lista_plano = $plano1->fetch()) {

            if ($lista_plano['id'] == $plano) {
                $planoOptions .= '<option value="'.$lista_plano['id'].'"> Plano Atual => '.$lista_plano['nome'].' [R$: '.$lista_plano['valor'].']</option>';
            }else{
                $planoOptions2 .= '<option value="'.$lista_plano['id'].'">'.$lista_plano['nome'].' [R$: '.$lista_plano['valor'].']</option>';
            }
        }

        $stmt = $conexao->query("SELECT * FROM devices_apps");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $devices = array();
        foreach ($rows as $row) {
          $deviceName = $row['device_name'];
          $appName = $row['app_name'];

          if (!isset($devices[$deviceName])) {
            $devices[$deviceName] = array();
          }

          $devices[$deviceName][] = array("name" => $appName);
        }

        $data = array("devices" => array());
        foreach ($devices as $deviceName => $apps) {
          $data["devices"][] = array("name" => $deviceName, "apps" => $apps);
        }

        $jsonData = json_encode($data);

        $modal_body = '';
        $modal_body .= '<input type="hidden" name="confirme_edite_cliente" value="">';
        $modal_body .= '<input type="hidden" name="id" value="'.$id.'">';
        $modal_body .= '<div class="form-group">
                        <label for="name">Nome do cliente:</label>
                        <input type="text" class="form-control" id="name" name="name" value="'.$name.'">
                    </div>';
        $modal_body .= '<div class="form-row row">';
        $modal_body .= '<div class="form-group col-md col">
        <label for="usuario">Usuario</label>
        <input type="text" class="form-control" name="usuario" value="'.$usuario.'">
    </div>';
        $modal_body .= ' <div class="form-group col-md col">
        <label for="senha">Senha</label>
        <input type="text" class="form-control" name="senha" value="'.$senha.'">
    </div>';
        $modal_body .= '</div>';
        $modal_body .= '<div class="form-group"> <label for="adulto">Conteudo adulto?</label>
                <select class="form-control form-select" name="adulto" id="adulto">
                                            <option value="'.$adulto.'"">('. ($adulto == 0 ? "NÃO" : "SIM") .')</option>';

        switch ($adulto) {
            case "0":
                $modal_body .= "<option value='1'>Mudar PARA ( SIM )</option>";
                break;
            case "1":
                $modal_body .= "<option value='0'>Mudar PARA ( NAO )</option>";
                break;
        }

        $modal_body .= '</select></div>';

        // Campo para alterar o tipo de conteúdo (filmes, séries ou completo).  Usamos a coluna
        // c_ocultar_fonte para armazenar essa informação.  Exibimos a opção atual e
        // oferecemos alternativas.  Caso o valor atual não seja reconhecido, assumimos completo.
        $valor_fonte_atual = isset($c_ocultar_fonte) ? strtolower($c_ocultar_fonte) : 'completo';
        if ($valor_fonte_atual !== 'filmes' && $valor_fonte_atual !== 'series' && $valor_fonte_atual !== 'completo') {
            $valor_fonte_atual = 'completo';
        }
        $modal_body .= '<div class="form-group">\n';
        $modal_body .= '<label for="fonte">Tipo de conteúdo:</label>\n';
        $modal_body .= '<select class="form-control form-select" name="fonte" id="fonte">';
        // Define a opção atual como selecionada
        $options_fonte = [
            'completo' => 'Completo (Filmes e Séries)',
            'filmes'   => 'Somente Filmes',
            'series'   => 'Somente Séries'
        ];
        foreach ($options_fonte as $valorOption => $rotuloOption) {
            $selected = ($valor_fonte_atual === $valorOption) ? 'selected' : '';
            $modal_body .= '<option value="' . $valorOption . '" ' . $selected . '>' . $rotuloOption . '</option>';
        }
        $modal_body .= '</select>';
        $modal_body .= '</div>';

        $modal_body .= '<div class="form-group">
            <label for="plano">plano:</label>
            <select class="form-control form-select" id="plano" name="plano">
                '.$planoOptions.' '.$planoOptions2.'
            </select>
    </div>';

        $modal_body .= '<div class="bform-row row">';
        $modal_body .= '<div class="col-6 form-group">';
            $modal_body .= '<label for="Dispositivo">Dispositivo:</label>
            <select class="form-control form-select" id="Dispositivo" name="dispositivo">
                <option value="'.$Dispositivo.'">'.$Dispositivo.' [Atual]</option>

            </select>';
            $modal_body .= '</div>';
            $modal_body .= '<div class="col-6 form-group">';
            $modal_body .= '<label for="App">App:</label>
            <select class="form-control form-select" id="App" name="app">
            <option value="'.$App.'">'.$App.' [Atual]</option>
            </select>';
            $modal_body .= '</div>';

        $modal_body .= '</div>';
        $modal_body .= '<div class="form-group">

            <label for="Forma-de-pagamento">Forma de pagamento:</label>
                <select class="form-control form-select" id="forma-de-pagamento" name="forma-de-pagamento">
                <option value="PIX">PIX</option>
                <option value="boleto">Boleto</option>
                </select>

        <label for="nome-do-pagador">Nome do pagador:</label>
        <input type="text" class="form-control" id="nome-do-pagador" name="nome-do-pagador" value="'.$nome_do_pagador.'" placeholder="Exemplo: josé joão da silva">

    </div>';
        $modal_body .= '<div class="form-group">
        <label for="Whatsapp">Whatsapp:</label>
            <input type="text"class="form-control" id="Whatsapp" name="whatsapp" value="'.$Whatsapp.'" placeholder="Exemplo: +55 11 99999-9999">
    </div>';
    $modal_body .= '<div class="form-group">
        <label for="Whatsapp">Indicado por:</label>
            <input type="text"class="form-control" id="indicacao" name="indicacao" value="'.$indicado_por.'" placeholder="Coloque o ID do Usuário que fez a indicação">
    </div>';
    if ($App == "SMART ONE" || $App == "IBO PLAYER PRO" || $App == "IBO PRO") {
        $modal_body .= '<div class="form-group">
        <label for="device_mac">MAC:</label>
            <input type="text"class="form-control" id="device_mac" maxlength="17" name="device_mac" value="'.$device_mac.'" placeholder="Exemplo:  D4:1B:11:22:B0:44 ou D41B1122B044">
    </div>';
    }
    if ($App == "ClouddY") {
        $modal_body .= '<div class="form-group">
        <label for="email_app">EMAIL-APP:</label>
            <input type="text"class="form-control" id="email_app" name="email_app" value="'.$email_app.'" placeholder="Exemplo: josefulano@gmail.com">
    </div>';
    $modal_body .= '<div class="form-group">
        <label for="senha_app">Senha-APP:</label>
            <input type="text"class="form-control" id="senha_app"  name="senha_app" value="'.$senha_app.'" placeholder="coloque a senha do aplicativo aqui">
    </div>';
    }
    if ($App == "IBO PLAYER PRO" || $App == "IBO PRO") {
        $modal_body .= '<div class="form-group">
        <label for="device_key">Device key:</label>
            <input type="text"class="form-control" id="device_key" name="device_key" value="'.$device_key.'" placeholder="Exemplo:  112233">
    </div>';
    }
    if ($App == "SMART ONE" || $App == "IBO PLAYER PRO" || $App == "IBO PRO" || $App == "ClouddY") {
        $modal_body .= '<div class="form-group">
        <label for="data_app">Vencimento App:</label>
            <input type="date"class="form-control" id="data_app" name="data_app" value="'.$validade_app.'">
    </div>';
    }

        $modal_body .= '<script>
  var data = ' . $jsonData . ';
  data.devices.forEach(device => {
    const option = document.createElement("option");
    option.value = device.name;
    option.text = device.name;
    document.querySelector("#Dispositivo").appendChild(option);
  });

  document.querySelector("#Dispositivo").addEventListener("change", function () {
    const selectedDevice = data.devices.find(device => device.name === this.value);
    document.querySelector("#App").innerHTML = "";
    const option = document.createElement("option");
    option.value = "";
    option.text = "Selecione um app";
    document.querySelector("#App").appendChild(option);
    if (selectedDevice) {
      selectedDevice.apps.forEach(app => {
        const option = document.createElement("option");
        option.value = app.name;
        option.text = app.name;
        document.querySelector("#App").appendChild(option);
      });
    }
  });

    document.querySelector("#App").addEventListener("change", function () {
    const selectedApp = this.value;
    const deviceMacInput = document.querySelector("#device_mac");
    const deviceKeyInput = document.querySelector("#device_key");
    const demailappInput = document.querySelector("#email_app");
    const senhaappInput = document.querySelector("#senha_app");
    const dataappInput = document.querySelector("#data_app");

    if (deviceMacInput) {
        deviceMacInput.disabled = true;
    }
    if (deviceKeyInput) {
        deviceKeyInput.disabled = true;
    }
    if (demailappInput) {
        demailappInput.disabled = true;
    }
    if (senhaappInput) {
        senhaappInput.disabled = true;
    }
    if (dataappInput) {
        dataappInput.disabled = true;
    }

    if (selectedApp === "SMART ONE") {
        if (deviceMacInput) {
            deviceMacInput.disabled = false;
        }
    }
    if (selectedApp === "IBO PLAYER PRO" || selectedApp === "IBO PRO") {
        if (deviceMacInput) {
            deviceMacInput.disabled = false;
        }
        if (deviceKeyInput) {
            deviceKeyInput.disabled = false;
        }
    }
    if (selectedApp === "ClouddY") {
        if (demailappInput) {
            demailappInput.disabled = false;
        }
        if (senhaappInput) {
            senhaappInput.disabled = false;
        }
    }
    if (selectedApp === "IBO PLAYER PRO" || selectedApp === "IBO PRO" || selectedApp === "ClouddY") {
        if (dataappInput) {
            dataappInput.disabled = false;
        }
    }
    });</script>';
        $modal_body .= '';

        $modal_footer = "<button type='button' onclick='enviardados(\"modal_master_form\", \"clientes.php\")' class='btn btn-info waves-effect waves-light' >Salvar</button><button type='button' class='btn btn-danger' data-bs-dismiss='modal' aria-label='Close'>Cancelar</button>";

        $resposta = [
            'modal_header_class'=> "d-block modal-header bg-info text-white",
            'modal_titulo'=> "lista do usuario (".$usuario.")",
            'modal_body'=> $modal_body,
            'modal_footer'=> $modal_footer
        ];

    return $resposta;
    } else {
        return 0;
    }
}

function confirme_edite_cliente($id, $name, $usuario, $senha, $fonte, $adulto, $plano, $Dispositivo, $App, $Forma_de_pagamento, $nome_do_pagador, $Whatsapp, $indicacao, $mac, $key,$email_app, $senha_app, $validade_app)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";
    $admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

    $id = preg_replace("/[^0-9]/", "", $id);
    $name = preg_replace("/[^a-zA-Z0-9 ]/", "", $name);
    $usuario = preg_replace("/[^a-zA-Z0-9]/", "", $usuario);
    $senha = preg_replace("/[^a-zA-Z0-9]/", "", $senha);
    $adulto = preg_replace("/[^0-9]/", "", $adulto);
    $plano = preg_replace("/[^0-9]/", "", $plano);
    $Dispositivo = preg_replace("/[^a-zA-Z0-9 ]/", "", $Dispositivo);
    $App = preg_replace("/[^a-zA-Z0-9 ]/", "", $App);
    $Forma_de_pagamento = preg_replace("/[^a-zA-Z0-9]/", "", $Forma_de_pagamento);
    $nome_do_pagador = preg_replace("/[^a-zA-Z0-9 ]/", "", $nome_do_pagador);

    if ($mac == 'não está presente') {

    }elseif($mac == 'vazio') {
        $mac = null;
    }else{
        $mac = preg_replace("/[^a-zA-Z0-9:]/", "", $mac);

        $mac_formatado = preg_replace('/[^a-fA-F0-9]/', '', $mac);

        $mac = strtoupper(implode(':', str_split($mac_formatado, 2)));
    }

    if (!empty($key)) {
        $key = preg_replace("/[^0-9]/", "", $key);
    } else {
        $key = null;
    }

    if (!empty($Whatsapp)) {
        $Whatsapp = preg_replace("/[^0-9+]/", "", $Whatsapp); 
        $Whatsapp = is_numeric($Whatsapp) ? $Whatsapp : null; 
    } else {
        $Whatsapp = null; 
    }

    if (!empty($indicacao)) {
        $indicacao = preg_replace("/[^0-9]/", "", $indicacao); 
        $indicacao = is_numeric($indicacao) ? $indicacao : null; 
    } else {
        $indicacao = null; 
    }

    if ($email_app == 'não está presente') {

    }elseif($email_app == 'vazio') {
        $email_app = null;
    }else{
        $email_app = preg_replace("/[^a-zA-Z0-9@. ]/", "", $email_app);
    }

    if ($senha_app == 'não está presente') {

    }elseif($senha_app == 'vazio') {
        $senha_app = null;
    }else{
        $senha_app = preg_replace("/[^a-zA-Z0-9@. ]/", "", $senha_app);
    }

    if ($validade_app == 'não está presente') {

    }elseif($validade_app == 'vazio') {
        $validade_app = null;
    }else{
        $validade_app = preg_replace("/[^0-9-]/", "", $validade_app);
    }

    $sql = "SELECT c.*,
                a.id as admin_id,
                p.valor as valor
            FROM clientes c 
            LEFT JOIN admin a ON c.admin_id = a.id 
            LEFT JOIN planos p ON p.id = :plano 
            WHERE c.id = :id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':plano', $plano, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token);
        $stmt->execute();

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $hoje = date('Y-m-d');
            $valor_plano = $row['valor']; 

            $sql_update = "UPDATE clientes SET ";
            $updates = [];

            if (!empty($adulto)) {
                $updates[] = "adulto = :adulto";
            }else{
                $updates[] = "adulto = 0";
            }
            if (!empty($name)) {
                $updates[] = "name = :name";
            }
            if (!empty($usuario)) {
                $updates[] = "usuario = :usuario";
            }
            if (!empty($senha)) {
                $updates[] = "senha = :senha";
            }

            // Atualiza o tipo de conteúdo, se informado (filmes, séries ou completo).
            if (!empty($fonte)) {
                $updates[] = "c_ocultar_fonte = :fonte";
            }
            if (!empty($plano)) {
                $updates[] = "plano = :plano";
            }
            if (isset($valor_plano) || $valor_plano === 0) {
                $updates[] = "V_total = :valor_plano";
            }
            if (!empty($Dispositivo)) {
                $updates[] = "Dispositivo = :Dispositivo";
            }
            if (!empty($App)) {
                $updates[] = "App = :App";
            }
            if (!empty($Forma_de_pagamento)) {
                $updates[] = "Forma_de_pagamento = :Forma_de_pagamento";
            }
            if (!empty($nome_do_pagador)) {
                $updates[] = "nome_do_pagador = :nome_do_pagador";
            }else{
                $updates[] = "nome_do_pagador = null";
            }
            if (!empty($Whatsapp)) {
                $updates[] = "Whatsapp = :Whatsapp";
            }else{
                $updates[] = "Whatsapp = null";
            }
            if (!empty($indicacao)) {
                $updates[] = "indicado_por = :indicacao";
            }else{
                $updates[] = "indicado_por = null";
            }
            if (($App == "SMART ONE" || $App == "IBO PLAYER PRO" || $App == "IBO PRO") && $mac !== 'não está presente') {
                if (!empty($mac)) {
                    $updates[] = "device_mac = :device_mac";
                }else{
                        $updates[] = "device_mac = null";
                    }
                if (!empty($validade_app)) {
                    $updates[] = "validade_app = :validade_app";
                }else{
                    $updates[] = "validade_app = null";
                }
            }
            if (($App == "IBO PLAYER PRO" || $App == "IBO PRO") && $key !== 'não está presente') {
                if (!empty($key)) {
                    $updates[] = "device_key = :device_key";
                }else{
                        $updates[] = "device_key = null";
                    }
            }
            if ($App == "ClouddY" && $email_app !== 'não está presente') {
                if (!empty($email_app)) {
                    $updates[] = "email_app = :email_app";
                }else{
                    $updates[] = "email_app = null";
                }
                if (!empty($senha_app)) {
                    $updates[] = "senha_app = :senha_app";
                }else{
                    $updates[] = "senha_app = null";
                }
                if (!empty($validade_app)) {
                    $updates[] = "validade_app = :validade_app";
                }else{
                    $updates[] = "validade_app = null";
                }
            }

            $sql_update .= implode(", ", $updates);
            $sql_update .= " WHERE id = :id AND admin_id = :admin_id";

            $stmt_update = $conexao->prepare($sql_update);

            if (!empty($adulto)) {
                $stmt_update->bindParam(':adulto', $adulto, PDO::PARAM_INT);
            }
            if (!empty($name)) {
                $stmt_update->bindParam(':name', $name, PDO::PARAM_STR);
            }
            if (!empty($usuario)) {
                $stmt_update->bindParam(':usuario', $usuario, PDO::PARAM_STR);
            }
            if (!empty($senha)) {
                $stmt_update->bindParam(':senha', $senha, PDO::PARAM_STR);
            }

            // Se fornecido, aplica o tipo de conteúdo (fonte) na atualização
            if (!empty($fonte)) {
                $stmt_update->bindParam(':fonte', $fonte, PDO::PARAM_STR);
            }
            if (!empty($plano)) {
                $stmt_update->bindParam(':plano', $plano, PDO::PARAM_INT);
            }
            if (isset($valor_plano) || $valor_plano === 0) {
                $stmt_update->bindParam(':valor_plano', $valor_plano);
            }
            if (!empty($Dispositivo)) {
                $stmt_update->bindParam(':Dispositivo', $Dispositivo, PDO::PARAM_STR);
            }
            if (!empty($App)) {
                $stmt_update->bindParam(':App', $App, PDO::PARAM_STR);
            }
            if (!empty($Forma_de_pagamento)) {
                $stmt_update->bindParam(':Forma_de_pagamento', $Forma_de_pagamento, PDO::PARAM_STR);
            }
            if (!empty($nome_do_pagador)) {
                $stmt_update->bindParam(':nome_do_pagador', $nome_do_pagador, PDO::PARAM_STR);
            }
            if (!empty($Whatsapp)) {
                $stmt_update->bindParam(':Whatsapp', $Whatsapp, PDO::PARAM_STR);
            }
            if (!empty($indicacao)) {
                $stmt_update->bindParam(':indicacao', $indicacao, PDO::PARAM_STR);
            }
            if (($App == "SMART ONE" || $App == "IBO PLAYER PRO" || $App == "IBO PRO") && $mac !== 'não está presente'){
                if (!empty($mac)) {
                    $stmt_update->bindParam(':device_mac', $mac, PDO::PARAM_STR);
                }
                if (!empty($validade_app)) {
                    $stmt_update->bindParam(':validade_app', $validade_app);
                }
            }
            if (($App == "IBO PLAYER PRO" || $App == "IBO PRO") && $key !== 'não está presente') {
                if (!empty($key)) {
                    $stmt_update->bindParam(':device_key', $key, PDO::PARAM_STR);
                }
            }
            if ($App == "ClouddY" && $email_app !== 'não está presente') {
                if (!empty($email_app)) {
                    $stmt_update->bindParam(':email_app', $email_app, PDO::PARAM_STR);
                }
                if (!empty($senha_app)) {
                    $stmt_update->bindParam(':senha_app', $senha_app, PDO::PARAM_STR);
                }
                if (!empty($validade_app)) {
                    $stmt_update->bindParam(':validade_app', $validade_app);
                }
            }

            $stmt_update->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt_update->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);

            if ($stmt_update->execute()) {
                $resposta['title'] = "Concluído!";
                $resposta['msg'] = "Cliente editado com sucesso";
                $resposta['icon'] = "success";
            } else {
                $resposta['title'] = "Erro!";
                $resposta['msg'] = "Erro ao editar cliente";
                $resposta['icon'] = "error";
            }

            return $resposta;
        } else {

            $resposta['title'] = "Erro!";
            $resposta['msg'] = "Cliente não encontrado";
            $resposta['icon'] = "error";
            return $resposta;
        }

}
function renovar_cliente($id, $usuario)
{

        $modal_body = "<input type=\"hidden\"  id=\"confirme_renovar_cliente\" name=\"confirme_renovar_cliente\" value='$id'></div>";
        $modal_body .= "<label>Renovar por:</label>";
        $modal_body .= "<input type='number' name='meses' class='form-control' id='renovar-meses' placeholder='meses' min='-3' value='1'>";
        $modal_body .= "<small class='form-text text-muted'>meses</small>";

        $modal_footer = "<button type='button' class='btn btn-info waves-effect waves-light ' onclick='enviardados(\"modal_master_form\", \"clientes.php\")'>Renovar</button>";

        $resposta = [
            'modal_header_class'=> "d-block modal-header bg-info text-white",
            'modal_titulo'=> "Renovar Cliente ($usuario)",
            'modal_body'=> $modal_body,
            'modal_footer'=> $modal_footer
        ];

    return $resposta;

}

function confirme_renovar_cliente($id, $meses)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.*,
                a.admin as admin, a.email as email, a.creditos as creditos,
                p.valor as valor
            FROM clientes c 
            LEFT JOIN admin a ON c.admin_id = a.id 
            LEFT JOIN planos p ON c.plano = p.id 
            WHERE c.id = :id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token);
        $stmt->execute();

    $resposta = []; 

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

        extract($row);

        $ultimopagamento = date("Y-m-d H:i:s");

        if ($meses < 0) {

            $nova_data = date("Y-m-d", strtotime("-" . abs($meses) . " month", strtotime($Vencimento)));
            $nova_data .= " 23:59:59";

        }else {

            $nova_data = date("Y-m-d", strtotime("$Vencimento +" . abs($meses) . " month"));

            if (strtotime($Vencimento) < strtotime(date("Y-m-d H:i:s"))) {

                $nova_data = date("Y-m-d", strtotime("+" . abs($meses) . " month"));
            }

            $nova_data .= " 23:59:59";
        }

        if ($admin == 1) {

            $sql_update ="UPDATE clientes SET Vencimento = '$nova_data', Ultimo_pagamento = '$ultimopagamento', V_total = '$valor' WHERE id = '$id'";

            if ($conexao->exec($sql_update)) {

                if ($meses > 0) {

                    $resposta['title'] = "Concluido! foi consumido ". $meses ." creditos";
                    $resposta['msg'] = "Cliente renovado com sucesso. Nova Data => ". date("d-m-Y H:i:s", strtotime($nova_data));
                    $resposta['icon'] = "success";
                    return $resposta;
                }else{

                        $resposta['title'] = "Concluido!";
                        $resposta['msg'] = $meses." mes removido . Nova Data => ". date("d-m-Y H:i:s", strtotime($nova_data));
                        $resposta['icon'] = "success";
                }

            }else{
                $resposta['title'] = "Erro!";
                $resposta['msg'] = "Nao foi possivel fazer a renovaçao";
                $resposta['icon'] = "error";
            }

        }elseif ($admin != 1 && $creditos >= 1 && $creditos>= $meses) {
            $sql_update ="UPDATE clientes SET Vencimento = '$nova_data', Ultimo_pagamento = '$ultimopagamento', V_total = '$valor' WHERE id = '$id'";
            if ($meses >= 0) {
                if ($conexao->exec($sql_update)) {

                    $sql_update = "UPDATE admin SET creditos = creditos - $meses WHERE id = '$admin_id'";

                    if ($conexao->exec($sql_update)) {

                        $resposta['title'] = "Concluido!";
                        $resposta['msg'] = "Cliente renovado com sucesso. Nova Data => ". $nova_data;
                        $resposta['icon'] = "success";
                    }
                }else{
                    $resposta['title'] = "Erro!";
                    $resposta['msg'] = "Nao foi possivel fazer a renovaçao";
                    $resposta['icon'] = "error";
                }

            }else{
                $resposta['title'] = "Aviso!";
                $resposta['msg'] = "voce nao tem permição para remover meses";
                $resposta['icon'] = "error";
            }

        }else{

            $resposta['title'] = "Erro!";
            $resposta['msg'] = "voce nao tem creditos suficientes";
            $resposta['icon'] = "error";

        }

        return $resposta;
    } else {
        return 0;
    }
}

function add_tempo($id, $usuario)
{

        $modal_body = "<input type=\"hidden\" name=\"confirme_add_tempo_clientes\" value='$id'></div>";
        $modal_body .= "<label>Adicionar Horas:</label>";
        $modal_body .= "<input type='number' name='tempo' class='form-control' id='tempo' placeholder='Tempo' min='-72' value='1'>";
        $modal_body .= "<small class='form-text text-muted'>Adicionar Tempo em (HORAS)</small>";

        $modal_footer = "<button type='button' class='btn btn-success waves-effect waves-light' onclick='enviardados(\"modal_master_form\", \"clientes.php\")'>Confirmar</button>";

        $resposta = [
            'modal_header_class'=> "d-block modal-header bg-success text-white",
            'modal_titulo'=> "Adicionar Tempo para ($usuario)",
            'modal_body'=> $modal_body,
            'modal_footer'=> $modal_footer
        ];

    return $resposta;
}

function confirme_add_tempo_clientes($id, $tempo)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $tempo = preg_replace("/[^0-9 ]/", "", $tempo);

    if ($tempo > 72) {
        $tempo = 72;
    }

    if ($tempo < -72) {
        $tempo = -72;
    }

    $sql = "SELECT c.*,
                a.admin as admin, a.creditos as creditos,
                p.valor as valor
            FROM clientes c 
            LEFT JOIN admin a ON c.admin_id = a.id 
            LEFT JOIN planos p ON c.plano = p.id 
            WHERE c.id = :id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token);
        $stmt->execute();

    $resposta = []; 

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

        extract($row);

        if ($tempo < 0) {

            $nova_data = date("Y-m-d H:i:s", strtotime("-" . abs($tempo) . " hour", strtotime($Vencimento)));

        }else {

            $nova_data = date("Y-m-d H:i:s", strtotime("$Vencimento +" . abs($tempo) . " hour"));

            if (strtotime($Vencimento) < strtotime(date("Y-m-d H:i:s"))) {

                $nova_data = date("Y-m-d H:i:s", strtotime("+" . abs($tempo) . " hour"));
            }
        }

        if ($admin == 1) {

            $sql_update = "UPDATE clientes SET Vencimento = :nova_data WHERE id = :id";
            $stmt = $conexao->prepare($sql_update);
            $stmt->bindParam(':nova_data', $nova_data);
            $stmt->bindParam(':id', $id);

            if ($stmt->execute()) {

                if ($tempo > 0) {

                    $resposta['title'] = "Concluido!";
                    $resposta['msg'] = "Foi Adicionado ".$tempo." hora(s). ";
                    $resposta['icon'] = "success";
                }else{

                    $resposta['title'] = "Concluido!";
                    $resposta['msg'] = "Foi Removido ".$tempo." hora(s). ";
                    $resposta['icon'] = "success";
                }
            }else{
                $resposta['title'] = "Erro!";
                $resposta['msg'] = "Nao foi possivel fazer a renovaçao";
                $resposta['icon'] = "error";
            }

        }elseif ($admin != 1 && $creditos >= 0) {
            $sql_update = "UPDATE clientes SET Vencimento = :nova_data WHERE id = :id";
            $stmt = $conexao->prepare($sql_update);
            $stmt->bindParam(':nova_data', $nova_data);
            $stmt->bindParam(':id', $id);

            if ($stmt->execute()) {

                if ($tempo < 0) {

                    $resposta['title'] = "Concluido!";
                    $resposta['msg'] = "Foi Removido ".$tempo." hora(s). ";
                    $resposta['icon'] = "success";

                }else{

                    $resposta['title'] = "Concluido!";
                    $resposta['msg'] = "Foi Adicionado ".$tempo." hora(s). ";
                    $resposta['icon'] = "success";

                }

            }else{

                $resposta['title'] = "Erro!";
                $resposta['msg'] = "Nao foi possivel adicionar tempo";
                $resposta['icon'] = "error";

            }
        }else{

            $resposta['title'] = "Erro!";
            $resposta['msg'] = "voce nao tem creditos suficientes";
            $resposta['icon'] = "error";

        }

        return $resposta;
    } else {
        return 0;
    }
}

function delete_cliente($id, $usuario)
{

        $modal_body = "<input type=\"hidden\"  name=\"confirme_delete_cliente\" value='$id'></div>";
        $modal_body .= "<input type=\"hidden\"  name=\"usuario\" value='$usuario'></div>";
        $modal_body .= "Tem certeza de que deseja excluir o cliente ($usuario) ?";

        $modal_footer = "<button type='button' class='btn btn-primary btn-sm' data-bs-dismiss='modal' aria-label='Close'>Cancelar</button><button type='button' class='btn btn-danger btn-sm' onclick='enviardados(\"modal_master_form\", \"clientes.php\")'>EXCLUIR</button>";

        $resposta = [
            'modal_header_class'=> "d-block modal-header bg-danger text-white",
            'modal_titulo'=> "EXCLUIR CLIENTE",
            'modal_body'=> $modal_body,
            'modal_footer'=> $modal_footer
        ];

    return $resposta;
}

function confirme_delete_cliente($id, $usuario)
{
    $conexao = conectar_bd();
    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    $sql = "SELECT c.*, a.id as admin_id
            FROM clientes c 
            LEFT JOIN admin a ON c.admin_id = a.id  
            WHERE c.id = :id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token);
        $stmt->execute();

    $resposta = []; 

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

        extract($row);

        $sql_delete = "DELETE FROM clientes WHERE id = '$id' and '$admin_id'";

        if ($conexao->exec($sql_delete)) {
            $resposta['title'] = "Sucesso!";
            $resposta['msg'] = "Cliente deletado com sucesso!";
            $resposta['icon'] = "success";
        } else {
            $resposta['title'] = "Erro!";
            $resposta['msg'] = "Erro ao deletar cliente.";
            $resposta['icon'] = "error";
        }

        return $resposta;
    } else {
        return 0;
    }
}

/**
 * Unifica as categorias de todos os servidores atribuídos ao cliente.  Esta função
 * foi criada para atender à necessidade de ter as mesmas categorias
 * disponíveis em todos os servidores quando o modo aleatório estiver
 * habilitado.  A implementação específica de sincronização de
 * categorias pode variar de acordo com a estrutura do painel e a
 * disponibilidade dos servidores; portanto, este método serve como um
 * ponto central de execução.  Atualmente, ele apenas retorna uma
 * mensagem de sucesso para indicar que a ação foi concluída.
 *
 * @param int $id ID do cliente
 * @return array
 */
function unificar_categorias_cliente($id)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";

    // Verifica se o cliente existe e pertence ao admin logado
    $sql = "SELECT c.id
            FROM clientes c
            JOIN admin a ON c.admin_id = a.id
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Cliente não encontrado.',
            'icon'  => 'error'
        ];
    }

    // Implementação de unificação de categorias duplicadas com o mesmo nome.
    // A tabela 'categoria' pode conter entradas com nomes iguais e IDs diferentes.
    // Para cada conjunto de nomes duplicados, escolhemos o menor ID como
    // referência e atualizamos todas as tabelas que referenciam as categorias
    // (streams e series) para usarem o ID principal. Em seguida, removemos
    // as entradas duplicadas. Isto garante que categorias de mesmo nome não
    // causem erros quando múltiplos servidores estiverem atribuídos ao cliente.
    try {
        // 1) Encontra grupos de categorias cujo nome (normalizado) se repete.
        // A normalização consiste em remover espaços nas extremidades e
        // converter para minúsculas, para que variações de capitalização
        // (ex: "Sport TV 1" vs "sport tv 1") sejam consideradas iguais.
        $sqlDup = "SELECT LOWER(TRIM(nome)) AS normalized_name, MIN(id) AS min_id
                    FROM categoria
                    GROUP BY normalized_name
                    HAVING COUNT(*) > 1";
        $stmtDup = $conexao->query($sqlDup);
        $duplicates = $stmtDup->fetchAll(PDO::FETCH_ASSOC);
        foreach ($duplicates as $dup) {
            $normalizedName = $dup['normalized_name'];
            $minId  = (int)$dup['min_id'];
            // Busca IDs duplicados para este nome normalizado, exceto o menor
            $stmtIds = $conexao->prepare("SELECT id FROM categoria WHERE LOWER(TRIM(nome)) = :normName AND id <> :minId");
            $stmtIds->bindParam(':normName', $normalizedName);
            $stmtIds->bindParam(':minId', $minId, PDO::PARAM_INT);
            $stmtIds->execute();
            $idsToMerge = $stmtIds->fetchAll(PDO::FETCH_COLUMN);
            if (!empty($idsToMerge)) {
                $in = implode(',', array_map('intval', $idsToMerge));
                // Atualiza todos os streams e séries que referenciam as categorias duplicadas
                $conexao->exec("UPDATE streams SET category_id = $minId WHERE category_id IN ($in)");
                $conexao->exec("UPDATE series SET category_id = $minId WHERE category_id IN ($in)");
                // Remove categorias duplicadas
                $conexao->exec("DELETE FROM categoria WHERE id IN ($in)");
            }
        }
        return [
            'title' => 'Concluído!',
            'msg'   => 'Categorias unificadas com sucesso.',
            'icon'  => 'success',
            'modal' => 'hide'
        ];
    } catch (Exception $e) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Falha ao unificar categorias: ' . $e->getMessage(),
            'icon'  => 'error'
        ];
    }
}

/**
 * Atualiza manualmente a data de vencimento de um cliente.
 * Permite que o administrador defina uma nova data e hora para
 * expiração do serviço. A data deve estar no formato 'Y-m-d H:i:s'.
 *
 * @param int $id ID do cliente
 * @param string $nova_data Nova data no formato YYYY-MM-DD HH:MM:SS
 * @return array Resultado da operação
 */
function update_vencimento_cliente($id, $nova_data)
{
    $conexao = conectar_bd();
    $token   = isset($_SESSION['token']) ? $_SESSION['token'] : "0";
    // Valida a data (timestamp) – se não for possível converter, retorna erro
    $timestamp = strtotime($nova_data);
    if ($timestamp === false) {
        return [
            'title' => 'Erro!',
            'msg'   => 'Data inválida fornecida.',
            'icon'  => 'error'
        ];
    }
    // Formata a data para MySQL
    $nova_data_fmt = date('Y-m-d H:i:s', $timestamp);
    $sql = "UPDATE clientes c
            JOIN admin a ON c.admin_id = a.id
            SET c.vencimento = :nova_data
            WHERE c.id = :id AND a.token = :token";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':nova_data', $nova_data_fmt, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    if ($stmt->execute()) {
        return [
            'title' => 'Concluído!',
            'msg'   => 'Data de vencimento atualizada com sucesso.',
            'icon'  => 'success',
            'modal' => 'hide'
        ];
    }
    return [
        'title' => 'Erro!',
        'msg'   => 'Não foi possível atualizar a data.',
        'icon'  => 'error'
    ];
}

function adicionar_clientes()
{
    function gerarValoresAleatorios() {

        $randomValue1 = substr(str_shuffle('0123456789'), 0, 6); 

        return $randomValue1;
    }

    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";
    $admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

    $sql = "SELECT a.id as admin_id, a.admin as administrador
            FROM admin a
            WHERE a.id = :admin_id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token);
        $stmt->execute();

    $option = "";
    if ($row = $stmt->fetch()) {

        $plano1 = $conexao->query("SELECT * FROM planos WHERE admin_id = '$admin_id'");
        $planoOptions = "";
        while ($lista_plano = $plano1->fetch()) {

            $planoOptions .= '<option value="'.$lista_plano['id'].'">'.$lista_plano['nome'].' [R$: '.$lista_plano['valor'].']</option>';

        }

        $stmt = $conexao->query("SELECT * FROM devices_apps");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $devices = array();
        foreach ($rows as $rows) {
          $deviceName = $rows['device_name'];
          $appName = $rows['app_name'];

          if (!isset($devices[$deviceName])) {
            $devices[$deviceName] = array();
          }

          $devices[$deviceName][] = array("name" => $appName);
        }

        $data = array("devices" => array());
        foreach ($devices as $deviceName => $apps) {
          $data["devices"][] = array("name" => $deviceName, "apps" => $apps);
        }

        $jsonData = json_encode($data);

        $modal_body = "";
        // Campo oculto para indicar que se trata de uma confirmação de criação de cliente
        $modal_body .= '<input type="hidden" id="confirme_adicionar_clientes" name="confirme_adicionar_clientes" value="">';
        // Nome do cliente
        $modal_body .= '<div class="form-group mb-3">'
                     . '<label for="name">Nome do cliente:</label>'
                     . '<input type="text" class="form-control" id="name" name="name" value="" autocomplete="off">'
                     . '</div>';
        // Linha para usuário e senha
        $modal_body .= '<div class="row mb-3">'
                     . '<div class="form-group col-md-6">'
                     . '<label for="usuario">Usuário</label>'
                     . '<input type="text" class="form-control" name="usuario" value="'.gerarValoresAleatorios().'" autocomplete="off">'
                     . '</div>'
                     . '<div class="form-group col-md-6">'
                     . '<label for="senha">Senha</label>'
                     . '<input type="text" class="form-control" name="senha" value="'.gerarValoresAleatorios().'" autocomplete="off">'
                     . '</div>'
                     . '</div>';
        // Conteúdo adulto
        $modal_body .= '<div class="form-group mb-3">'
                     . '<label for="adulto">Conteúdo adulto?</label>'
                     . '<select class="form-control form-select" name="adulto" id="adulto">'
                     . '<option value="0">NÃO</option>'
                     . '<option value="1">SIM</option>'
                     . '</select>'
                     . '</div>';
        // Plano
        $modal_body .= '<div class="form-group mb-3">'
                     . '<label for="plano">Plano:</label>'
                     . '<select class="form-control form-select" id="plano" name="plano">'
                     . $planoOptions
                     . '</select>'
                     . '</div>';
        // Número de telas
        $modal_body .= '<div class="form-group mb-3">'
                     . '<label for="conexoes_max">Número de telas:</label>'
                     . '<input type="number" class="form-control" id="conexoes_max" name="conexoes_max" min="1" max="50" value="1" placeholder="Quantidade de telas">'
                     . '</div>';
        // Duração
        $modal_body .= '<div class="form-group mb-3">'
                     . '<label for="duracao">Duração:</label>'
                     . '<select class="form-control form-select" id="duracao" name="duracao">'
                     . '<option value="30" selected>30 Dias</option>'
                     . '<option value="15">15 Dias (meio crédito por tela)</option>'
                     . '</select>'
                     . '</div>';
        // Tipo de conteúdo
        $modal_body .= '<div class="form-group mb-3">'
                     . '<label for="fonte">Tipo de conteúdo:</label>'
                     . '<select class="form-control form-select" id="fonte" name="fonte">'
                     . '<option value="completo" selected>Completo (Filmes e Séries)</option>'
                     . '<option value="filmes">Somente Filmes</option>'
                     . '<option value="series">Somente Séries</option>'
                     . '</select>'
                     . '</div>';

        // Ocultamos a seleção de dispositivo/aplicativo, pois ela não é necessária na criação de clientes.
        $modal_body .= '<div class="bform-row row" style="display:none;">';
            $modal_body .= '<div class="col-6 form-group">';
            $modal_body .= '<label for="Dispositivo">Dispositivo:</label>
            <select class="form-control form-select" id="Dispositivo" name="dispositivo">
                <option value="">Selecione um dispositivo</option>

            </select>';
            $modal_body .= '</div>';
            $modal_body .= '<div class="col-6 form-group">';
            $modal_body .= '<label for="App">App:</label>
            <select class="form-control form-select" id="App" name="app">
            <option value="">Selecione um app</option>
            </select>';
            $modal_body .= '</div>';
        $modal_body .= '</div>';
        // Ocultamos os campos de forma de pagamento, pagador, WhatsApp, indicação e detalhes do dispositivo,
        // pois estes não são necessários durante a criação do cliente. Ainda assim, os mantemos no DOM para
        // não quebrar a lógica de back-end e scripts existentes.
        $modal_body .= '<div class="form-group" style="display:none;">\n'
                        . '<label for="Forma-de-pagamento">Forma de pagamento:</label>\n'
                        . '<select class="form-control form-select" id="forma-de-pagamento" name="forma-de-pagamento">\n'
                        . '<option value="PIX">PIX</option>\n'
                        . '<option value="boleto">Boleto</option>\n'
                        . '</select>\n'
                        . '</div>';
        $modal_body .= '<div class="form-group" style="display:none;">\n'
                        . '<label for="nome-do-pagador">Nome do pagador:</label>\n'
                        . '<input type="text" class="form-control" id="nome-do-pagador" name="nome-do-pagador" value="" placeholder="Exemplo: josé joão da silva" autocomplete="off">\n'
                        . '</div>';
        $modal_body .= '<div class="form-group" style="display:none;">\n'
                        . '<label for="Whatsapp">Whatsapp:</label>\n'
                        . '<input type="text" class="form-control" id="Whatsapp" name="whatsapp" value="" placeholder="Exemplo: +55 11 99999-9999" autocomplete="off">\n'
                        . '</div>';
        $modal_body .= '<div class="form-group" style="display:none;">\n'
                        . '<label for="indicacao">Indicado por:</label>\n'
                        . '<input type="text" class="form-control" id="indicacao" name="indicacao" value="" placeholder="Coloque o ID do Usuário que fez a indicação" autocomplete="off">\n'
                        . '</div>';
        // Mesmo ocultos, mantemos os campos de MAC e Device Key para compatibilidade com o script de dispositivos
        $modal_body .= '<div class="form-group" style="display:none;">\n'
                        . '<label for="device_mac">MAC:</label>\n'
                        . '<input type="text" class="form-control" id="device_mac" maxlength="17" name="device_mac" value="" placeholder="Exemplo:  D4:1B:11:22:B0:44 ou D41B1122B044" autocomplete="off" disabled>\n'
                        . '</div>';
        $modal_body .= '<div class="form-group" style="display:none;">\n'
                        . '<label for="device_key">Device key:</label>\n'
                        . '<input type="text" class="form-control" id="device_key" name="device_key" value="" placeholder="Exemplo:  112233" autocomplete="off" disabled>\n'
                        . '</div>';

        $modal_body .= '<script>
  var data = ' . $jsonData . ';
  data.devices.forEach(device => {
    const option = document.createElement("option");
    option.value = device.name;
    option.text = device.name;
    document.querySelector("#Dispositivo").appendChild(option);
  });

  document.querySelector("#Dispositivo").addEventListener("change", function () {
    const selectedDevice = data.devices.find(device => device.name === this.value);
    document.querySelector("#App").innerHTML = "";
    const option = document.createElement("option");
    option.value = "";
    option.text = "Selecione um app";
    document.querySelector("#App").appendChild(option);
    if (selectedDevice) {
      selectedDevice.apps.forEach(app => {
        const option = document.createElement("option");
        option.value = app.name;
        option.text = app.name;
        option.dataset.deviceType = app.deviceType; 
        document.querySelector("#App").appendChild(option);
      });
    }
  });

  document.querySelector("#App").addEventListener("change", function () {
    const selectedApp = this.value;
    const deviceMacInput = document.querySelector("#device_mac");
    const deviceKeyInput = document.querySelector("#device_key");

    deviceMacInput.value = "";
    deviceKeyInput.value = "";

    deviceMacInput.disabled = true;
    deviceKeyInput.disabled = true;

    if (selectedApp === "SMART ONE") {
        deviceMacInput.disabled = false;
    } else if (selectedApp === "IBO PLAYER PRO" || selectedApp === "IBO PRO") {
        deviceMacInput.disabled = false;
        deviceKeyInput.disabled = false;
    }
    });</script>';

        $modal_footer = "<button type='button' class='btn btn-outline-danger btn-sm' data-bs-dismiss='modal' aria-label='Close'>Cancelar</button><button type='button' class='btn btn-primary btn-sm' onclick='enviardados(\"modal_master_form\", \"clientes.php\")'>Adicionar</button>";

        $resposta = [
            'modal_header_class'=> "d-block modal-header bg-primary text-white",
            'modal_titulo'=> "Preencha com os dados do cliente",
            'modal_body'=> $modal_body,
            'modal_footer'=> $modal_footer
        ];

        return $resposta;
    } else {
        return 0;
    }
}

function confirme_adicionar_clientes($name, $usuario, $senha, $adulto, $plano, $Dispositivo, $App, $Forma_de_pagamento, $nome_do_pagador, $Whatsapp, $indicacao, $mac, $key, $conexoes_max, $duracao, $fonte)
{
    $conexao = conectar_bd();

    $token = isset($_SESSION['token']) ? $_SESSION['token'] : "0";
    $admin_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

    $name = preg_replace("/[^a-zA-Z0-9 ]/", "", $name);
    $usuario = preg_replace("/[^a-zA-Z0-9]/", "", $usuario);
    $senha = preg_replace("/[^a-zA-Z0-9]/", "", $senha);
    $adulto = preg_replace("/[^0-9]/", "", $adulto);
    $plano = preg_replace("/[^0-9]/", "", $plano);
    $Dispositivo = preg_replace("/[^a-zA-Z0-9 ]/", "", $Dispositivo);
    $App = preg_replace("/[^a-zA-Z0-9 ]/", "", $App);
    $Forma_de_pagamento = preg_replace("/[^a-zA-Z0-9]/", "", $Forma_de_pagamento);
    $nome_do_pagador = preg_replace("/[^a-zA-Z0-9 ]/", "", $nome_do_pagador);

    if ($mac == 'não está presente') {
        $mac = null;
    }elseif($mac == 'vazio') {
        $mac = null;
    }else{
        $mac = preg_replace("/[^a-zA-Z0-9:]/", "", $mac);

        $mac_formatado = preg_replace('/[^a-fA-F0-9]/', '', $mac);

        $mac = strtoupper(implode(':', str_split($mac_formatado, 2)));
    }

    if ($key == 'não está presente') {
        $key = null;
    }elseif($key == 'vazio') {
        $key = null;
    }else{
        $key = preg_replace("/[^0-9]/", "", $key);
        $key = is_numeric($key) ? $key : null; 
    }

    // Sanitiza e limita o número máximo de conexões (telas) permitido para o cliente
    $conexoes_max = preg_replace("/[^0-9]/", "", $conexoes_max);
    if (empty($conexoes_max) || $conexoes_max < 1) {
        $conexoes_max = 1;
    } elseif ($conexoes_max > 50) {
        $conexoes_max = 50;
    }

    // Sanitiza a duração e define padrão de 30 dias caso valor inesperado. Permitimos 15 ou 30 dias.
    $duracao = preg_replace("/[^0-9]/", "", $duracao);
    if ($duracao != '15' && $duracao != '30') {
        $duracao = '30';
    }
    // Sanitiza o tipo de conteúdo (fonte). Aceita valores: filmes, series ou completo. Default completo.
    $fonte = preg_replace("/[^a-zA-Z]/", "", strtolower($fonte));
    if ($fonte !== 'filmes' && $fonte !== 'series' && $fonte !== 'completo') {
        $fonte = 'completo';
    }

    if (!empty($Whatsapp)) {
        $Whatsapp = preg_replace("/[^0-9+]/", "", $Whatsapp); 
        $Whatsapp = is_numeric($Whatsapp) ? $Whatsapp : null; 
    } else {
        $Whatsapp = null; 
    }

    if (!empty($indicacao)) {
        $indicacao = preg_replace("/[^0-9]/", "", $indicacao); 
        $indicacao = is_numeric($indicacao) ? $indicacao : null; 
    } else {
        $indicacao = null; 
    }

    $sql = "SELECT a.id as admin_id, a.admin as admin, a.creditos as creditos,
                p.valor as valor
            FROM admin a 
            LEFT JOIN planos p ON p.id = :plano
            WHERE a.id = :admin_id AND a.token = :token";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':plano', $plano);
        $stmt->execute();

    $resposta = []; 

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

        extract($row);

        $sql_check = "SELECT id FROM clientes WHERE usuario = :usuario";
        $stmt_check = $conexao->prepare($sql_check);
        $stmt_check->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmt_check->execute();

        if ($stmt_check->fetch(PDO::FETCH_ASSOC)) {

            $resposta['title'] = "Erro!";
            $resposta['msg'] = "Cliente já cadastrado";
            $resposta['icon'] = "error";
            return $resposta;
        }
        $dataAtual = date("Y-m-d H:i:s");
        // Define vencimento conforme a duração escolhida. Para 30 dias, usamos 30 dias a partir da data atual;
        // para 15 dias, adicionamos 15 dias. O horário é fixado para o fim do dia (23:59:59).
        if ($duracao == '15') {
            $vencimento = date("Y-m-d", strtotime("+15 days")) . " 23:59:59";
        } else {
            // 30 dias
            $vencimento = date("Y-m-d", strtotime("+30 days")) . " 23:59:59";
        }

        $sql_insert = "INSERT INTO clientes (name, usuario, senha, Criado_em, Ultimo_pagamento, vencimento, admin_id, adulto, plano, V_total, c_ocultar_fonte, Dispositivo, App, Forma_de_pagamento, nome_do_pagador, Whatsapp, indicado_por, device_mac, device_key, conexoes_max) 
                        VALUES (:name, :usuario, :senha, :Criado_em, :Ultimo_pagamento, :vencimento, :admin_id, :adulto, :plano, :V_total, :fonte, :Dispositivo, :App, :Forma_de_pagamento, :nome_do_pagador, :Whatsapp, :indicacao, :mac, :chavekay, :conexoes_max)";
        $stmt_insert = $conexao->prepare($sql_insert);

        $stmt_insert->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt_insert->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmt_insert->bindParam(':senha', $senha, PDO::PARAM_STR);
        $stmt_insert->bindValue(':Criado_em', date("Y-m-d H:i:s"), PDO::PARAM_STR);
        $stmt_insert->bindValue(':Ultimo_pagamento', date("Y-m-d H:i:s"), PDO::PARAM_STR);
        $stmt_insert->bindParam(':vencimento', $vencimento, PDO::PARAM_STR);
        $stmt_insert->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
        $stmt_insert->bindParam(':adulto', $adulto, PDO::PARAM_INT);
        $stmt_insert->bindParam(':plano', $plano, PDO::PARAM_INT);
        $stmt_insert->bindParam(':V_total', $valor, PDO::PARAM_INT);
        // Tipo de conteúdo selecionado (filmes, séries ou completo)
        $stmt_insert->bindParam(':fonte', $fonte, PDO::PARAM_STR);
        $stmt_insert->bindParam(':Dispositivo', $Dispositivo, PDO::PARAM_STR);
        $stmt_insert->bindParam(':App', $App, PDO::PARAM_STR);
        $stmt_insert->bindParam(':Forma_de_pagamento', $Forma_de_pagamento, PDO::PARAM_STR);
        $stmt_insert->bindParam(':nome_do_pagador', $nome_do_pagador, PDO::PARAM_STR);
        $stmt_insert->bindParam(':Whatsapp', $Whatsapp, PDO::PARAM_STR);
        $stmt_insert->bindParam(':indicacao', $indicacao, PDO::PARAM_INT);
        $stmt_insert->bindParam(':mac', $mac, PDO::PARAM_STR);
        $stmt_insert->bindParam(':chavekay', $key, PDO::PARAM_STR);
        $stmt_insert->bindParam(':conexoes_max', $conexoes_max, PDO::PARAM_INT);
        // Novo parâmetro para o tipo de conteúdo (filmes, séries ou completo)
        $stmt_insert->bindParam(':fonte', $fonte, PDO::PARAM_STR);

        if ($admin == 1) {

            if ($stmt_insert->execute()) {
                $resposta['title'] = "Concluído!";
                $resposta['msg'] = "Cliente inserido com sucesso";
                $resposta['icon'] = "success";
                // Gera link M3U para cópia imediata. O link utiliza o host atual e o novo usuário/senha.
                $link_m3u = 'http://' . $_SERVER['HTTP_HOST'] . '/get.php?username=' . $usuario . '&password=' . $senha . '&type=m3u_plus&output=ts';
                $resposta['link_m3u'] = $link_m3u;
                $resposta['username'] = $usuario;
                $resposta['password'] = $senha;
            } else {
                $resposta['title'] = "Erro!";
                $resposta['msg'] = "Erro ao inserir cliente";
                $resposta['icon'] = "error";
            }
        } elseif ($admin != 1) {
            /*
             * Para revendedores (admin != 1), o custo de criação de um cliente deve ser
             * proporcional ao número de telas solicitadas. Antes de deduzir créditos,
             * verificamos se o revendedor possui créditos suficientes para cobrir o
             * total de conexões máximas. Se não houver créditos suficientes,
             * retornamos um erro. Caso contrário, inserimos o cliente e deduzimos
             * o valor correspondente de créditos.
             */
            // Calcula o número de créditos necessários.  Cada tela custa 1 crédito para 30 dias ou 0,5 crédito para 15 dias.
            $telasNecessarias = (float)$conexoes_max * (($duracao == '15') ? 0.5 : 1.0);
            // Converte créditos e telas para float para comparação adequada, evitando perdas de precisão
            if ((float)$creditos < $telasNecessarias) {
                // créditos insuficientes
                $resposta['title'] = "Erro!";
                $resposta['msg']   = "Você não tem créditos suficientes";
                $resposta['icon']  = "error";
            } else {
                if ($stmt_insert->execute()) {
                    // Deduz o número de telas solicitadas dos créditos do revendedor
                    $sql_update_creditos = "UPDATE admin SET creditos = creditos - :telas WHERE id = :admin_id";
                    $stmt_credito = $conexao->prepare($sql_update_creditos);
                    // Utiliza PARAM_STR para permitir valores decimais ao debitar meio crédito
                    $stmt_credito->bindParam(':telas', $telasNecessarias, PDO::PARAM_STR);
                    $stmt_credito->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
                    if ($stmt_credito->execute()) {
                        $resposta['title'] = "Concluído!";
                        $resposta['msg']   = "Cliente inserido com sucesso";
                        $resposta['icon']  = "success";
                    } else {
                        // Caso raro: inserção ocorreu mas não conseguiu descontar créditos
                        $resposta['title'] = "Aviso!";
                        $resposta['msg']   = "Cliente inserido, mas não foi possível deduzir créditos.";
                        $resposta['icon']  = "warning";
                    }
                } else {
                    $resposta['title'] = "Erro!";
                    $resposta['msg']   = "Erro ao inserir cliente";
                    $resposta['icon']  = "error";
                }
            }
        } else {
            $resposta['title'] = "Erro!";
            $resposta['msg']   = "Você não tem créditos suficientes";
            $resposta['icon']  = "error";
        }

        return $resposta;
    } else {
        return 0;
    }
}