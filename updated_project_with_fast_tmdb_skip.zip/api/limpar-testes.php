<?php
/**
 * Endpoint para remover clientes em modo de teste (trial) que estejam expirados.
 *
 * Este script deve ser acessado via POST e somente por administradores (nivel_admin = 1).
 * Ele consulta a tabela `clientes` procurando registros com is_trial = 1 e
 * data de vencimento anterior à data/hora atual. Os registros encontrados
 * são removidos permanentemente. O resultado é retornado em formato JSON
 * com mensagem de sucesso ou erro.
 */
session_start();
require_once('./controles/db.php');
require_once('./controles/checkLogout.php');

header('Content-Type: application/json; charset=utf-8');

// Garante que a sessão esteja válida
checkLogoutapi();

// Apenas administradores podem realizar esta operação
if (!isset($_SESSION['nivel_admin']) || (int)$_SESSION['nivel_admin'] !== 1) {
    echo json_encode([
        'title' => 'Acesso negado',
        'msg'   => 'Você não tem permissão para executar esta operação.',
        'icon'  => 'error'
    ]);
    exit;
}

// Permite apenas chamadas POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'title' => 'Método inválido',
        'msg'   => 'Requisições devem ser feitas com método POST.',
        'icon'  => 'error'
    ]);
    exit;
}

try {
    $con = conectar_bd();
    if (!$con) {
        throw new Exception('Falha ao conectar ao banco de dados');
    }
    /*
     * Para administradores (nivel_admin = 1) removemos todos os testes
     * expirados da tabela clientes, independentemente de quem seja o
     * proprietário. Isso garante que os testes vencidos sejam limpos
     * em todos os painéis, inclusive dos revendedores.  O filtro
     * anterior baseado no admin_id restringia a exclusão apenas aos
     * clientes do administrador atual, o que fazia com que os testes
     * permanecessem visíveis para os outros revendedores.  Agora
     * realizamos a contagem e exclusão de maneira global.
     */
    // Conta quantos testes expirados existem antes de deletar
    $stmtCount = $con->prepare('SELECT COUNT(*) FROM clientes WHERE is_trial = 1 AND Vencimento < NOW()');
    $stmtCount->execute();
    $quantidade = (int)$stmtCount->fetchColumn();
    // Remove os clientes em teste cuja data de vencimento já passou
    $stmtDelete = $con->prepare('DELETE FROM clientes WHERE is_trial = 1 AND Vencimento < NOW()');
    $stmtDelete->execute();
    echo json_encode([
        'title' => 'Concluído!',
        'msg'   => $quantidade . ' teste(s) expirado(s) removido(s) com sucesso.',
        'icon'  => 'success'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'title' => 'Erro!',
        'msg'   => $e->getMessage(),
        'icon'  => 'error'
    ]);
}
exit;