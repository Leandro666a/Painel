<?php
// Endpoint para retornar a lista de clientes online em tempo real.
// Esta rota permite que o painel atualize a contagem de usuários
// online e testes online via AJAX, evitando que o administrador
// precise recarregar a página para ver as informações atualizadas.

session_start();
require_once('./controles/db.php');
require_once('./controles/checkLogout.php');
require_once('../functions.php');

// Define o cabeçalho da resposta como JSON
header('Content-Type: application/json; charset=utf-8');

// Verifica se a sessão ainda é válida antes de prosseguir
checkLogoutapi();

// Identifica o administrador logado, se existir, para filtrar os
// usuários online pertencentes a este revendedor.  Caso seja
// administrador master, a lista retornará todos os usuários.
$adminId = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

// Recupera a lista de usuários online usando a função de apoio
$dadosOnline = obter_usuarios_online($adminId);

// Envia a resposta em formato JSON
echo json_encode($dadosOnline);
exit();