<?php
/**
 * API para gerenciamento de mensagens enviadas pelo administrador aos
 * revendedores.  Fornece três ações principais:
 *  - enviar: somente administradores (nivel_admin = 1) podem enviar
 *    mensagens.  Para cada destinatário informado (ou para todos os
 *    revendedores) é inserido um registro na tabela mensagens.
 *  - obter: revendedores consultam suas mensagens não lidas.  Retorna um
 *    array JSON com id, título, mensagem e data de envio.
 *  - ler: revendedores marcam uma mensagem como lida.  Atualiza o
 *    registro na tabela para não exibir novamente.
 *
 * A tabela `mensagens` é criada automaticamente caso ainda não exista.
 */
session_start();
require_once('./controles/db.php');
require_once('./controles/checkLogout.php');

header('Content-Type: application/json; charset=utf-8');

// Garante que a sessão esteja válida
checkLogoutapi();

// Função utilitária para responder JSON e encerrar a execução
function respond($data) {
    echo json_encode($data);
    exit;
}

// Recupera o corpo JSON da requisição, se houver
$rawInput = file_get_contents('php://input');
$inputData = [];
if ($rawInput) {
    $parsed = json_decode($rawInput, true);
    if (is_array($parsed)) {
        $inputData = $parsed;
    }
}

// Determina a ação com base no corpo JSON, no POST ou no GET
$action = '';
if (isset($inputData['action'])) {
    $action = $inputData['action'];
} elseif (isset($_POST['action'])) {
    $action = $_POST['action'];
} elseif (isset($_GET['action'])) {
    $action = $_GET['action'];
}

// Abre conexão com o banco
$con = conectar_bd();
if (!$con) {
    respond([
        'title' => 'Erro!',
        'msg'   => 'Não foi possível conectar ao banco de dados.',
        'icon'  => 'error'
    ]);
}

// Cria a tabela mensagens caso não exista.  Essa tabela armazena
// mensagens por destinatário e registra se cada mensagem foi lida ou não.
$createTableSql = "CREATE TABLE IF NOT EXISTS mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    revendedor_id INT NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    mensagem TEXT NOT NULL,
    data_envio DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    lida TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

try {
    $con->exec($createTableSql);
} catch (Exception $e) {
    // Ignora erros de criação de tabela aqui; eles serão capturados nas
    // operações subsequentes
}

// Manipula as ações
switch ($action) {
    case 'enviar':
        // Apenas administradores podem enviar mensagens
        if (!isset($_SESSION['nivel_admin']) || (int)$_SESSION['nivel_admin'] !== 1) {
            respond([
                'title' => 'Acesso negado',
                'msg'   => 'Somente administradores podem enviar mensagens.',
                'icon'  => 'error'
            ]);
        }
        $destino  = '';
        $titulo   = '';
        $mensagem = '';
        // Lê dados de acordo com o formato de envio (JSON ou form-data)
        if (!empty($inputData)) {
            $destino  = isset($inputData['destino'])  ? $inputData['destino']  : '';
            $titulo   = isset($inputData['titulo'])   ? trim($inputData['titulo'])   : '';
            $mensagem = isset($inputData['mensagem']) ? trim($inputData['mensagem']) : '';
        } else {
            $destino  = isset($_POST['destino'])  ? $_POST['destino']  : '';
            $titulo   = isset($_POST['titulo'])   ? trim($_POST['titulo'])   : '';
            $mensagem = isset($_POST['mensagem']) ? trim($_POST['mensagem']) : '';
        }
        if ($titulo === '' || $mensagem === '') {
            respond([
                'title' => 'Dados inválidos',
                'msg'   => 'Informe um título e uma mensagem.',
                'icon'  => 'warning'
            ]);
        }
        // Identificador do administrador remetente
        $adminId = isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : 0;
        if ($adminId <= 0) {
            respond([
                'title' => 'Erro',
                'msg'   => 'ID do administrador inválido.',
                'icon'  => 'error'
            ]);
        }
        try {
            // Caso o destino seja "todos", buscamos todos os revendedores (admin != 1)
            if ($destino === 'todos') {
                $stmt = $con->prepare('SELECT id FROM admin WHERE admin != 1');
                $stmt->execute();
                $revendedores = $stmt->fetchAll(PDO::FETCH_COLUMN);
                $inseridos = 0;
                foreach ($revendedores as $rid) {
                    $stmtIns = $con->prepare('INSERT INTO mensagens (admin_id, revendedor_id, titulo, mensagem) VALUES (:admin_id, :revendedor_id, :titulo, :mensagem)');
                    $stmtIns->bindValue(':admin_id', $adminId, PDO::PARAM_INT);
                    $stmtIns->bindValue(':revendedor_id', $rid, PDO::PARAM_INT);
                    $stmtIns->bindValue(':titulo', $titulo, PDO::PARAM_STR);
                    $stmtIns->bindValue(':mensagem', $mensagem, PDO::PARAM_STR);
                    $stmtIns->execute();
                    $inseridos++;
                }
                respond([
                    'title' => 'Mensagem enviada',
                    'msg'   => 'A mensagem foi enviada para ' . $inseridos . ' revendedor(es).',
                    'icon'  => 'success'
                ]);
            } else {
                // Envia mensagem para revendedor específico
                $revendedorId = (int)$destino;
                if ($revendedorId <= 0) {
                    respond([
                        'title' => 'Destinatário inválido',
                        'msg'   => 'Selecione um revendedor válido ou escolha Todos.',
                        'icon'  => 'warning'
                    ]);
                }
                // Verifica se o revendedor existe e não é um administrador
                $stmt = $con->prepare('SELECT id FROM admin WHERE id = :id AND admin != 1');
                $stmt->bindValue(':id', $revendedorId, PDO::PARAM_INT);
                $stmt->execute();
                if ($stmt->rowCount() === 0) {
                    respond([
                        'title' => 'Destinatário inválido',
                        'msg'   => 'O revendedor informado não existe.',
                        'icon'  => 'warning'
                    ]);
                }
                $stmtIns = $con->prepare('INSERT INTO mensagens (admin_id, revendedor_id, titulo, mensagem) VALUES (:admin_id, :revendedor_id, :titulo, :mensagem)');
                $stmtIns->bindValue(':admin_id', $adminId, PDO::PARAM_INT);
                $stmtIns->bindValue(':revendedor_id', $revendedorId, PDO::PARAM_INT);
                $stmtIns->bindValue(':titulo', $titulo, PDO::PARAM_STR);
                $stmtIns->bindValue(':mensagem', $mensagem, PDO::PARAM_STR);
                $stmtIns->execute();
                respond([
                    'title' => 'Mensagem enviada',
                    'msg'   => 'Mensagem enviada com sucesso para o revendedor selecionado.',
                    'icon'  => 'success'
                ]);
            }
        } catch (Exception $e) {
            respond([
                'title' => 'Erro',
                'msg'   => $e->getMessage(),
                'icon'  => 'error'
            ]);
        }
        break;

    case 'obter':
        // Revendedores consultam suas mensagens não lidas
        if (!isset($_SESSION['admin_id'])) {
            respond(['mensagens' => []]);
        }
        // Não exibe mensagens para administradores; retorna lista vazia
        if (isset($_SESSION['nivel_admin']) && (int)$_SESSION['nivel_admin'] === 1) {
            respond(['mensagens' => []]);
        }
        $revendedorId = (int)$_SESSION['admin_id'];
        try {
            $stmt = $con->prepare('SELECT id, titulo, mensagem, DATE_FORMAT(data_envio, "%d/%m/%Y %H:%i:%s") AS data_envio FROM mensagens WHERE revendedor_id = :revendedor_id AND lida = 0 ORDER BY data_envio ASC');
            $stmt->bindValue(':revendedor_id', $revendedorId, PDO::PARAM_INT);
            $stmt->execute();
            $msgs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            respond(['mensagens' => $msgs]);
        } catch (Exception $e) {
            respond(['mensagens' => []]);
        }
        break;

    case 'ler':
        // Marca uma mensagem como lida
        if (!isset($_SESSION['admin_id'])) {
            respond(['success' => false]);
        }
        // Revendedores podem marcar mensagens; administradores não precisam
        if (isset($_SESSION['nivel_admin']) && (int)$_SESSION['nivel_admin'] === 1) {
            respond(['success' => true]);
        }
        $msgId = 0;
        if (!empty($inputData)) {
            $msgId = isset($inputData['id']) ? (int)$inputData['id'] : 0;
        } elseif (isset($_POST['id'])) {
            $msgId = (int)$_POST['id'];
        }
        if ($msgId <= 0) {
            respond(['success' => false]);
        }
        $revendedorId = (int)$_SESSION['admin_id'];
        try {
            $stmt = $con->prepare('UPDATE mensagens SET lida = 1 WHERE id = :id AND revendedor_id = :revendedor_id');
            $stmt->bindValue(':id', $msgId, PDO::PARAM_INT);
            $stmt->bindValue(':revendedor_id', $revendedorId, PDO::PARAM_INT);
            $stmt->execute();
            respond(['success' => true]);
        } catch (Exception $e) {
            respond(['success' => false]);
        }
        break;

    default:
        // Ação desconhecida ou nenhuma ação definida
        respond(['mensagens' => []]);
        break;
}