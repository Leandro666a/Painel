<?php
// Endpoint AJAX para exibir detalhes de clientes online em um modal.
// Este arquivo responde às chamadas realizadas via modal_master no dashboard.

session_start();
require_once('./controles/db.php');
require_once('./controles/checkLogout.php');
// functions.php está fora do diretório api, portanto usa-se caminho relativo
require_once('../functions.php');

header('Content-Type: application/json; charset=utf-8');

// Verifica se a sessão ainda é válida
checkLogoutapi();

// Trata requisição de detalhes de clientes online
if (isset($_POST['detalhes_online'])) {
    // Recupera o ID do administrador logado
    $adminId = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : null;

    if (function_exists('obter_detalhes_online')) {
        $lista = obter_detalhes_online($adminId);
        // Constrói a tabela com os dados retornados
        $table = '<div class="table-responsive" style="max-height: 60vh; overflow-y: auto;">';
        // Usa table-dark para melhor legibilidade em temas escuros
        $table .= '<table class="table table-dark table-striped table-bordered">';
        $table .= '<thead><tr>';
        $table .= '<th>Usuário</th><th>Nome</th><th>Assistindo</th><th>Última atividade</th><th>Tempo assistindo</th><th>Cidade</th><th>Provedor</th>';
        $table .= '</tr></thead><tbody>';
        foreach ($lista as $item) {
            $table .= '<tr>';
            $table .= '<td>' . htmlspecialchars($item['usuario'], ENT_QUOTES, 'UTF-8') . '</td>';
            $table .= '<td>' . htmlspecialchars($item['nome'], ENT_QUOTES, 'UTF-8') . '</td>';
            $table .= '<td>' . htmlspecialchars($item['assistindo'], ENT_QUOTES, 'UTF-8') . '</td>';
            $table .= '<td>' . htmlspecialchars($item['ultima'], ENT_QUOTES, 'UTF-8') . '</td>';
            // Exibe o tempo assistindo; se estiver vazio, mostra o tempo desde a última atividade como fallback
            $tempoAssistindo = !empty($item['tempo_assistindo']) ? $item['tempo_assistindo'] : $item['tempo_desde_ultima'];
            $table .= '<td>' . htmlspecialchars($tempoAssistindo, ENT_QUOTES, 'UTF-8') . '</td>';
            $table .= '<td>' . htmlspecialchars($item['cidade'], ENT_QUOTES, 'UTF-8') . '</td>';
            $table .= '<td>' . htmlspecialchars($item['provedor'], ENT_QUOTES, 'UTF-8') . '</td>';
            $table .= '</tr>';
        }
        $table .= '</tbody></table></div>';

        $response = [
            'modal_titulo'      => 'Clientes Online Detalhado',
            'modal_header_class' => 'modal-header bg-primary text-white',
            'modal_body'        => $table,
            'modal_footer'      => '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>',
            // Define icon apenas para manter compatibilidade com SweetAlert
            'icon'             => 'info'
        ];
        echo json_encode($response);
        exit();
    } else {
        $resposta = [
            'title' => 'Erro!',
            'msg'   => 'Função obter_detalhes_online não encontrada.',
            'icon'  => 'error'
        ];
        echo json_encode($resposta);
        exit();
    }
}

// Caso nenhum parâmetro esperado seja fornecido, retorna erro genérico
$resposta = [
    'title' => 'Erro!',
    'msg'   => 'Requisição inválida.',
    'icon'  => 'error'
];
echo json_encode($resposta);
exit();