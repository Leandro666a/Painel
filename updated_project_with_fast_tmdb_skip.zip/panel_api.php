<?php
header('Content-Type: text/plain; charset=UTF-8');  // Resposta em texto, mas com conteúdo JSON
header('Access-Control-Allow-Origin: *'); // Permite requisições de qualquer origem


// Conecta-se ao banco de dados de usuários
require_once($_SERVER['DOCUMENT_ROOT'] . '/api/controles/db.php');
// Inclui funções auxiliares, como registrar_conexao().
require_once(__DIR__ . '/functions.php');

date_default_timezone_set('America/Sao_Paulo');
$username = isset($_GET['username']) ? $_GET['username'] : null;
$password = isset($_GET['password']) ? $_GET['password'] : null;

//Autenticação /player_api.php?username=X&password=X
if (!$username || !$password) {
    http_response_code(401); // 401 Unauthorized
   $errorResponse['user_info'] = array();
   $errorResponse['user_info']['auth'] = 0;
   $errorResponse['user_info']['msg'] = "username e password necessario!";
    echo json_encode($errorResponse);
    exit();
}

// Conexão com o banco de dados
$conexao = conectar_bd();

// Busca os dados do usuário
$query = "SELECT * FROM clientes WHERE usuario = :username AND senha = :password";
$statement = $conexao->prepare($query);
$statement->bindValue(':username', $username);
$statement->bindValue(':password', $password);
$statement->execute();
$result = $statement->fetch(PDO::FETCH_ASSOC);

if (!$result) {
    http_response_code(401); // 401 Unauthorized
    echo json_encode([["auth" => 0]]);
    exit();
}

// Verifica se o cliente ou o revendedor estão bloqueados. Caso afirmativo, responde
// com 401 Unauthorized e encerra a execução.  Consulta a coluna 'bloqueado' na
// tabela clientes e, se necessário, na tabela admin.
try {
    $clienteBloqueado = isset($result['bloqueado']) && (int)$result['bloqueado'] === 1;
    $adminBloqueado   = false;
    if (!$clienteBloqueado) {
        $stmt_admin = $conexao->prepare('SELECT bloqueado FROM admin WHERE id = :adminId');
        $stmt_admin->bindParam(':adminId', $result['admin_id']);
        $stmt_admin->execute();
        $adminRow = $stmt_admin->fetch(PDO::FETCH_ASSOC);
        if ($adminRow && isset($adminRow['bloqueado']) && (int)$adminRow['bloqueado'] === 1) {
            $adminBloqueado = true;
        }
    }
    if ($clienteBloqueado || $adminBloqueado) {
        http_response_code(401);
        echo json_encode([["auth" => 0]]);
        exit();
    }
} catch (Exception $e) {
    // Em caso de erro ao verificar bloqueio, negar acesso por segurança
    http_response_code(401);
    echo json_encode([["auth" => 0]]);
    exit();
}
// Antes de registrar a conexão simples, verificamos se uma nova sessão seria
// permitida com base no limite de telas.  `verificar_sessao()` aplica a
// mesma lógica de `registrar_sessao()` sem atualizar a tabela
// `conexoes_ativas`.  Se o usuário exceder o limite (por exemplo, tentar
// logar de outro dispositivo quando tem apenas uma tela), a API deve
// responder com 401 imediatamente.
try {
    $limiteTelas = isset($result['conexoes_max']) ? (int) $result['conexoes_max'] : 1;
    if (!verificar_sessao($result['usuario'], $limiteTelas)) {
        http_response_code(401);
        echo json_encode(["user_info" => ["auth" => 0, "msg" => "Limite de conexões atingido"]]);
        exit();
    }
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode(["user_info" => ["auth" => 0]]);
    exit();
}
// Agora registramos (ou atualizamos) a sessão ativa deste dispositivo na
// tabela `conexoes_ativas`.  Embora o bloqueio de telas não ocorra na
// reprodução do conteúdo, precisamos que o painel crie um registro da
// sessão para impedir que um segundo aparelho passe da tela de login
// quando o limite de telas for atingido.  registrar_sessao() usa o
// device_hash do dispositivo atual e apenas insere/atualiza sem
// recontar telas, pois a verificação já ocorreu acima.
try {
    registrar_sessao($result['usuario'], $limiteTelas);
} catch (Exception $e) {
    // Falha silenciosa na gravação da sessão
}

// Em seguida registramos a conexão simples para fins de monitoramento.  Isso
// não consome uma tela, pois a reprodução do conteúdo ocorre em outra rota.
try {
    registrar_conexao($result['usuario']);
} catch (Exception $e) {
    // Falha ao registrar a conexão não deve impedir a resposta do painel.
}

// Processa informações do usuário
$exp_date = strtotime($result['Vencimento']);
$created_at = strtotime($result['Criado_em']);
$status = ($exp_date < time()) ? "Inactive" : "Active";
$auth = ($status === "Active") ? "1" : "0";

// Informações do usuário
$user_info = [
    "username" => $result['usuario'],
    "password" => $result['senha'],
    "auth" => $auth,
    "status" => $status,
    "exp_date" => "$exp_date",
    "is_trial" => "{$result['is_trial']}",
    "active_cons" => "1",
    "created_at" => "$created_at",
    "max_connections" => "{$result['conexoes']}",
    "allowed_output_formats" => ["m3u8", "ts", "rtmp"]
];

// Informações do servidor
$server_info = [
    "url" => $_SERVER['HTTP_HOST'],
    "port" => $_SERVER['SERVER_PORT'],
    "https_port" => "443",
    "server_protocol" => $_SERVER['REQUEST_SCHEME']
];

// -----------------------------------------------------------------------------
// Filtra categorias e streams conforme a preferência de conteúdo do usuário
// (filmes, séries ou completo).  A coluna c_ocultar_fonte em clientes define a
// preferência.  Quando "filmes", apenas categorias de filmes e canais são
// retornadas; quando "series", apenas séries e canais; quando "completo",
// todas as categorias são retornadas.

// Determina o tipo de conteúdo permitido para este usuário
$tipoConteudoPainel = isset($result['c_ocultar_fonte']) ? strtolower($result['c_ocultar_fonte']) : 'completo';
if ($tipoConteudoPainel !== 'filmes' && $tipoConteudoPainel !== 'series' && $tipoConteudoPainel !== 'completo') {
    $tipoConteudoPainel = 'completo';
}

// Obtenção das categorias, filtrando conforme o tipo de conteúdo
$categorias = ["movie" => [], "live" => [], "series" => []];
$tiposCategorias = ["movie", "live", "series"];
$mapa_categorias = [];
foreach ($tiposCategorias as $tipo) {
    // Aplica filtro: quando o usuário escolhe somente filmes, não retornamos
    // categorias de séries; quando escolhe somente séries, não retornamos
    // categorias de filmes.  As categorias de canais (live) são retornadas em
    // ambos os casos.  Quando completo, retornamos todas.
    if ($tipoConteudoPainel === 'filmes' && $tipo === 'series') {
        continue;
    }
    if ($tipoConteudoPainel === 'series' && $tipo === 'movie') {
        continue;
    }
    $queryCat = $conexao->prepare("SELECT * FROM categoria WHERE type = :type");
    $queryCat->bindValue(":type", $tipo);
    $queryCat->execute();
    while ($rowCat = $queryCat->fetch(PDO::FETCH_ASSOC)) {
        $categorias[$tipo][] = [
            "category_id"   => (string) $rowCat["id"],
            "category_name" => $rowCat["nome"],
            "parent_id"     => $rowCat["parent_id"]
        ];
        $mapa_categorias[$rowCat["id"]] = $rowCat["nome"];
    }
}

// Obtenção dos streams, filtrando filmes ou séries conforme a preferência
$streams = [];
$num = 0;
$stmtStreams = $conexao->query("SELECT * FROM streams");
while ($row = $stmtStreams->fetch(PDO::FETCH_ASSOC)) {
    // Skip de acordo com o tipo de conteúdo escolhido
    // - filmes: inclui filmes e canais (live), exclui outros
    // - series: inclui canais (live) mas exclui filmes
    // - completo: inclui todos
    if ($tipoConteudoPainel === 'filmes') {
        // Inclui apenas filmes e canais
        if ($row['stream_type'] !== 'movie' && $row['stream_type'] !== 'live') {
            continue;
        }
        // Exclui séries (não existem nesta tabela, mas por segurança)
    } elseif ($tipoConteudoPainel === 'series') {
        // Inclui apenas canais (live); exclui filmes
        if ($row['stream_type'] === 'movie') {
            continue;
        }
    }
    // Correção de caracteres especiais no nome
    $stream_name = htmlspecialchars_decode($row["name"], ENT_QUOTES);
    $stream_name = mb_convert_encoding($stream_name, 'UTF-8', 'ISO-8859-1');

    $category_name = isset($mapa_categorias[$row["category_id"]]) ? $mapa_categorias[$row["category_id"]] : "Sem Categoria";
    $num++;
    $streams[$row["id"]] = [
        "num"          => $num,
        "name"         => $row["name"],
        "stream_type"  => $row["stream_type"],
        "type_name"    => ucfirst($row["stream_type"]) . " Streams",
        "stream_id"    => $row["id"],
        "stream_icon"  => $row["stream_icon"],
        "epg_channel_id" => null,
        "added"        => $row["added"],
        "category_name" => $category_name,
        "category_id"  => $row["category_id"],
        "series_no"    => null,
        "live"         => ($row["stream_type"] == "live") ? "1" : "0",
        "container_extension" => ($row["stream_type"] == "live") ? null : "mp4",
        "custom_sid"   => "",
        "tv_archive"   => 0,
        "direct_source" => "",
        "tv_archive_duration" => 0
    ];
}

// Monta o JSON final
$response = [
    "user_info" => $user_info,
    "server_info" => $server_info,
    "categories" => $categorias,
    "available_channels" => $streams
];

// Retorna o JSON formatado
echo json_encode($response, JSON_PRETTY_PRINT);
exit();
?>
