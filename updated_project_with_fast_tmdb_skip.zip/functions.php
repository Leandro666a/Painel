<?php
if (!function_exists('dd')) {
    function dd(...$vars)
    {
        echo '<pre style="background: #222; color: #0f0; padding: 10px; border-radius: 5px;">';
        foreach ($vars as $var) {
            var_dump($var);
        }
        echo '</pre>';
        exit;
    }
}

/**
 * Registra ou atualiza a atividade de conexão de um usuário na tabela `conexoes`.
 * Esta função usa um "upsert" para que, caso o usuário já exista na tabela,
 * apenas atualize a data/hora da última atividade e o IP.  Caso não exista,
 * insere um novo registro.  A tabela `conexoes` foi definida no banco de
 * dados original e contém colunas: id (AUTO_INCREMENT), usuario (UNIQUE), ip,
 * ultima_atividade.
 *
 * @param string $usuario Nome de usuário a registrar
 * @return void
 */
function registrar_conexao($usuario)
{
    $con = conectar_bd();
    if (!$con) {
        return;
    }
    try {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null;
        // Insere ou atualiza a linha conforme usuário existente
        $sql = "INSERT INTO conexoes (usuario, ip, ultima_atividade) VALUES (:usuario, :ip, NOW())
                ON DUPLICATE KEY UPDATE ip = VALUES(ip), ultima_atividade = NOW()";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmt->bindParam(':ip', $ip, PDO::PARAM_STR);
        $stmt->execute();
    } catch (Exception $e) {
        // Falha silenciosa, não interrompe o fluxo
    }
}

/**
 * Registra o último conteúdo acessado por um usuário.  Esta função insere
 * um novo registro na tabela `ultimos_acessos` para que o painel possa
 * exibir o que o cliente está assistindo em tempo real.  Não substituímos
 * registros anteriores; simplesmente adicionamos um novo, pois a consulta
 * em {@see obter_detalhes_online()} ordena por id decrescente e pega o
 * mais recente para cada usuário.  Se algum dos parâmetros for vazio,
 * ainda assim registramos, pois o nome e o tipo podem não estar
 * disponíveis em algumas chamadas.
 *
 * A tabela `ultimos_acessos` possui as colunas id, id_user, usuario,
 * tipo, nome, logo, status e data.  Utilizamos apenas `usuario`,
 * `tipo`, `nome`, `logo`, `status` e `data`.  O campo `id_user` foi
 * mantido para compatibilidade, mas como não temos o ID numérico do
 * usuário em todas as rotas, deixamos nulo por padrão.
 *
 * @param string $usuario Nome de usuário
 * @param string|null $tipo Tipo de conteúdo (ex.: "Ao Vivo", "Filme", "Episódio")
 * @param string|null $nome Nome ou título do conteúdo
 * @param string|null $logo URL ou caminho da imagem de capa (opcional)
 * @param string|null $status Estado atual (opcional)
 * @return void
 */
function registrar_ultimo_acesso($usuario, $tipo = null, $nome = null, $logo = null, $status = null)
{
    $con = conectar_bd();
    if (!$con) {
        return;
    }
    try {
        $sql = "INSERT INTO ultimos_acessos (id_user, usuario, tipo, nome, logo, status, data) VALUES (NULL, :usuario, :tipo, :nome, :logo, :status, NOW())";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
        $stmt->bindParam(':nome', $nome, PDO::PARAM_STR);
        $stmt->bindParam(':logo', $logo, PDO::PARAM_STR);
        $stmt->bindParam(':status', $status, PDO::PARAM_STR);
        $stmt->execute();
    } catch (Exception $e) {
        // Falha silenciosa; não interrompe o fluxo se não for possível registrar
    }
}

// -----------------------------------------------------------------------------
// Configuração global do painel
//
// Este valor define por quanto tempo, em minutos, um usuário deve ser
// considerado "online" após a última atividade.  Por padrão, as funções de
// listagem de usuários online utilizavam intervalos curtos (3 minutos) para
// remover rapidamente conexões inativas.  No entanto, alguns clientes podem
// permanecer assistindo conteúdo por períodos mais longos sem realizar novas
// requisições à API, causando o desaparecimento prematuro do status online no
// painel.  Ao aumentar este valor, mantemos os usuários visíveis durante um
// período maior, aproximando-se de um monitoramento em "tempo real" sem
// necessidade de alterar o esquema do banco de dados.  Ajuste conforme a
// necessidade do seu serviço.  Exemplo: 10 para 10 minutos.
if (!defined('ONLINE_INTERVAL_MINUTES')) {
    define('ONLINE_INTERVAL_MINUTES', 10);
}

/**
 * Verifica quantas conexões ativas (sessões) um usuário possui e registra/atualiza
 * a conexão atual caso ainda esteja abaixo do limite permitido. Cada sessão
 * é identificada por um hash baseado no IP e no agente do navegador. A função
 * retorna true se a conexão foi registrada ou atualizada com sucesso e false
 * caso o limite de conexões simultâneas seja atingido.
 *
 * Tabela utilizada: `conexoes_ativas` com colunas id, usuario, device_hash, ip,
 * ultima_atividade. O campo device_hash é UNIQUE para cada usuário.
 *
 * @param string $usuario
 * @param int $conexoes_max Limite de conexões simultâneas permitido para este usuário
 * @return bool true se a sessão foi registrada/atualizada, false se bloqueada
 */
function registrar_sessao($usuario, $conexoes_max = 1)
{
    $con = conectar_bd();
    if (!$con) {
        return false;
    }
    try {
        // Garante que o limite de conexões seja pelo menos 1.  Valores
        // nulos ou menores do que 1 poderiam bloquear completamente o cliente,
        // causando comportamentos inesperados (como exigir mais de uma tela
        // disponível).  Ao normalizar aqui, tratamos esses casos como se
        // tivesse direito a uma única tela.
        $conexoes_max = (int) $conexoes_max;
        if ($conexoes_max < 1) {
            $conexoes_max = 1;
        }
        $ip        = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null;
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        // Para identificar de forma única um dispositivo, combinamos o IP e o User-Agent.
        // Optamos por não incluir o Accept-Language, pois ele pode variar entre chamadas
        // no mesmo aparelho, o que poderia gerar hashes diferentes para o mesmo usuário.
        $deviceHash = md5($ip . '|' . $userAgent);

        // Obtém o hash do dispositivo da sessão existente mais recente (últimos 5 minutos).
        // Ordenamos por `ultima_atividade` decrescente para garantir que o dispositivo
        // mais recentemente atualizado seja retornado.  Isso evita que conexões
        // antigas (inclusive de dispositivos bloqueados) interfiram na decisão.
        $stmtDevice = $con->prepare(
            "SELECT device_hash FROM conexoes_ativas WHERE usuario = :usuario AND ultima_atividade >= (NOW() - INTERVAL 5 MINUTE) ORDER BY ultima_atividade DESC LIMIT 1"
        );
        $stmtDevice->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmtDevice->execute();
        $existingDevice = $stmtDevice->fetchColumn();

        // Conta quantas sessões ativas existem para este usuário (últimos 5 minutos).
        $stmtCount = $con->prepare(
            "SELECT COUNT(*) FROM conexoes_ativas WHERE usuario = :usuario AND ultima_atividade >= (NOW() - INTERVAL 5 MINUTE)"
        );
        $stmtCount->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmtCount->execute();
        $activeCount = (int) $stmtCount->fetchColumn();

        /*
         * Lógica de bloqueio imediata:
         * - Para clientes com apenas uma tela (conexoes_max <= 1):
         *     Bloqueia a nova conexão se já existir uma sessão ativa com um
         *     device_hash diferente. Assim, o usuário não pode alternar de
         *     aparelho sem que uma nova tela seja configurada. Se não houver
         *     sessão ativa ou se for o mesmo dispositivo, permite atualizar.
         * - Para clientes com múltiplas telas (conexoes_max > 1):
         *     Permite até o limite de conexões simultâneas. No entanto,
         *     conexões vindas de um dispositivo já registrado não devem
         *     consumir uma nova tela, portanto não contam para o limite.
         */
        if ($conexoes_max <= 1) {
            if ($existingDevice && $existingDevice !== $deviceHash) {
                // Já há uma sessão e a nova conexão vem de outro aparelho.
                return false;
            }
            // Caso não haja sessão ativa ou seja o mesmo aparelho, prossegue.
        } else {
            // Verifica se o dispositivo atual já está registrado nos últimos 5 minutos
            $stmtCheckDevice = $con->prepare(
                "SELECT COUNT(*) FROM conexoes_ativas WHERE usuario = :usuario AND device_hash = :device_hash AND ultima_atividade >= (NOW() - INTERVAL 5 MINUTE)"
            );
            $stmtCheckDevice->bindParam(':usuario', $usuario, PDO::PARAM_STR);
            $stmtCheckDevice->bindParam(':device_hash', $deviceHash, PDO::PARAM_STR);
            $stmtCheckDevice->execute();
            $isSameDevice = ((int) $stmtCheckDevice->fetchColumn()) > 0;

            if (!$isSameDevice && $activeCount >= $conexoes_max) {
                // Não é o mesmo dispositivo e já atingiu o limite de telas
                return false;
            }
            // Caso seja o mesmo dispositivo ou ainda não atingiu o limite, prossegue.
        }

        // Registra ou atualiza a sessão atual usando device_hash como chave única.
        $sql = "INSERT INTO conexoes_ativas (usuario, device_hash, ip, ultima_atividade) VALUES (:usuario, :device_hash, :ip, NOW())"
             . " ON DUPLICATE KEY UPDATE ip = VALUES(ip), ultima_atividade = NOW()";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmt->bindParam(':device_hash', $deviceHash, PDO::PARAM_STR);
        $stmt->bindParam(':ip', $ip, PDO::PARAM_STR);
        $stmt->execute();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Verifica se o usuário pode iniciar uma nova sessão sem registrar/atualizar
 * a tabela `conexoes_ativas`.  Esta função utiliza a mesma lógica de
 * `registrar_sessao()` para determinar se uma nova conexão seria aceita
 * (considerando o limite de telas e o dispositivo em uso), mas não
 * modifica o banco de dados.  É ideal para checar o limite de conexões
 * durante o login ou geração de playlist, garantindo que apenas o
 * dispositivo autorizado prossiga sem consumir uma nova tela.
 *
 * @param string $usuario
 * @param int $conexoes_max Limite de conexões simultâneas permitido
 * @return bool true se a nova sessão seria permitida, false se excederia o limite
 */
function verificar_sessao($usuario, $conexoes_max = 1)
{
    $con = conectar_bd();
    if (!$con) {
        return false;
    }
    try {
        // Normaliza o limite de telas
        $conexoes_max = (int) $conexoes_max;
        if ($conexoes_max < 1) {
            $conexoes_max = 1;
        }
        $ip        = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null;
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        // Gera o hash do dispositivo apenas com IP e User-Agent.  Evita usar
        // Accept-Language, pois variações em cabeçalhos podem gerar hashes
        // diferentes para o mesmo aparelho.
        $deviceHash = md5($ip . '|' . $userAgent);

        // Busca o hash do dispositivo mais recentemente ativo deste usuário
        // nos últimos 5 minutos, ordenando por `ultima_atividade` descrescente.
        $stmtDevice = $con->prepare(
            "SELECT device_hash FROM conexoes_ativas WHERE usuario = :usuario AND ultima_atividade >= (NOW() - INTERVAL 5 MINUTE) ORDER BY ultima_atividade DESC LIMIT 1"
        );
        $stmtDevice->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmtDevice->execute();
        $existingDevice = $stmtDevice->fetchColumn();

        // Conta quantas sessões ativas existem para este usuário
        $stmtCount = $con->prepare(
            "SELECT COUNT(*) FROM conexoes_ativas WHERE usuario = :usuario AND ultima_atividade >= (NOW() - INTERVAL 5 MINUTE)"
        );
        $stmtCount->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmtCount->execute();
        $activeCount = (int)$stmtCount->fetchColumn();

        if ($conexoes_max <= 1) {
            // Para uma única tela, bloquear se já existir um dispositivo diferente
            if ($existingDevice && $existingDevice !== $deviceHash) {
                return false;
            }
            return true;
        }
        // Para múltiplas telas, permitir se o mesmo dispositivo já estiver ativo
        $stmtCheckDevice = $con->prepare(
            "SELECT COUNT(*) FROM conexoes_ativas WHERE usuario = :usuario AND device_hash = :device_hash AND ultima_atividade >= (NOW() - INTERVAL 5 MINUTE)"
        );
        $stmtCheckDevice->bindParam(':usuario', $usuario, PDO::PARAM_STR);
        $stmtCheckDevice->bindParam(':device_hash', $deviceHash, PDO::PARAM_STR);
        $stmtCheckDevice->execute();
        $isSameDevice = ((int) $stmtCheckDevice->fetchColumn()) > 0;

        if ($isSameDevice) {
            return true;
        }
        // Se não for o mesmo dispositivo, permitir apenas se ainda não atingiu o limite de telas
        return ($activeCount < $conexoes_max);
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Obtém a lista de usuários online e testes online para o dashboard.
 * Considera um usuário online se sua última atividade for nos últimos 5 minutos.
 * Retorna duas contagens e uma lista de detalhes para exibição opcional.
 *
 * @param int|null $adminId Se fornecido, filtra apenas clientes pertencentes a este admin.
 * @return array Estrutura contendo contagens e lista de usuários online
 */
function obter_usuarios_online($adminId = null)
{
    $con = conectar_bd();
    $dados = [
        'usuarios_online' => 0,
        'testes_online'   => 0,
        'lista'           => []
    ];
    if (!$con) {
        return $dados;
    }
    try {
        // Seleciona usuários cujas conexões foram atualizadas dentro do intervalo
        // definido por ONLINE_INTERVAL_MINUTES.  Anteriormente, o intervalo fixo
        // era de 3 minutos, o que fazia com que usuários desaparecessem da lista
        // online pouco tempo após iniciar a reprodução.  Agora, mantemos o
        // status online por mais tempo (10 minutos por padrão), aproximando
        // o comportamento de um monitoramento em tempo real sem alterar o banco.
        $sql = "SELECT c.usuario, c.name, c.is_trial, c.admin_id, cx.ultima_atividade
                FROM conexoes cx
                JOIN clientes c ON c.usuario = cx.usuario
                WHERE cx.ultima_atividade >= (NOW() - INTERVAL " . ONLINE_INTERVAL_MINUTES . " MINUTE)";
        if ($adminId !== null) {
            $sql .= " AND c.admin_id = :adminId";
        }
        $stmt = $con->prepare($sql);
        if ($adminId !== null) {
            $stmt->bindParam(':adminId', $adminId, PDO::PARAM_INT);
        }
        $stmt->execute();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $dados['usuarios_online']++;
            if ((int)$row['is_trial'] === 1) {
                $dados['testes_online']++;
            }
            $dados['lista'][] = [
                'usuario' => $row['usuario'],
                'nome'    => $row['name'],
                'is_trial' => (int)$row['is_trial'],
                'ultima_atividade' => $row['ultima_atividade']
            ];
        }
    } catch (Exception $e) {
        // falha silenciosa
    }
    return $dados;
}

/**
 * Obtém uma lista detalhada de clientes online.
 *
 * Esta função expande a lista simples de usuários online retornando
 * informações adicionais, como o último conteúdo acessado, o tempo
 * desde a última atividade e dados de geolocalização (cidade e
 * provedor) com base no endereço IP. Caso não seja possível
 * determinar a cidade ou o provedor, "Desconhecido" será utilizado.
 *
 * Para cada conexão ativa (última atividade nos últimos 5 minutos),
 * são retornados os seguintes campos:
 * - usuario: login do cliente
 * - nome: nome do cliente
 * - is_trial: flag de teste (0 ou 1)
 * - assistindo: nome e tipo do último conteúdo acessado
 * - ultima: timestamp da última atividade
 * - tempo_desde_ultima: diferença de tempo desde a última atividade
 * - cidade: cidade detectada via API de geolocalização
 * - provedor: provedor/ISP detectado via API de geolocalização
 * - ip: endereço IP utilizado na conexão
 *
 * @param int|null $adminId Se informado, filtra apenas os clientes
 *                          pertencentes a este administrador.
 * @return array Lista de detalhes dos clientes online.
 */
function obter_detalhes_online($adminId = null)
{
    $con = conectar_bd();
    $detalhes = [];
    if (!$con) {
        return $detalhes;
    }
    try {
        // Seleciona conexões ativas dentro do intervalo definido por
        // ONLINE_INTERVAL_MINUTES.  Um intervalo maior evita que o cliente
        // desapareça rapidamente da lista online, mantendo-o visível enquanto
        // assiste conteúdo.  Ajuste ONLINE_INTERVAL_MINUTES para personalizar
        // a janela de visibilidade.
        $sql = "SELECT cx.usuario, cx.ip, cx.ultima_atividade, c.name, c.is_trial
                FROM conexoes cx
                JOIN clientes c ON cx.usuario = c.usuario
                WHERE cx.ultima_atividade >= (NOW() - INTERVAL " . ONLINE_INTERVAL_MINUTES . " MINUTE)";
        if ($adminId !== null) {
            $sql .= " AND c.admin_id = :adminId";
        }
        $stmt = $con->prepare($sql);
        if ($adminId !== null) {
            $stmt->bindParam(':adminId', $adminId, PDO::PARAM_INT);
        }
        $stmt->execute();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $usuario = $row['usuario'];
            $ip = $row['ip'] ?? '';
            $ultima = $row['ultima_atividade'];
            $nome = $row['name'];
            $is_trial = (int)$row['is_trial'];
            // Recupera o último conteúdo acessado a partir de ultimos_acessos
            $assistindo = 'N/A';
            $tempoAssistindo = '';
            try {
                $stmt2 = $con->prepare("SELECT nome, tipo, data FROM ultimos_acessos WHERE usuario = :usuario ORDER BY id DESC LIMIT 1");
                $stmt2->bindParam(':usuario', $usuario, PDO::PARAM_STR);
                $stmt2->execute();
                $acesso = $stmt2->fetch(PDO::FETCH_ASSOC);
                if ($acesso) {
                    $assistindo = $acesso['nome'];
                    if (!empty($acesso['tipo'])) {
                        $assistindo .= ' (' . $acesso['tipo'] . ')';
                    }
                    // A coluna `data` armazena o momento em que o conteúdo foi iniciado.
                    // Calcula o tempo decorrido desde então.
                    $tempoInicio = strtotime($acesso['data']);
                    if ($tempoInicio > 0) {
                        $difMin = floor((time() - $tempoInicio) / 60);
                        if ($difMin < 60) {
                            $tempoAssistindo = $difMin . ' min';
                        } else {
                            $h = floor($difMin / 60);
                            $m = $difMin % 60;
                            $tempoAssistindo = $h . 'h ' . $m . 'min';
                        }
                    } else {
                        $tempoAssistindo = '';
                    }
                }
            } catch (Exception $ex2) {
                // Ignora falhas nesta consulta auxiliar
            }
            // Calcula tempo desde a última atividade
            $minutos = '';
            if ($ultima) {
                try {
                    $timestamp = strtotime($ultima);
                    if ($timestamp > 0) {
                        $minDiff = floor((time() - $timestamp) / 60);
                        if ($minDiff < 60) {
                            $minutos = $minDiff . ' min';
                        } else {
                            $horas = floor($minDiff / 60);
                            $remMin = $minDiff % 60;
                            $minutos = $horas . 'h ' . $remMin . 'min';
                        }
                    }
                } catch (Exception $ex3) {
                    // falha silenciosa
                }
            }
            // Determina cidade e provedor usando API externa ip-api.com
            $cidade = 'Desconhecido';
            $provedor = 'Desconhecido';
            if ($ip && filter_var($ip, FILTER_VALIDATE_IP)) {
                $url = "http://ip-api.com/json/" . urlencode($ip) . "?fields=city,isp";
                $ctx = stream_context_create([
                    'http' => [
                        'timeout' => 2
                    ]
                ]);
                $json = @file_get_contents($url, false, $ctx);
                if ($json) {
                    $info = json_decode($json, true);
                    if (is_array($info)) {
                        if (!empty($info['city'])) {
                            $cidade = $info['city'];
                        }
                        if (!empty($info['isp'])) {
                            $provedor = $info['isp'];
                        }
                    }
                }
            }
            $detalhes[] = [
                'usuario' => $usuario,
                'nome' => $nome,
                'is_trial' => $is_trial,
                'assistindo' => $assistindo,
                'ultima' => $ultima,
                // Tempo desde a última atividade (em minutos ou horas)
                'tempo_desde_ultima' => $minutos,
                // Tempo assistindo o conteúdo atual
                'tempo_assistindo' => $tempoAssistindo,
                'cidade' => $cidade,
                'provedor' => $provedor,
                'ip' => $ip
            ];
        }
    } catch (Exception $ex) {
        // Falha silenciosa para não interromper execução
    }
    return $detalhes;
}