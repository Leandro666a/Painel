<?php
/**
 * Página auxiliar para alternar o modo aleatório (sorteio de servidores) no painel.
 *
 * Esta página é acionada via POST a partir do dashboard.  Ela alterna o valor
 * da coluna `modo_aleatorio` para o administrador logado.  Após efetuar a
 * atualização, redireciona de volta para a página do dashboard.
 */

session_start();
require_once(__DIR__ . '/api/controles/db.php');

// Verifica se o usuário está autenticado.  Caso contrário, redireciona
// para a página de login.
if (!isset($_SESSION['token']) || !isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

// Apenas processos POST são suportados.  Se for uma solicitação GET,
// redireciona de volta ao dashboard sem fazer alterações.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}

$adminId = (int)$_SESSION['admin_id'];

try {
    $conexao = conectar_bd();
    // Obtém o valor atual do modo aleatório
    $stmtSelect = $conexao->prepare('SELECT modo_aleatorio FROM admin WHERE id = :id LIMIT 1');
    $stmtSelect->bindParam(':id', $adminId, PDO::PARAM_INT);
    $stmtSelect->execute();
    $currentValue = (int)$stmtSelect->fetchColumn();

    // Alterna o valor
    $novoValor = ($currentValue === 1) ? 0 : 1;
    $stmtUpdate = $conexao->prepare('UPDATE admin SET modo_aleatorio = :novo WHERE id = :id');
    $stmtUpdate->bindParam(':novo', $novoValor, PDO::PARAM_INT);
    $stmtUpdate->bindParam(':id', $adminId, PDO::PARAM_INT);
    $stmtUpdate->execute();
} catch (Exception $ex) {
    // Em caso de erro, ignoramos e ainda assim redirecionamos de volta
}

// Redireciona para o dashboard após a alteração
header('Location: dashboard.php');
exit;