<?php
session_start();
require_once('./api/controles/db.php');
require_once('./api/controles/dashboard.php');
require_once("menu.php");
require_once('./api/is_trial.php');
// Importa funções auxiliares para registrar conexões e obter usuários online
require_once('functions.php');

$dadosAtivos = Dashboard();
$dadosTestes = testes();
$conteudos = conteudos();

// -------------------------------------------------------------------------
// Recupera o estado do modo aleatório para exibir no cartão de atalho do
// dashboard.  Utilizamos a coluna "modo_aleatorio" na tabela admin para
// armazenar o estado global do sorteio de domínios.  Caso não haja valor
// válido, assume-se zero (desativado).  Esta variável é utilizada mais
// adiante para alterar a cor do cartão e o texto de ativação/desativação.
$modo_aleatorio_dashboard = 0;
$adminIdDashboard = isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : 0;
$conexao = conectar_bd();
if ($conexao && $adminIdDashboard > 0) {
    try {
        $stmtModoDash = $conexao->prepare("SELECT modo_aleatorio FROM admin WHERE id = :aid LIMIT 1");
        $stmtModoDash->bindValue(':aid', $adminIdDashboard, PDO::PARAM_INT);
        $stmtModoDash->execute();
        $modo_aleatorio_dashboard = (int)$stmtModoDash->fetchColumn();
    } catch (Exception $ex) {
        $modo_aleatorio_dashboard = 0;
    }
}
// Prepara lista de revendedores para a funcionalidade de mensagens. Somente o
// administrador (nivel_admin = 1) pode enviar mensagens.  Aqui carregamos
// todos os usuários da tabela admin cujo campo `admin` é diferente de 1.  A
// lista é serializada posteriormente em JavaScript para construir o
// seletor de destinatários.  Caso ocorra algum erro na consulta, o array
// permanece vazio.
$revendedores = [];
if (isset($_SESSION['nivel_admin']) && (int)$_SESSION['nivel_admin'] === 1) {
    try {
        $stmtRev = $conexao->prepare("SELECT id, user FROM admin WHERE admin != 1");
        $stmtRev->execute();
        $revendedores = $stmtRev->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $ex) {
        $revendedores = [];
    }
}
$resposta = contar_clientes_is_trial_0();

// Calcula usuários online e testes online para o dashboard.  O ID do admin
// logado é utilizado para filtrar apenas os clientes deste revendedor.  A
// função retorna as contagens e uma lista detalhada.
$usuariosOnlineData = obter_usuarios_online($adminIdDashboard);
?>

<style type="text/css">
  
  .scrollable-table {
  max-height: 300px; /* Defina a altura máxima desejada */
  overflow-y: auto;
}

/*
 * Ajuste de cores para melhorar a legibilidade no dashboard.
 * Os textos pequenos de rodapé e rótulos que utilizavam cores
 * escurecidas são clareados para que fiquem visíveis em temas
 * escuros. Apenas os elementos de rodapé com float-start ou
 * cor preta são afetados; os elementos de lucro/faturamento
 * (sucesso/danger) permanecem com suas cores originais.
 */
.card-footer small.float-start {
  color: rgba(255, 255, 255, 0.7) !important;
}
.card-footer small.text-black {
  color: rgba(255, 255, 255, 0.7) !important;
}
.card-label.small.text-muted {
  color: rgba(255, 255, 255, 0.85) !important;
}

</style>

<div class="p-2">

  <!-- Estatísticas gerais apresentadas em um gráfico de barras.  Esta seção utiliza
       o Chart.js para visualizar as quantidades de conteúdos (canais ao vivo,
       filmes, séries e episódios) disponíveis.  A classe animate__fadeInUp
       proporciona uma animação de entrada suave na renderização inicial.

       Este bloco é exibido apenas para administradores (nivel_admin == 1).
       Para revendedores e usuários comuns, o gráfico é ocultado para evitar
       carregamento desnecessário de scripts e problemas de permissões. -->
  <?php if (isset($_SESSION['nivel_admin']) && $_SESSION['nivel_admin'] == 1): ?>
  <div class="row mb-4">
    <div class="col-12">
      <div class="card shadow-sm animate__animated animate__fadeInUp">
        <div class="card-body">
          <h5 class="card-title mb-3">Visão Geral do Conteúdo</h5>
          <div class="chart-container" style="position: relative; height:260px;">
            <canvas id="statsChart"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!--
   * Bloco de atalhos rápidos
   *
   * Movemos os cartões de ações rápidas (Adicionar Teste, Clientes,
   * Revendedores, Modo Aleatório e Chatbot) para o topo da página.
   * Isso melhora a navegação colocando as ações mais utilizadas
   * imediatamente acessíveis.  Para revendedores, alguns itens são
   * ocultados conforme as permissões.  Este bloco é exibido para
   * todos os usuários; cada cartão possui suas próprias condições.
   -->
  <div class="row mb-4">
    <?php // Cartão para adicionar teste rápido, disponível para masters e revendedores ?>
    <?php // Exibe o cartão de teste rápido para qualquer usuário logado (admin ou revendedor)
    // Antes, restringíamos a exibição apenas pelo nível do admin.  No entanto,
    // revendedores também precisam acessar a funcionalidade de teste rápido.
    // Portanto, verificamos a presença do admin_id na sessão para mostrar
    // este cartão a todos os usuários autenticados.
    if (isset($_SESSION['admin_id'])): ?>
    <div class="col-md-6 col-lg-3 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-primary border-start">
       <!--
         * Botão de criação de teste rápido
         * Adicionamos atributos de acessibilidade e tooltip para informar ao usuário
         * que o teste criado será listado na página de Testes (trial).  O papel de
         * botão (role="button") melhora a semântica para leitores de tela.
         -->
       <div class="card-body d-flex align-items-center justify-content-center flex-column text-center"
            role="button"
            data-bs-toggle="tooltip"
            data-bs-placement="bottom"
            title="Cria um teste rápido. O teste ficará disponível na página de Testes."
            style="cursor: pointer;"
            onclick='modal_master("api/testes.php", "adicionar_testes", "add")'>
        <i class="fa-3x fa-solid fa-plus-circle mb-2" style="color: var(--primary-color);"></i>
        <p class="card-label small fs-5 mb-0">Adicionar Teste</p>
        <small class="text-white-50">Criar teste rápido</small>
       </div>
      </div>
    </div>
    <?php endif; ?>
    <?php // Cartão de acesso aos clientes - disponível para todos ?>
    <div class="col-md-6 col-lg-3 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-success border-start">
       <div class="card-body d-flex align-items-center justify-content-center flex-column text-center" style="cursor: pointer;"
            onclick="window.location.href='clientes.php'">
        <i class="fa-3x fa-solid fa-users mb-2 text-success"></i>
        <p class="card-label small fs-5 mb-0">Clientes</p>
        <small class="text-white-50">Gerenciar clientes</small>
       </div>
      </div>
    </div>
    <?php // Cartão de acesso aos revendedores - somente se plano permite ?>
    <?php if (isset($_SESSION['plano_admin']) && $_SESSION['plano_admin'] != 1): ?>
    <div class="col-md-6 col-lg-3 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-info border-start">
       <div class="card-body d-flex align-items-center justify-content-center flex-column text-center" style="cursor: pointer;"
            onclick="window.location.href='revendedores.php'">
        <i class="fa-3x fa-solid fa-users-gear mb-2 text-info"></i>
        <p class="card-label small fs-5 mb-0">Revendedores</p>
        <small class="text-white-50">Gerenciar revendedores</small>
       </div>
      </div>
    </div>
    <?php endif; ?>
    <?php // Cartão para limpeza de testes expirados - somente administradores ?>
    <?php if (isset($_SESSION['nivel_admin']) && $_SESSION['nivel_admin'] == 1): ?>
    <div class="col-md-6 col-lg-3 mb-4">
      <!-- O cartão de limpeza não utiliza formulário tradicional; o clique é tratado via JavaScript -->
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-danger border-start">
        <div id="btnLimparTestes" class="card-body d-flex align-items-center justify-content-center flex-column text-center" style="cursor: pointer;">
          <i class="fa-3x fa-solid fa-broom mb-2 text-danger"></i>
          <p class="card-label small fs-5 mb-0">Limpar Testes Expirados</p>
          <small class="text-white-50">Remover testes vencidos</small>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php // Cartão para envio de mensagem aos revendedores - apenas administradores ?>
    <?php if (isset($_SESSION['nivel_admin']) && (int)$_SESSION['nivel_admin'] === 1): ?>
    <div class="col-md-6 col-lg-3 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-warning border-start">
        <div id="btnEnviarMensagem" class="card-body d-flex align-items-center justify-content-center flex-column text-center" style="cursor: pointer;">
          <i class="fa-3x fa-solid fa-envelope mb-2 text-warning"></i>
          <p class="card-label small fs-5 mb-0">Enviar Mensagem</p>
          <small class="text-white-50">Notificar revendedores</small>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <?php // O cartão de Chatbot foi removido a pedido do usuário ?>
  </div>

  <?php if ($_SESSION['nivel_admin'] == 1): ?>
  
  <div class="row">
    <h4 class="p-2 rounded-3 text-white bg-success">Informações De Conteudos </h4>
    <div class="col-md-6 col-lg-4 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-primary border-start">
       <div class="card-body">
        <div class="card-innerBody align-items-center">
         <div class="float-start justify-content-center text-black-50" style="min-width: 50px;min-height: 50px;">
          <i class="fa-3x fa-solid fa-tv text-primary"></i>
         </div>
         <div class="float-end ml-auto">
          <p class="card-label small text-end fs-4">Canais</p>
          <h4 class="card-text text-end"><?php echo $conteudos['TotalLiveStreams']; ?></h4>
         </div>
        </div>
       </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-4 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-success border-start">
       <div class="card-body">
        <div class="card-innerBody align-items-center">
         <div class="float-start justify-content-center text-black-50" style="min-width: 50px;min-height: 50px;">
          <i class="fa-3x fa-solid fa-film text-success"></i>
         </div>
         <div class="float-end ml-auto">
          <p class="card-label small text-end fs-4">Filmes</p>
          <h4 class="card-text text-end"><?php echo $conteudos['TotalMovieStreams']; ?></h4>
         </div>
        </div>
       </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-4 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-warning border-start">
       <div class="card-body">
        <div class="card-innerBody align-items-center">
         <div class="float-start justify-content-center text-black-50" style="min-width: 50px;min-height: 50px;">
          <i class="fa-3x fa-solid fa-clapperboard text-warning"></i>
         </div>
         <div class="float-end ml-auto">
          <p class="card-label small text-end fs-4">Series</p>
          <h4 class="card-text text-end"><?php echo $conteudos['TotalSeries']; ?></h4>
         </div>
        </div>
       </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-4 mb-4">
      <div class="border-0 card h-100 rounded-0 shadow-sm border-0 border-5 border-info border-start">
       <div class="card-body">
        <div class="card-innerBody align-items-center">
         <div class="float-start justify-content-center text-black-50" style="min-width: 50px;min-height: 50px;">
          <i class="fa-3x fa-solid fa-photo-film text-info"></i>
         </div>
         <div class="float-end ml-auto">
          <p class="card-label small text-end fs-4">Episodios</p>
          <h4 class="card-text text-end"><?php echo $conteudos['TotalEpisodes']; ?></h4>
         </div>
        </div>
       </div>
      </div>
    </div>
  </div>
  <?php endif ?>
  
  <div class="row">
    <h4 class="p-2 rounded-3 text-white bg-primary">Informações Finançeiras</h4>
   <div class="col-12 mb-4 col-lg-6">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-success" style="min-width: 50px;min-height: 50px;">
        <i class="fa-eye fa-solid fa-3x text-success"></i>
       </div>
       <div class="ml-auto">
        <p class="small text-center text-white-50 w-100">Usuários Online</p>
        <h4 class="card-text j_content_online_users text-center">
            <?php echo isset($usuariosOnlineData['usuarios_online']) ? $usuariosOnlineData['usuarios_online'] : 0; ?>
        </h4>
       </div>
      </div>
     </div>
     <div class="listaClientesOnline" style="max-height: 90px; overflow: auto;zoom: 90%;">
        <?php
        // Lista de clientes online (não trial) para exibição rápida.  Cada usuário
        // é apresentado em uma linha simples.  Apenas usuários com is_trial = 0 são listados.
        if (!empty($usuariosOnlineData['lista'])) {
            foreach ($usuariosOnlineData['lista'] as $cli) {
                if ((int)$cli['is_trial'] === 0) {
                    echo '<div>' . htmlspecialchars($cli['usuario'], ENT_QUOTES, 'UTF-8') . '</div>';
                }
            }
        }
        ?>
        <div class="text-center mt-2">
            <button type="button" class="btn btn-outline-primary btn-sm"
                    onclick="modal_master('api/clientes_online.php','detalhes_online','1')">
                Detalhes
            </button>
        </div>
     </div>
    </div>
   </div>
   <div class="col-12 mb-4 col-lg-6">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-info" style="min-width: 50px;min-height: 50px;">
        <i class="fa-eye fa-solid fa-3x text-info"></i>
       </div>
    <div class="ml-auto">
    <p class="small text-center text-white-50 w-100">Testes Online</p>
    <h4 class="card-text j_content_online_users text-center">
        <?php echo isset($usuariosOnlineData['testes_online']) ? $usuariosOnlineData['testes_online'] : 0; ?>
    </h4>
</div>
      </div>
     </div>
     <div class="listaClientesOnline" style="max-height: 90px; overflow: auto;zoom: 90%;">
        <?php
        // Lista de clientes de teste online para exibição rápida.  Filtra apenas is_trial = 1.
        if (!empty($usuariosOnlineData['lista'])) {
            foreach ($usuariosOnlineData['lista'] as $cli) {
                if ((int)$cli['is_trial'] === 1) {
                    echo '<div>' . htmlspecialchars($cli['usuario'], ENT_QUOTES, 'UTF-8') . '</div>';
                }
            }
        }
        ?>
        <div class="text-center mt-2">
            <button type="button" class="btn btn-outline-primary btn-sm"
                    onclick="modal_master('api/clientes_online.php','detalhes_online','1')">
                Detalhes
            </button>
        </div>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-primary" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-users text-primary"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Total de Usuários</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['Totaldeclientes']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">Total</small>
      <small class="text-black float-end ml-auto">
       <i class="fa fa-caret-up"></i><i class="fa fa-caret-down"></i>R$: <?php echo $dadosAtivos['Totaldeclientes_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">P/unitário:</small>
      <small class="text-black float-end ml-auto">R$: <?php echo $dadosAtivos['Totaldeclientes_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-success" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-users text-success"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Clientes ATIVOS</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['clientesAtivos']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">Total</small>
      <small class="text-success float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-up"></i>R$: <?php echo $dadosAtivos['clientesAtivos_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">P/unitário:</small>
      <small class="text-success float-end ml-auto">R$: <?php echo $dadosAtivos['clientesAtivos_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-danger" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-users-slash text-danger"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Total Vencidos</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['clientesvencidostotal']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">Total</small>
      <small class="text-danger float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-down"></i>R$: <?php echo $dadosAtivos['clientesvencidostotal_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">P/unitário:</small>
      <small class="text-danger float-end ml-auto">R$: <?php echo $dadosAtivos['clientesvencidostotal_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-success" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-user-check text-success"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Renovados</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['clientesrenovados']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">Total</small>
      <small class="text-success float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-up"></i>R$: <?php echo $dadosAtivos['clientesrenovados_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">P/unitário:</small>
      <small class="text-success float-end ml-auto">R$: <?php echo $dadosAtivos['clientesrenovados_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-warning" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-user-clock text-warning"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Total a renovar</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['clientesarenovar']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">Total</small>
      <small class="text-success float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-up"></i>R$: <?php echo $dadosAtivos['clientesarenovar_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">P/unitário:</small>
      <small class="text-success float-end ml-auto">R$: <?php echo $dadosAtivos['clientesarenovar_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-info" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-user-plus text-info"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Novos Usuários</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['clientesnovos']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">Total</small>
      <small class="text-success float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-up"></i>R$: <?php echo $dadosAtivos['clientesnovos_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">P/unitário:</small>
      <small class="text-success float-end ml-auto">R$: <?php echo $dadosAtivos['clientesnovos_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-danger" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-user-xmark text-danger"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Vencidos este mes</p>
        <h4 class="card-text text-end"><?php echo $dadosAtivos['clientesvencidos_este_mes']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">Total</small>
      <small class="text-danger float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-down"></i>R$: <?php echo $dadosAtivos['clientesvencidos_este_mes_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">P/unitário:</small>
      <small class="text-danger float-end ml-auto">R$: <?php echo $dadosAtivos['clientesvencidos_este_mes_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-primary" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-users text-primary"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Total de Testes</p>
        <h4 class="card-text text-end"><?php echo $dadosTestes['Totaldetestes']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">Total</small>
      <small class="text-black float-end ml-auto">
       <i class="fa fa-caret-up"></i><i class="fa fa-caret-down"></i> R$: <?php echo $dadosTestes['Totaldetestes_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">P/unitário:</small>
      <small class="text-black float-end ml-auto">R$: <?php echo $dadosTestes['Totaldetestes_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-success" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-users text-success"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Testes ATIVOS</p>
        <h4 class="card-text text-end"><?php echo $dadosTestes['TestesAtivos']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">Total</small>
      <small class="text-success float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-up"></i>R$: <?php echo $dadosTestes['TestesAtivos_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style=" font-size: x-small;">P/unitário:</small>
      <small class="text-success float-end ml-auto">R$: <?php echo $dadosTestes['TestesAtivos_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
   <div class="col-md-4 col-lg-4 mb-4">
    <div class="border-0 card h-100 rounded-0 shadow-sm">
     <div class="card-body">
      <div class="card-innerBody align-items-center">
       <div class="float-start justify-content-center text-danger" style="min-width: 50px;min-height: 50px;">
        <i class="fa-3x fa-solid fa-users-slash text-danger"></i>
       </div>
       <div class="float-end ml-auto">
        <p class="card-label small text-muted text-end">Testes Vencidos</p>
        <h4 class="card-text text-end"><?php echo $dadosTestes['Testesvencidostotal']; ?></h4>
       </div>
      </div>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">Total</small>
      <small class="text-danger float-end ml-auto">
       <i aria-hidden="true" class="fa fa-caret-down"></i>R$: <?php echo $dadosTestes['Testesvencidostotal_valor']; ?></small>
     </div>
     <div class="card-footer">
      <small class="float-start text-muted" style="font-size: x-small;">P/unitário:</small>
      <small class="text-danger float-end ml-auto">R$: <?php echo $dadosTestes['Testesvencidostotal_valor_unidade']; ?></small>
     </div>
    </div>
   </div>
 </div>
 </div>
  <!-------------hashboard2----------->
  <div class="row">
    <div class="align-items-stretch col-lg-6 mb-4">
      <div class="card h-100 border-0 rounded-0 ">
          <div class="card-title d-flex mb-1 p-3">
            <h5>Vencimento hoje</h5>
          </div>
          <div class="card-body"><div class="overflow-auto" style="max-height: 13em; min-height: 13em;">
                <table class="table scrollable-table table-responsive">
                  <thead>
                    <tr>
                      <th class="acao text-center" style="width: 22%;"> Ações</th>
                      <th style="width: 10%;min-width: 67px;">ID-C:</th>
                      <th class="number">Usuario:</th>
                      <th style="width:20%;">Vencimento:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Lucro:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Valor:</th>
                    </tr>
                  </thead>
                  <tbody class="no-border-x">
                    <?php if (empty($dadosAtivos['clientesvencidos_hoje_lista'])){ ?>
                        <tr>
                            <td colspan="5" class="text-center">Não há clientes Vencidos hoje para exibir.</td>
                        </tr>
                    <?php }else{ ?>
                    <?php foreach ($dadosAtivos['clientesvencidos_hoje_lista'] as $cliente) { ?>
                      <tr>
                        <!-- Tabela de clientesvencidos_este_mes -->                  
                        <td class="acao">
                          <button type="button" class="btn btn-outline-primary fw-bold p-1" style="font-size: 12px; width: 81px;" data-toggle="modal" data-placement="top" title="Renovar" onclick='modal_master("api/clientes.php", "renovar_cliente", "<?php echo $cliente['id']; ?>", "usuario", "<?php echo $cliente['usuario']; ?>")'><i class="btn-sm fa-retweet fas"></i> Renovar </button>
                        </td>
                        <td><?php echo $cliente['id']; ?></td>
                        <td class="number"><?php echo $cliente['usuario']; ?></td>
                        <td class="text-center"><?php echo $cliente['data']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['lucro']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['total']; ?></td>
                        
                      </tr>
                    <?php }} ?>
                  </tbody>
                </table>
            </div>
            <table>
                <thead>
                  <tr>
                    <th style="width: 10%;max-width: 60px;">TOTAL:</th>
                    <th style="width: 100%;"> </th>
                    <th style="width:20%;min-width: 140px;">Lucro: R$: <?php echo $dadosAtivos['clientesvencidos_hoje_lucro']; ?></th>
                    <th style="width:20%;min-width: 110px;">Faturamento: R$: <?php echo $dadosAtivos['clientesvencidos_valor_total']; ?></th>
                  </tr>
                </thead>
            </table>
          </div>
      </div>
    </div>
    <div class="align-items-stretch col-lg-6 mb-4">
      <div class="card h-100 border-0 rounded-0">
          <div class="card-title d-flex mb-1 p-3">
            <h5>Vencimento Amanha</h5>
          </div>
          <div class="card-body"><div class="overflow-auto" style="max-height: 13em; min-height: 13em;">
                <table class="table scrollable-table table-responsive">
                  <thead>
                    <tr>
                      <th class="acao text-center" style="width: 22%;"> Ações</th>
                      <th style="width: 10%;min-width: 67px;">ID-C:</th>
                      <th class="number">Usuario:</th>
                      <th style="width:20%;">Vencimento:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Lucro:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Valor:</th>
                    </tr>
                  </thead>
                  <tbody class="no-border-x">
                    <?php if (empty($dadosAtivos['clientesvencidos_amanha_lista'])){ ?>
                      <tr>
                          <td colspan="5" class="text-center">Não há clientes com vencimento amanha para exibir.</td>
                      </tr>
                  <?php }else{ ?>
                    <?php foreach ($dadosAtivos['clientesvencidos_amanha_lista'] as $cliente) { ?>
                      <tr>
                        <!-- Tabela de clientesvencidos_este_mes -->                  
                        <td class="acao">
                          <button type="button" class="btn btn-outline-primary fw-bold p-1" style="font-size: 12px; width: 81px;" data-toggle="modal" data-placement="top" title="Renovar" onclick='modal_master("api/clientes.php", "renovar_cliente", "<?php echo $cliente['id']; ?>", "usuario", "<?php echo $cliente['usuario']; ?>")'><i class="btn-sm fa-retweet fas"></i> Renovar </button>
                        </td>
                        <td><?php echo $cliente['id']; ?></td>
                        <td class="number"><?php echo $cliente['usuario']; ?></td>
                        <td class="text-center"><?php echo $cliente['data']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['lucro']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['total']; ?></td>
                        
                      </tr>
                    <?php }} ?>
                  </tbody>
                </table>
            </div>
            <table>
                <thead>
                  <tr>
                    <th style="width: 10%;max-width: 60px;">TOTAL:</th>
                    <th style="width: 100%;"> </th>
                    <th style="width:20%;min-width: 140px;">Lucro: R$: <?php echo $dadosAtivos['clientesvencidos_amanha_lucro']; ?></th>
                    <th style="width:20%;min-width: 110px;">Faturamento: R$: <?php echo $dadosAtivos['clientesvencidos_amanha_valor_total']; ?></th>
                  </tr>
                </thead>
            </table>
          </div>
      </div>
    </div>
    <div class="align-items-stretch col-lg-6 mb-4">
      <div class="card h-100 border-0 rounded-0">
          <div class="card-title d-flex mb-1 p-3">
            <h5>Proximos 7 Dias</h5>
          </div>
          <div class="card-body"><div class="overflow-auto" style="max-height: 13em; min-height: 13em;">
                <table class="table scrollable-table table-responsive">
                  <thead>
                    <tr>
                      <th class="acao text-center" style="width: 22%;"> Ações</th>
                      <th style="width: 10%;min-width: 67px;">ID-C:</th>
                      <th class="number">Usuario:</th>
                      <th style="width:20%;">Vencimento:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Lucro:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Valor:</th>
                    </tr>
                  </thead>
                  <tbody class="no-border-x">
                    <?php if (empty($dadosAtivos['clientesvencidos_proximos'])){ ?>
                      <tr>
                          <td colspan="5" class="text-center">Não há clientes com vencimento nos proximo 7 dias para exibir.</td>
                      </tr>
                  <?php }else{ ?>
                    <?php foreach ($dadosAtivos['clientesvencidos_proximos'] as $cliente) { ?>
                      <tr>
                        <!-- Tabela de clientesvencidos_este_mes -->                  
                        <td class="acao">
                          <button type="button" class="btn btn-outline-primary fw-bold p-1" style="font-size: 12px; width: 81px;" data-toggle="modal" data-placement="top" title="Renovar" onclick='modal_master("api/clientes.php", "renovar_cliente", "<?php echo $cliente['id']; ?>", "usuario", "<?php echo $cliente['usuario']; ?>")'><i class="btn-sm fa-retweet fas"></i> Renovar </button>
                        </td>
                        <td><?php echo $cliente['id']; ?></td>
                        <td class="number"><?php echo $cliente['usuario']; ?></td>
                        <td class="text-center"><?php echo $cliente['data']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['lucro']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['total']; ?></td>
                        
                      </tr>
                    <?php }} ?>
                  </tbody>
                </table>
            </div>
            <table>
                <thead>
                  <tr>
                    <th style="width: 10%;max-width: 60px;">TOTAL:</th>
                    <th style="width: 100%;"> </th>
                    <th style="width:20%;min-width: 140px;">Lucro: R$: <?php echo $dadosAtivos['clientesvencidos_proximos_lucro']; ?></th>
                    <th style="width:20%;min-width: 110px;">Faturamento: R$: <?php echo $dadosAtivos['clientesvencidos_proximos_valor_total']; ?></th>
                  </tr>
                </thead>
            </table>
          </div>
      </div>
    </div>
    <div class="align-items-stretch col-lg-6 mb-4">
      <div class="card h-100 border-0 rounded-0">
          <div class="card-title d-flex mb-1 p-3">
            <h5 class="text-danger">Vencidos Este Mes</h5>
          </div>
          <div class="card-body"><div class="overflow-auto" style="max-height: 13em; min-height: 13em;">
                <table class="table scrollable-table table-responsive">
                  <thead>
                    <tr>
                      <th class="acao text-center" style="width: 22%;"> Ações</th>
                      <th style="width: 10%;min-width: 67px;">ID-C:</th>
                      <th class="number">Usuario:</th>
                      <th style="width:20%;">Vencimento:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Lucro:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Valor:</th>
                    </tr>
                  </thead>
                  <tbody class="no-border-x">
                    <?php if (empty($dadosAtivos['clientesvencidos_este_mes_lista'])){ ?>
                      <tr>
                          <td colspan="5" class="text-center">Não há clientes vencidos este mes para exibir.</td>
                      </tr>
                  <?php }else{ ?>
                    <?php foreach ($dadosAtivos['clientesvencidos_este_mes_lista'] as $cliente) { ?>
                      <tr>
                        <!-- Tabela de clientesvencidos_este_mes -->                  
                        <td class="acao">
                          <button type="button" class="btn btn-outline-primary fw-bold p-1" style="font-size: 12px; width: 81px;" data-toggle="modal" data-placement="top" title="Renovar" onclick='modal_master("api/clientes.php", "renovar_cliente", "<?php echo $cliente['id']; ?>", "usuario", "<?php echo $cliente['usuario']; ?>")'><i class="btn-sm fa-retweet fas"></i> Renovar </button>
                        </td>
                        <td><?php echo $cliente['id']; ?></td>
                        <td class="number"><?php echo $cliente['usuario']; ?></td>
                        <td class="text-center"><?php echo $cliente['data']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['lucro']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['total']; ?></td>
                        
                      </tr>
                    <?php }} ?>
                  </tbody>
                </table>
            </div>
          </div>
      </div>
    </div>
    <div class="align-items-stretch col-lg-6 mb-4">
      <div class="card h-100 border-0 rounded-0">
          <div class="card-title d-flex mb-1 p-3">
            <h5 class="">Renovados Este Mes</h5>
          </div>
          <div class="card-body"><div class="overflow-auto" style="max-height: 13em; min-height: 13em;">
                <table class="table scrollable-table table-responsive">
                  <thead>
                    <tr>
                      <th style="width: 10%;min-width: 67px;">ID-C:</th>
                      <th class="number">Usuario:</th>
                      <th style="width:20%;">Vencimento:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Lucro:</th>
                      <th style="width: 20%;min-width: 90px;" class="text-center">Valor:</th>
                    </tr>
                  </thead>
                  <tbody class="no-border-x">
                    <?php if (empty($dadosAtivos['clientesrenovados_lista'])){ ?>
                      <tr>
                          <td colspan="5" class="text-center">Não há clientes renovados este mes para exibir.</td>
                      </tr>
                  <?php }else{ ?>
                    <?php foreach ($dadosAtivos['clientesrenovados_lista'] as $cliente) { ?>
                      <tr>
                        <!-- Tabela de clientesvencidos_este_mes -->                  
                        
                        <td class="text-center"><?php echo $cliente['id']; ?></td>
                        <td class="number "><?php echo $cliente['usuario']; ?></td>
                        <td class="text-center"><?php echo $cliente['data']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['lucro']; ?></td>
                        <td class="text-center" style="width:20%;"><?php echo "R$: ". $cliente['total']; ?></td>
                        
                      </tr>
                    <?php }} ?>
                  </tbody>
                </table>
            </div>
            <table>
              <thead>
                <tr>
                  <th style="width: 10%;max-width: 60px;">TOTAL:</th>
                  <th style="width: 100%;"> </th>
                  <th style="width:20%;min-width: 140px;">Lucro: R$: <?php echo $dadosAtivos['clientesrenovados_lista_valor']; ?></th>
                  <th style="width:20%;min-width: 110px;">Faturamento: R$: <?php echo $dadosAtivos['clientesrenovados_lista_valor_total']; ?></th>
                </tr>
              </thead>
          </table>
          </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal master -->
<!-- Define dados para o gráfico e importa Chart.js
     O código a seguir é carregado somente quando o usuário é administrador.
     Dessa forma, evitamos carregar Chart.js desnecessariamente e prevenimos
     erros de script em páginas de revendedores/usuários comuns. -->
<?php if (isset($_SESSION['nivel_admin']) && $_SESSION['nivel_admin'] == 1): ?>
<script>
window.statsData = {
  labels: ['Canais', 'Filmes', 'Séries', 'Episódios'],
  values: [
    <?php echo isset($conteudos['TotalLiveStreams']) ? $conteudos['TotalLiveStreams'] : 0; ?>,
    <?php echo isset($conteudos['TotalMovieStreams']) ? $conteudos['TotalMovieStreams'] : 0; ?>,
    <?php echo isset($conteudos['TotalSeries']) ? $conteudos['TotalSeries'] : 0; ?>,
    <?php echo isset($conteudos['TotalEpisodes']) ? $conteudos['TotalEpisodes'] : 0; ?>
  ]
};
</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="js/chart-config.js"></script>
<?php endif; ?>
<div class="modal fade" id="modal_master" tabindex="-1" aria-labelledby="modal_master" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="d-block modal-header" id="modal_master-header">
        <h5 class="float-start modal-title" id="modal_master-titulo"></h5>
        <button type="button" class="fa btn text-white fa-close fs-6 float-end" data-bs-dismiss="modal" aria-label="Close"></button>
        </button>
      </div>
      <form id="modal_master_form" onsubmit="event.preventDefault();" autocomplete="off">
        <div id="modal_master-body" class="modal-body overflow-auto" style="max-height: 421px;"></div>
        <div id="modal_master-footer" class="modal-footer"></div>
      </form>
    </div>
  </div>
</div>
<!-- Modal master Fim-->
<app-footer><hr class="border-1 border-secondary border-top mb-4 mt-4">
<div class="container-fluid"><div class="row pt-4"><div class="col-md-12 text-center mb-2"><small> © <?php echo date("Y"); ?> Feito Com <i aria-hidden="true" class="fa fa-heart text-danger"></i> por <span class="text-secondary font-weight-bold">Furia</span></small></div><div class="col-md-12 text-center mb-3"><a class="bg-light btn-sm m-2 shadow-sm text-dark" target="_blank"><i class="fa-telegram-plane fab"></i></a></div></div></div></app-footer>

<!-- Script para atualizar a lista de usuários online em tempo real -->
<script>
  /**
   * Requisita a lista de usuários online e atualiza a contagem e as listas
   * de clientes online e testes online no dashboard.  A função utiliza
   * fetch() para chamar o endpoint api/online.php e substitui o conteúdo
   * dos elementos apropriados.  É executada inicialmente na carga da
   * página e a cada 60 segundos.
   */
  function updateOnline() {
    fetch('api/online.php', { method: 'GET' })
      .then(function(resp) { return resp.json(); })
      .then(function(data) {
        // Atualiza os contadores de usuários e testes online
        var counters = document.querySelectorAll('h4.j_content_online_users');
        if (counters.length > 0) {
          counters[0].innerText = data.usuarios_online || 0;
          if (counters.length > 1) {
            counters[1].innerText = data.testes_online || 0;
          }
        }
        // Atualiza as listas de clientes online (não trial) e testes online (trial)
        var lists = document.querySelectorAll('div.listaClientesOnline');
        if (lists.length > 0 && data.lista) {
          // Constrói HTML para clientes (is_trial === 0)
          var htmlClientes = '';
          data.lista.forEach(function(item) {
            if (parseInt(item.is_trial) === 0) {
              htmlClientes += '<div>' + item.usuario + '</div>';
            }
          });
          htmlClientes += '<div class="text-center mt-2"><button type="button" class="btn btn-outline-primary btn-sm" onclick="modal_master(\'api/clientes_online.php\',\'detalhes_online\',\'1\')">Detalhes</button></div>';
          lists[0].innerHTML = htmlClientes;
          // Constrói HTML para testes online (is_trial === 1)
          if (lists.length > 1) {
            var htmlTestes = '';
            data.lista.forEach(function(item) {
              if (parseInt(item.is_trial) === 1) {
                htmlTestes += '<div>' + item.usuario + '</div>';
              }
            });
            htmlTestes += '<div class="text-center mt-2"><button type="button" class="btn btn-outline-primary btn-sm" onclick="modal_master(\'api/clientes_online.php\',\'detalhes_online\',\'1\')">Detalhes</button></div>';
            lists[1].innerHTML = htmlTestes;
          }
        }
      })
      .catch(function(err) {
        console.error('Erro ao atualizar usuários online:', err);
      });
  }
  // Atualiza ao carregar a página
  document.addEventListener('DOMContentLoaded', updateOnline);
  // Atualiza a cada 60 segundos (60000 ms)
  setInterval(updateOnline, 60000);
</script>

<!-- Script para limpar testes expirados via AJAX -->
<script>
document.addEventListener('DOMContentLoaded', function () {
  var btnLimpar = document.getElementById('btnLimparTestes');
  if (btnLimpar) {
    btnLimpar.addEventListener('click', function () {
      Swal.fire({
        title: 'Limpar Testes Expirados?',
        text: 'Essa ação removerá todos os testes vencidos. Deseja prosseguir?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sim, limpar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          fetch('api/limpar-testes.php', { method: 'POST' })
            .then(function (resp) { return resp.json(); })
            .then(function (json) {
              if (json && json.title && json.msg && json.icon) {
                Swal.fire(json.title, json.msg, json.icon);
              } else {
                Swal.fire('Erro!', 'Resposta inesperada do servidor.', 'error');
              }
              // Atualiza contadores e recarrega tabela de testes, se existir
              updateOnline();
              if (typeof reloadTestesTable === 'function') reloadTestesTable();
            })
            .catch(function (err) {
              Swal.fire('Erro!', 'Falha ao limpar testes expirados.', 'error');
              console.error(err);
            });
        }
      });
    });
  }
});
</script>

<!-- Variável contendo a lista de revendedores para compor o seletor de destinatários no envio de mensagens -->
<?php if (isset($_SESSION['nivel_admin']) && (int)$_SESSION['nivel_admin'] === 1): ?>
<script>
// Lista de revendedores carregada do PHP.  Cada elemento possui os campos
// `id` e `user`. Esta variável é utilizada para gerar dinamicamente o
// seletor de destinatários na janela de envio de mensagens.
var listaRevendedores = <?php echo json_encode($revendedores, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;

document.addEventListener('DOMContentLoaded', function () {
  var btnEnviar = document.getElementById('btnEnviarMensagem');
  if (btnEnviar) {
    btnEnviar.addEventListener('click', function () {
      // Constrói o campo de seleção de destinatário
      var selectHTML = '<select id="destinoMsg" class="form-select mb-2">';
      selectHTML += '<option value="todos">Todos os Revendedores</option>';
      if (Array.isArray(listaRevendedores)) {
        listaRevendedores.forEach(function (item) {
          // Escapamos o nome do usuário apenas por segurança
          var user = item.user ? String(item.user) : '';
          selectHTML += '<option value="' + item.id + '">' + user + '</option>';
        });
      }
      selectHTML += '</select>';
      Swal.fire({
        title: 'Enviar Mensagem',
        html: selectHTML +
          '<input id="tituloMsg" class="swal2-input" placeholder="Título da mensagem">' +
          '<textarea id="mensagemMsg" class="swal2-textarea" placeholder="Mensagem"></textarea>',
        showCancelButton: true,
        confirmButtonText: 'Enviar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
          const destino = document.getElementById('destinoMsg').value;
          const titulo = document.getElementById('tituloMsg').value.trim();
          const mensagem = document.getElementById('mensagemMsg').value.trim();
          if (!titulo || !mensagem) {
            Swal.showValidationMessage('Preencha o título e a mensagem para continuar.');
            return false;
          }
          return { destino: destino, titulo: titulo, mensagem: mensagem };
        }
      }).then((result) => {
        if (result.isConfirmed) {
          fetch('api/mensagens.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'enviar',
              destino: result.value.destino,
              titulo: result.value.titulo,
              mensagem: result.value.mensagem
            })
          })
            .then(function (resp) { return resp.json(); })
            .then(function (json) {
              if (json && json.title && json.msg && json.icon) {
                Swal.fire(json.title, json.msg, json.icon);
              } else {
                Swal.fire('Erro', 'Resposta inesperada do servidor ao enviar mensagem.', 'error');
              }
            })
            .catch(function (err) {
              console.error(err);
              Swal.fire('Erro', 'Falha ao enviar mensagem.', 'error');
            });
        }
      });
    });
  }
});
</script>
<?php endif; ?>

