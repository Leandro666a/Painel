$(document).ready(function() {
    var table = $('#data_table').DataTable({
        ajax: './api/listar-clientes.php?listar_clientes',
        processing: true,
        serverSide: true,
        language: {
        url: './js/datatables/pt_br.json'
    },
    layout: {
        topStart: null,
        bottom: 'paging',
        bottomStart: "info",
        bottomEnd: null
    },
        columns: [
            {
                data: "id",
                className: "text-center"
            }, // ID
            {
                data: "name",
                className: "text-center"
            }, // URL
            {
                orderable: false,
                data: "usuario",
                className: "text-center"
            },
            {
                orderable: false,
                data: "indicados",
                className: "text-center"
            },
            {
                data: "status",
                className: "text-center"
            },
            {
                data: "vencimento",
                className: "text-center"
            },
            {
                orderable: false,
                data: "acao",
                className: "text-center acao"
            }, // Logo URL
            
        ],
    order: [[0, 'asc']]
    });
    $('#clienteModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget); // Botão que acionou o modal
        if (!button || button.length === 0) return;
        const id = button.data('id');
        const usuario = button.data('usuario');
        const bloqueado = button.data('bloqueado');
        const modoAleatorio = button.data('modo-aleatorio');
        const $modal = $(this);
        $modal.attr('data-id', id);
        $modal.attr('data-usuario', usuario);
        $modal.attr('data-bloqueado', bloqueado);
        $modal.attr('data-modo-aleatorio', modoAleatorio);
        const $btnModo = $('#btnModoAleatorio');
        if (modoAleatorio == 1) {
            $btnModo.html('<i class="fa fa-random"></i> Desativar Aleatório');
        } else {
            $btnModo.html('<i class="fa fa-random"></i> Ativar Aleatório');
        }
        const $dialog = $modal.find('.modal-dialog');
        $dialog.removeClass('modal-fullscreen');
    });
    $('#btnTela').on('click', function () {
        const id = $('#clienteModal').attr('data-id');
        const usuario = $('#clienteModal').attr('data-usuario');
        $('#clienteModal').modal('hide');
        modal_master('api/clientes.php', 'mais_telas_cliente', id, 'usuario', usuario, 'dummy', '');
    });
    $('#btnLinks').on('click', function () {
        const id = $('#clienteModal').attr('data-id');
        if (!id) return;
        $('#clienteModal').modal('hide');
        modal_master('api/clientes.php', 'info_links', id);
    });
    $('#btnEditarData').on('click', function () {
        const id = $('#clienteModal').attr('data-id');
        if (!id) return;
        Swal.fire({
            title: 'Editar Data de Vencimento',
            html: '<label>Selecione nova data e hora:</label><input id="novaDataInput" type="datetime-local" class="swal2-input" value="">',
            showCancelButton: true,
            confirmButtonText: 'Salvar',
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                const novaData = document.getElementById('novaDataInput').value;
                if (!novaData) {
                    Swal.showValidationMessage('Informe uma data e hora válidas');
                    return false;
                }
                return novaData;
            }
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                const isoString = result.value;
                const formatted = isoString.replace('T', ' ') + ':00';
                $.ajax({
                    type: 'POST',
                    url: 'api/clientes.php',
                    data: {
                        update_vencimento_cliente: id,
                        nova_data: formatted
                    },
                    success: function (resp) {
                        let json;
                        try {
                            json = typeof resp === 'object' ? resp : JSON.parse(resp);
                        } catch (e) {
                            json = { title: 'Erro!', msg: 'Erro ao processar resposta.', icon: 'error' };
                        }
                        if (json.title && json.msg && json.icon) {
                            Swal.fire(json.title, json.msg, json.icon);
                        }
                        const dt = $('#data_table').DataTable();
                        dt.ajax.reload(null, false);
                    },
                    error: function () {
                        Swal.fire('Erro!', 'Erro ao atualizar data.', 'error');
                    }
                });
            }
        });
    });
    $('#btnModoAleatorio').on('click', function () {
        const id = $('#clienteModal').attr('data-id');
        let modoAtual = parseInt($('#clienteModal').attr('data-modo-aleatorio'), 10) || 0;
        $.ajax({
            type: 'POST',
            url: 'api/clientes.php',
            data: { toggle_modo_aleatorio_cliente: id },
            success: function (response) {
                let json;
                try {
                    json = typeof response === 'object' ? response : JSON.parse(response);
                } catch (e) {
                    json = { title: 'Erro!', msg: 'Erro ao processar a resposta.', icon: 'error' };
                }
                if (json.title && json.msg && json.icon) {
                    Swal.fire(json.title, json.msg, json.icon);
                }
                modoAtual = modoAtual === 1 ? 0 : 1;
                $('#clienteModal').attr('data-modo-aleatorio', modoAtual);
                const $btnModo = $('#btnModoAleatorio');
                if (modoAtual === 1) {
                    $btnModo.html('<i class="fa fa-random"></i> Desativar Aleatório');
                } else {
                    $btnModo.html('<i class="fa fa-random"></i> Ativar Aleatório');
                }
                if (modoAtual === 1) {
                    $.ajax({
                        type: 'POST',
                        url: 'api/clientes.php',
                        data: { unificar_categorias_cliente: id },
                        success: function (resp2) {
                            let respJson;
                            try {
                                respJson = typeof resp2 === 'object' ? resp2 : JSON.parse(resp2);
                            } catch (e) {
                                respJson = { title: 'Erro!', msg: 'Erro ao processar a resposta da unificação.', icon: 'error' };
                            }
                            if (respJson.title && respJson.msg && respJson.icon) {
                                Swal.fire(respJson.title, respJson.msg, respJson.icon);
                            }
                            const dt2 = $('#data_table').DataTable();
                            dt2.ajax.reload(null, false);
                        },
                        error: function () {
                            Swal.fire('Erro!', 'Erro ao unificar categorias.', 'error');
                        }
                    });
                } else {
                    const dt = $('#data_table').DataTable();
                    dt.ajax.reload(null, false);
                }
            },
            error: function () {
                Swal.fire('Erro!', 'Erro ao alternar modo aleatório.', 'error');
            }
        });
    });
    $('#btnMigrarClientes').on('click', function () {
        modal_master('api/clientes.php', 'migrar_clientes', '');
    });
    $(document).on('click', '.acao-renovar', function(e) {
        e.preventDefault();
        SweetAlert3('Renovado com sucesso', 'success');
    });
    $(document).on('click', '.acao-bloquear', function(e) {
        e.preventDefault();
        SweetAlert3('Bloqueado com sucesso', 'success');
    });
    $(document).on('click', '.acao-tela', function(e) {
        e.preventDefault();
        const idCliente = $(this).data('id');
        let options = '';
        for (let i = 1; i <= 10; i++) {
            options += `<option value="${i}">${i}</option>`;
        }
        Swal.fire({
            title: 'Gerenciar Telas',
            html: `<label class="d-block mb-2">Selecione a tela:</label><select id="selectTela" class="swal2-select form-select">${options}</select>`,
            showCancelButton: true,
            confirmButtonText: 'Adicionar',
            showDenyButton: true,
            denyButtonText: 'Remover',
            cancelButtonText: 'Cancelar',
            focusConfirm: false,
        }).then((result) => {
            if (result.isConfirmed) {
                const tela = document.getElementById('selectTela').value;
                SweetAlert3('Tela adicionada com sucesso', 'success');
            } else if (result.isDenied) {
                const tela = document.getElementById('selectTela').value;
                SweetAlert3('Tela removida com sucesso', 'success');
            }
        });
    });
    $(document).on('click', '.toggle-block', function (e) {
        e.preventDefault();
        const $button = $(this);
        const id = $button.data('id');
        $.ajax({
            type: 'POST',
            url: 'api/clientes.php',
            data: { toggle_bloqueado_cliente: id },
            success: function (response) {
                let json;
                try {
                    json = typeof response === 'object' ? response : JSON.parse(response);
                } catch (e) {
                    json = { title: 'Erro!', msg: 'Erro ao processar a resposta.', icon: 'error' };
                }
                if (json.title && json.msg && json.icon) {
                    Swal.fire(json.title, json.msg, json.icon);
                }
                const isBloq = $button.data('bloqueado') == 1;
                const novoBloq = isBloq ? 0 : 1;
                $button.data('bloqueado', novoBloq);
                $button.attr('title', novoBloq ? 'Desbloquear' : 'Bloquear');
                $button.find('i').toggleClass('fa-lock fa-unlock');
                const dt = $('#data_table').DataTable();
                dt.ajax.reload(null, false);
            },
            error: function () {
                Swal.fire('Erro!', 'Erro ao alternar bloqueio.', 'error');
            }
        });
    });
    $(document).on('click', '.editar-cliente', function (e) {
        e.preventDefault();
        const id = $(this).data('id');
        modal_master('api/clientes.php', 'edite_cliente', id);
    });
    $(document).on('click', '.excluir-cliente', function (e) {
        e.preventDefault();
        const $button = $(this);
        const id = $button.data('id');
        const usuario = $button.data('usuario');
        Swal.fire({
            title: 'Tem certeza?',
            text: 'Deseja excluir este cliente? Esta ação é irreversível.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sim, excluir',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: 'POST',
                    url: 'api/clientes.php',
                    data: { confirme_delete_cliente: id, usuario: usuario },
                    success: function (response) {
                        let json;
                        try {
                            json = typeof response === 'object' ? response : JSON.parse(response);
                        } catch (e) {
                            json = { title: 'Erro!', msg: 'Erro ao processar a resposta.', icon: 'error' };
                        }
                        if (json.title && json.msg && json.icon) {
                            Swal.fire(json.title, json.msg, json.icon);
                        }
                        const dt = $('#data_table').DataTable();
                        dt.ajax.reload(null, false);
                    },
                    error: function () {
                        Swal.fire('Erro!', 'Erro ao excluir cliente.', 'error');
                    }
                });
            }
        });
    });
  });