document.addEventListener('DOMContentLoaded', function () {
  const canvas = document.getElementById('statsChart');
  if (!canvas || !window.statsData) return;
  const ctx = canvas.getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: window.statsData.labels,
      datasets: [
        {
          label: 'Total',
          data: window.statsData.values,
          backgroundColor: 'rgba(99, 102, 241, 0.5)',
          borderColor: 'rgba(99, 102, 241, 1)',
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
});