$(document).ready(function() {
    var table = $('#data_table').DataTable({
        ajax: './api/listar-clientes.php?listar_series',
        processing: true,
        serverSide: true,
        language: {
        url: './js/datatables/pt_br.json'
    },
    layout: {
        topStart: null,
        bottom: 'paging',
        bottomStart: "info",
        bottomEnd: null
    },
        columns: [
            {
                data: "id",
                className: "text-center"
            }, // ID
            {
                data: "name",
                className: "text-center"
            }, // URL
            {
                orderable: false,
                data: "usuario",
                className: "text-center"
            },
            {
                orderable: false,
                data: "indicados",
                className: "text-center"
            },
            {
                data: "status",
                className: "text-center"
            },
            {
                data: "vencimento",
                className: "text-center"
            },
            {
                orderable: false,
                data: "acao",
                className: "text-center acao"
            }, // Logo URL
            
        ],
    order: [[0, 'asc']]
    });
  });