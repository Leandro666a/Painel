<?php
header("Content-Type: text/html; charset=UTF-8");
header("Cache-Control: no-store, no-cache, must-revalidate");

require_once "./api/controles/db.php";
// Importa funções auxiliares, incluindo registrar_conexao().
require_once __DIR__ . '/functions.php';
function processarUrl($url)
{
    $parsedUrl = parse_url($url);

    $path = $parsedUrl["path"];

    $pathParts = explode("/", trim($path, "/"));

    if (count($pathParts) >= 4) {
        $domain = $parsedUrl["host"];
        //$type = $pathParts[0];
        $usuario = $pathParts[1];
        $senha = $pathParts[2];
        $arquivo = pathinfo($pathParts[3], PATHINFO_FILENAME);
    } elseif (count($pathParts) <= 3) {
        $domain = $parsedUrl["host"];
        $usuario = $pathParts[0];
        $senha = $pathParts[1];
        $arquivo = pathinfo($pathParts[2], PATHINFO_FILENAME);
    } else {
        return false;
    }

    if (empty($arquivo) || !is_numeric($arquivo)) {
        return false;
    }

    return [
        "dominio" => $domain,
        "usuario" => $usuario,
        "senha" => $senha,
        "arquivo" => $arquivo,
    ];
}

function getHeadersAsJson($url)
{
    $options = [
        "http" => [
            "method" => "GET",
            "header" => "User-Agent: XCIPTV\r\n",
        ],
    ];

    $context = stream_context_create($options);

    $headers = @get_headers($url, 1, $context);

    if ($headers === false) {
        return json_encode(
            ["error" => "Não foi possível obter os cabeçalhos"],
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
        );
    }

    if (isset($headers["Location"])) {
        $locations = is_array($headers["Location"])
            ? $headers["Location"]
            : [$headers["Location"]];

        $urlsComToken = array_filter($locations, function ($location) {
            return strpos($location, "token=") !== false;
        });

        if (!empty($urlsComToken)) {
            return json_encode(
                ["URLsComToken" => array_values($urlsComToken)],
                JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
            );
        }

        return json_encode(
            ["Location" => $locations],
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
        );
    }

    return json_encode($headers, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}

$userAgent = $_SERVER["HTTP_USER_AGENT"];

$type_url = $_GET["type_url"] ?? "live";
$username = $_GET["usuario"] ?? null;
$password = $_GET["senha"] ?? null;
$arquivo = $_GET["arquivo"] ?? null;
$tempo = $_GET["tempo"] ?? null;

if ($arquivo) {
    $arquivo_sem_extensao = pathinfo($arquivo, PATHINFO_FILENAME);
    $extensao = pathinfo($arquivo, PATHINFO_EXTENSION);
}

if (!$username || !$password) {
    http_response_code(401);
    $errorResponse["user_info"] = [];
    $errorResponse["user_info"]["auth"] = 0;
    $errorResponse["user_info"]["msg"] = "username e password necessario!";
    echo json_encode($errorResponse);
    exit();
}

$conexao = conectar_bd();
$query = "SELECT *
                    FROM clientes
                    WHERE usuario = :username AND senha = :password";
$statement = $conexao->prepare($query);
$statement->bindValue(":username", $username);
$statement->bindValue(":password", $password);
$statement->execute();
$result = $statement->fetch(PDO::FETCH_ASSOC);
if (!$result) {
    http_response_code(401);
    $errorResponse = json_encode(["user_info" => ["auth" => 0]]);
    echo $errorResponse;
    exit();
}

// Verifica bloqueio do cliente e do revendedor antes de prosseguir.  Caso algum
// esteja bloqueado, o usuário será redirecionado para o vídeo de bloqueio.
// Também busca dados do revendedor para uso no modo aleatório.
$adminRow = null;
try {
    $clienteBloqueado = isset($result['bloqueado']) && (int)$result['bloqueado'] === 1;
    $adminBloqueado   = false;
    $stmt_admin       = $conexao->prepare('SELECT bloqueado, servidores, modo_aleatorio FROM admin WHERE id = :adminId');
    $stmt_admin->bindParam(':adminId', $result['admin_id']);
    $stmt_admin->execute();
    $adminRow = $stmt_admin->fetch(PDO::FETCH_ASSOC);
    if ($adminRow && isset($adminRow['bloqueado']) && (int)$adminRow['bloqueado'] === 1) {
        $adminBloqueado = true;
    }
    if ($clienteBloqueado || $adminBloqueado) {
        // Redireciona para um vídeo de bloqueio quando o acesso não é permitido
        $bloqueadoUrl = "http://" . $_SERVER["HTTP_HOST"] . "/video/block.mp4";
        header("Location: $bloqueadoUrl");
        exit();
    }
} catch (Exception $e) {
    // Em caso de erro ao verificar bloqueio, negar acesso por segurança
    $bloqueadoUrl = "http://" . $_SERVER["HTTP_HOST"] . "/video/block.mp4";
    header("Location: $bloqueadoUrl");
    exit();
}

$dataAtual = new DateTime();
if (new DateTime($result["Vencimento"]) < $dataAtual) {
    $vencido = "http://" . $_SERVER["HTTP_HOST"] . "/video/block.mp4";
    header("Location: $vencido");
    exit();
}

// Não aplicamos mais o controle de telas nesta etapa. O bloqueio por
// excesso de dispositivos é verificado apenas durante o login/geração
// da playlist via player_api/get.php. Aqui, prosseguimos sempre para
// registrar a atividade do usuário.

// Registra a atividade do usuário no sistema de conexões após todas as
// verificações de bloqueio e expiração.  Isso ajuda a manter a lista de
// usuários online atualizada no painel.
registrar_conexao($result['usuario']);

$query_streams = "SELECT * FROM streams WHERE id = :id";
$stmt_streams = $conexao->prepare($query_streams);
$stmt_streams->bindParam(":id", $arquivo_sem_extensao, PDO::PARAM_STR);
$stmt_streams->execute();
$resultado_streams = $stmt_streams->fetch(PDO::FETCH_ASSOC);

if (empty($resultado_streams)) {
    $vod_nao_encontrado =
        "http://" . $_SERVER["HTTP_HOST"] . "/video/vod_nao_encontrado.mp4";
    header("Location: $vod_nao_encontrado");
    exit();
}

$location = $resultado_streams["link"];
$tipo_link = $resultado_streams["tipo_link"];

// --------------------------------------------------------------------------
// Registra o último conteúdo assistido pelo usuário
//
// Para que o painel exiba o nome do canal ou programa em tempo real,
// registramos aqui o acesso à stream na tabela `ultimos_acessos`.  Não
// removemos entradas antigas; a função obter_detalhes_online() lê o mais
// recente.  O tipo é definido como "Ao Vivo" para canais de TV.
// --------------------------------------------------------------------------
try {
    $nomeConteudo = isset($resultado_streams['name']) ? $resultado_streams['name'] : null;
    $logoConteudo = isset($resultado_streams['stream_icon']) ? $resultado_streams['stream_icon'] : null;
    // Opcionalmente, podemos usar stream_type para diferenciar; mas os
    // canais são tratados como Ao Vivo.
    $tipoConteudo = 'Ao Vivo';
    registrar_ultimo_acesso($result['usuario'], $tipoConteudo, $nomeConteudo, $logoConteudo, 'assistindo');
} catch (Exception $e) {
    // falha silenciosa; não impede o redirecionamento
}


    // --------------------
    // MODO ALEATÓRIO: quando ativado para o cliente ou para o seu revendedor,
    // distribui as conexões de forma randômica entre os servidores definidos.
    // Os servidores podem ser definidos individualmente para o cliente via
    // clientes.servidores ou herdados do revendedor via admin.servidores.
    // Se nenhum servidor estiver configurado, nada é alterado.
    $domainOverride = null;
    try {
        $modoAleatorioAtivo = false;
        // Verifica a flag de modo aleatório no cliente
        if (isset($result['modo_aleatorio']) && (int)$result['modo_aleatorio'] === 1) {
            $modoAleatorioAtivo = true;
        }
        // Verifica a flag de modo aleatório no revendedor, caso exista
        if (!$modoAleatorioAtivo && $adminRow && isset($adminRow['modo_aleatorio']) && (int)$adminRow['modo_aleatorio'] === 1) {
            $modoAleatorioAtivo = true;
        }
        if ($modoAleatorioAtivo) {
            $listaServidores = [];
            // Primeiro, verifica se o canal possui uma lista de servidores extras definida no campo custom_sid.
            if (!empty($resultado_streams['custom_sid'])) {
                $linhas = preg_split('/\r?\n/', $resultado_streams['custom_sid']);
                foreach ($linhas as $linha) {
                    $linha = trim($linha);
                    if ($linha === '') {
                        continue;
                    }
                    // Tenta extrair o host da URL (caso fornecida com protocolo)
                    $host = parse_url($linha, PHP_URL_HOST);
                    if ($host) {
                        $listaServidores[] = $host;
                    } else {
                        // Remove eventual protocolo e caminho e usa o valor como domínio
                        $dom = preg_replace('#^https?://#i', '', $linha);
                        $dom = explode('/', $dom)[0];
                        if ($dom) {
                            $listaServidores[] = $dom;
                        }
                    }
                }
            }
            // Caso o canal não tenha servidores extras, utiliza a lista de servidores do cliente
            if (empty($listaServidores) && !empty($result['servidores'])) {
                $listaServidores = array_filter(array_map('trim', explode(',', $result['servidores'])));
            }
            // Se ainda estiver vazia, utiliza a lista do revendedor
            if (empty($listaServidores) && $adminRow && !empty($adminRow['servidores'])) {
                $listaServidores = array_filter(array_map('trim', explode(',', $adminRow['servidores'])));
            }
            // Escolhe aleatoriamente um servidor da lista
            if (!empty($listaServidores)) {
                $escolhido = $listaServidores[array_rand($listaServidores)];
                // Remove protocolo se estiver incluso (ex.: http://) e deixa apenas o domínio
                $escolhido = preg_replace('#^https?://#i', '', $escolhido);
                // Caso a entrada tenha caminho, pega apenas o domínio
                $escolhido = explode('/', $escolhido)[0];
                $domainOverride = $escolhido;
            }
        }
    } catch (Exception $e) {
        // ignora falhas e segue com $domainOverride = null
    }

if ($tipo_link == "link_direto") {
    header("Location: " . $location);
    exit();
}

$dados = @processarUrl($location);

if ($location && $dados && $tipo_link !== "link_direto2") {
    // Se o modo aleatório estiver ativado e $domainOverride estiver definido,
    // substituímos o domínio original por um dos servidores selecionados.
    $domainForUrl = isset($domainOverride) && $domainOverride ? $domainOverride : $dados["dominio"];
    $url = "http://{$domainForUrl}/{$type_url}/{$dados["usuario"]}/{$dados["senha"]}/{$dados["arquivo"]}.$extensao";

    if ($tipo_link == "padrao2") {
        header("Location: " . $location);
        exit();
    }

    $location2 = json_decode(getHeadersAsJson($url), true);
    if ($location2) {
        if (isset($location2["location"])) {
            header("url: 1 location");
            if (is_array($location2["location"])) {
                //echo "link location: " . $location2["location"][0];
                header("Location: " . $location2["location"][0]);
            } else {
                //echo "link location: " . $location2["location"];
                header("Location: " . $location2["location"]);
            }

            exit();
        }
        if (isset($location2["URLsComToken"])) {
            header("url: 2 URLsComToken");

            if (is_array($location2["URLsComToken"])) {
                //echo "link location: " . $location2["URLsComToken"][0];
                header("Location: " . $location2["URLsComToken"][0]);
                exit();
            } else {
                echo "link location 2: " . $location2["URLsComToken"];
                header("Location: " . $location2["URLsComToken"]);
            }
        }
    }

    header("url: 3 link original");
    //echo "link 2: " . $url;
    header("Location: $url");
    exit();
}

$location3 = json_decode(getHeadersAsJson($location), true);

if ($location3) {
    if (isset($location3["location"])) {
        header("url: 1 link direto location");
        if (is_array($location3["location"])) {
            //echo "link location: " . $location3["location"][0];
            header("Location: " . $location3["location"][0]);
        } else {
            //echo "link location: " . $location3["location"];
            header("Location: " . $location3["location"]);
        }

        exit();
    }
    if (isset($location3["URLsComToken"])) {
        header("url: 2 link direto URLsComToken");

        if (is_array($location3["URLsComToken"])) {
            //echo "link location: " . $location3["URLsComToken"][0];
            header("Location: " . $location3["URLsComToken"][0]);
            exit();
        } else {
            //echo "link location 2: " . $location3["URLsComToken"];
            header("Location: " . $location3["URLsComToken"]);
        }
    }

    //echo "link 1: " . $location3;
}
header("url: 3 link direto original");
//echo "link 4: " . $location;
header("Location: $location");
exit();
