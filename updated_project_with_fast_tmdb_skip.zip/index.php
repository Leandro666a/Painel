<!DOCTYPE html>
<html lang="pt-br" data-theme="light">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="UltraVision Pro" name="author">
  <!-- Título da página ajustado para a nova marca -->
  <title>Login | UltraVision Pro</title>
  <!-- Ícone da aplicação -->
  <link rel="shortcut icon" href="./img/icon.png">
  <!-- Bootstrap CSS -->
  <link href="//cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- Tema moderno que define variáveis de cor para o painel -->
  <link rel="stylesheet" type="text/css" href="css/modern.css">
  <!-- Font Awesome (updated to latest 6.5.1) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <!-- Inter font for modern typography -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <!-- Modern UltraVision styles: loaded last to override previous themes -->
  <link rel="stylesheet" type="text/css" href="css/ultravision-modern.css">
  <!-- Custom framework variables and overrides -->
  <link rel="stylesheet" type="text/css" href="css/framework-custom.css">
  <!-- Animate.css for simple entrance animations -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <!-- jQuery -->
  <script src="//cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
  <!-- Efeito fade-in para a seção de login -->
  <style>
    .fade-in {
      opacity: 0;
      animation: fadeIn 1s ease 0.3s forwards;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<!--
  A página de login foi redesenhada com uma estética moderna baseada no tema do painel.
  A cor de fundo herda de --body-bg definida em css/modern.css, com um fallback
  escuro (#121212) caso a variável não esteja disponível.  A seção de login
  utiliza um cartão translúcido com efeito de desfoque (glassmorphism) para
  destacar o formulário sobre o fundo.  As cores foram ajustadas para garantir
  contraste e legibilidade em temas claros ou escuros.
-->
<body style="background-color: var(--body-bg, #121212); color: var(--text-color, #f5f6fa);">
  <section class="auth-bg-cover min-vh-100 p-4 d-flex align-items-center justify-content-center fade-in"
    style="background-color: rgba(24, 29, 48, 0.85); backdrop-filter: blur(8px); border-radius: 1rem;">
    <div class="container-fluid px-0">
      <div class="g-0 row">
        <div class="col-lg-12 col-xl-12">
          <div class="d-flex flex-column flex-lg-wrap-reverse h-100 justify-content-between mb-0 p-4">
            <!-- Formulário de login -->
            <div class="col-xl-4 col-lg-6">
              <div class="card mb-0" style="background-color: var(--card-bg, rgba(36, 41, 61, 0.95)); border: none; box-shadow: 0 0 15px rgba(0,0,0,0.5); color: var(--text-color, #f5f6fa);">
                <div class="card-body p-4 p-sm-5 m-lg-2">
                  <!-- Logomarca completa -->
                  <div class="text-center mt-2" style="width: 100%;">
                    <img src="./img/ultravision_logo_full.png" alt="UltraVision Pro" class="img-fluid mb-3" style="max-width: 100%; height: auto;">
                  </div>
                  <div class="p-2 mt-5">
                    <form id="login_form" onsubmit="event.preventDefault();">
                      <div class="mb-3">
                        <input name="login" type="hidden" id="login">
                        <label for="username" class="form-label fw-bold" style="color: #f5f6fa;">Usuário</label>
                        <input name="username" type="text" class="form-control" id="username" placeholder="Coloque o usuário"
                               style="background-color: rgba(52, 58, 86, 0.8); border: none; color: var(--text-color, #f5f6fa);">
                      </div>
                      <div class="mb-3">
                        <label class="form-label fw-bold" for="password-input" style="color: #f5f6fa;">Senha</label>
                        <div class="position-relative auth-pass-inputgroup mb-3">
                          <input name="password" type="password" class="form-control pe-5 password-input" placeholder="******" id="password-input"
                                 style="background-color: rgba(52, 58, 86, 0.8); border: none; color: var(--text-color, #f5f6fa);">
                          <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none" type="button" id="password-addon" style="color: #adb5bd;">
                            <i class="ri-eye-fill align-middle"></i>
                          </button>
                        </div>
                      </div>
                      <div class="mt-4 text-center">
                        <button type="submit" onclick="enviardados('login_form')" class="btn"
                                style="background-color: var(--primary-color, #5c6bc0); color: #fff; border: none; width: 100%;">Entrar</button>
                      </div>
                    </form>
                    <div class="text-center mt-5"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Rodapé personalizado -->
        <footer class="bg-gradient pt-5">
          <div class="container text-center">
            <div class="row justify-content-center">
              <div class="col-lg-8">
                <div class="d-flex flex-column align-items-center">
                  <img src="./img/ultravision_logo.png" alt="UltraVision Pro" height="50" class="mb-2">
                  <h4 class="text-uppercase text-white mb-3" style="letter-spacing: 1px;">UltraVision Pro</h4>
                  <p class="text-white-50 mb-2">A melhor experiência IPTV para você.</p>
                  <div class="social d-flex justify-content-center mb-3">
                    <a href="#" class="fs-2 mx-2 text-primary" title="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="fs-2 mx-2 text-info" title="Telegram"><i class="fab fa-telegram"></i></a>
                    <a href="#" class="fs-2 mx-2 text-danger" title="YouTube"><i class="fab fa-youtube"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <div class="copyright-area my-4">
              <p class="py-3 text-center text-white" style="border-top: 1px solid #192129;">
                © <?php echo date("Y"); ?> UltraVision Pro. Todos os direitos reservados.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  </section>
  <script src="./js/sweetalert2.js"></script>
  <script>
  // Lógica de envio de dados para login.  Faz uma solicitação assíncrona
  // ao arquivo api/login.php e exibe notificações de sucesso ou erro.
  var solicitacaoPendente = false;
  function enviardados(id_formulario) {
      if (solicitacaoPendente) {
          SweetAlert2('Aguarde!', 'warning');
          setTimeout(function() {
                  solicitacaoPendente = false;
              }, 3000);
          return;
      }
      solicitacaoPendente = false;
      var dados = $("#" + id_formulario).serialize();
      $.ajax({
          type: "GET",
          url: "./api/login.php",
          data: dados,
          success: function(response) {
              if (response.trim() === '') {
                  SweetAlert2('Resposta do servidor vazia.', 'error');
              } else {
                  var jsonResponse = JSON.parse(response);
                  if (jsonResponse.icon === 'error') {
                      SweetAlert2(jsonResponse.title, jsonResponse.icon);
                  } else {
                      SweetAlert2(jsonResponse.title, jsonResponse.icon);
                      if (jsonResponse.url) {
                        setTimeout(function() {
                          window.location.href = jsonResponse.url;
                        }, parseInt(jsonResponse.time, 10));
                      }
                  }
              }
            },
          error: function(data) {
              SweetAlert2('Erro na solicitaçao!', 'error');
          },
          complete: function() {
              solicitacaoPendente = false;
          }
      });
  }
  // Notificação toast simples usando SweetAlert2
  function SweetAlert2(title, icon){
      const Toast = Swal.mixin({
      toast: true,
      position: "top-end",
      showConfirmButton: false,
      timer: 2000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.onmouseenter = Swal.stopTimer;
        toast.onmouseleave = Swal.resumeTimer;
      }
    });
    Toast.fire({
      icon: icon,
      title: title
    });
  }
  </script>
  <!-- Inicia o controle de tema claro/escuro -->
  <script src="js/theme-toggle.js"></script>
</body>
</html>