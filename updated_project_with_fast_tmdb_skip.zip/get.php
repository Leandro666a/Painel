<?php
//ini_set('memory_limit', '512M'); // Aumenta para 512 MB

// Obtém os parâmetros da URL
$username = isset($_GET['username']) ? $_GET['username'] : null;
$password = isset($_GET['password']) ? $_GET['password'] : null;
$output = isset($_GET['output']) ? $_GET['output'] : "m3u8";

// Valida os parâmetros
if (empty($username) || empty($password)) {
    die("Username e password são obrigatórios.");
}

// Conecta-se ao banco de dados de usuários
require_once($_SERVER['DOCUMENT_ROOT'] . '/api/controles/db.php');
// Inclui funções auxiliares para registrar conexões
require_once(__DIR__ . '/functions.php');
$conexao = conectar_bd();
$query = "SELECT *
          FROM clientes
          WHERE usuario = :username AND senha = :password";
$statement = $conexao->prepare($query);
$statement->bindValue(':username', $username);
$statement->bindValue(':password', $password);
$statement->execute();
$result = $statement->fetch(PDO::FETCH_ASSOC);
if (!$result) {
    http_response_code(401); // 401 Unauthorized
    die("Username e password incorretos.");
}

// Verifica se o cliente ou seu revendedor estão bloqueados.  Caso algum esteja
// bloqueado, retorna 401 e interrompe a execução.  O cliente está bloqueado
// quando a coluna clientes.bloqueado = 1; o revendedor é verificado pela coluna
// admin.bloqueado baseada em clientes.admin_id.
try {
    $clienteBloqueado = isset($result['bloqueado']) && (int)$result['bloqueado'] === 1;
    $adminBloqueado   = false;
    if (!$clienteBloqueado) {
        $stmt_admin = $conexao->prepare('SELECT bloqueado FROM admin WHERE id = :adminId');
        $stmt_admin->bindParam(':adminId', $result['admin_id']);
        $stmt_admin->execute();
        $adminRow = $stmt_admin->fetch(PDO::FETCH_ASSOC);
        if ($adminRow && isset($adminRow['bloqueado']) && (int)$adminRow['bloqueado'] === 1) {
            $adminBloqueado = true;
        }
    }
    if ($clienteBloqueado || $adminBloqueado) {
        http_response_code(401);
        die("Usuário ou revendedor bloqueado. Consulte seu master.");
    }
} catch (Exception $e) {
    http_response_code(401);
    die("Erro ao verificar bloqueio de usuário.");
}

// Antes de prosseguir, verifica se a abertura de uma nova sessão seria
// permitida.  A função `verificar_sessao()` realiza a mesma checagem de
// limite de telas que `registrar_sessao()`, mas sem registrar uma nova
// sessão.  Se o usuário já estiver conectado em outro dispositivo e
// tiver apenas uma tela disponível, a geração da playlist é negada.
try {
    $limiteTelas = isset($result['conexoes_max']) ? (int) $result['conexoes_max'] : 1;
    if (!verificar_sessao($result['usuario'] ?? $username, $limiteTelas)) {
        http_response_code(401);
        die("Limite de conexões atingido.");
    }
} catch (Exception $e) {
    http_response_code(401);
    die("Erro ao verificar sessão.");
}
// Registra ou atualiza a sessão ativa para este dispositivo, mesmo que a
// playlist não consuma uma tela.  Dessa forma, mantemos um registro do
// aparelho autorizado, impedindo que outro dispositivo passe da tela de
// login quando houver apenas uma tela disponível.  Falhas nesta chamada
// não interrompem a geração da lista.
try {
    $telasMaxGet = isset($result['conexoes_max']) ? (int)$result['conexoes_max'] : 1;
    registrar_sessao($username, $telasMaxGet);
} catch (Exception $e) {
    // Falha silenciosa na gravação da sessão
}

// Em seguida registramos a conexão apenas para fins de monitoramento (clientes online).  A
// geração da playlist M3U/HLS não consome uma tela; o controle de telas
// permanece nas rotas de redirecionamento.  Falhas nessa gravação não
// impedem a entrega do arquivo.
try {
    registrar_conexao($username);
} catch (Exception $e) {
    // Falha silenciosa
}

if (isset($_GET['username']) && isset($_GET['password'])) {
    // Obtém o host atual
    $hostUrl = $_SERVER['HTTP_HOST'];

    // Define o arquivo temporário para o conteúdo M3U
    $tempFile = tempnam(sys_get_temp_dir(), 'playlist_') . '.m3u';

    // Abre o arquivo para escrita
    $fileHandle = fopen($tempFile, 'w');

    // Cabeçalho M3U
    fwrite($fileHandle, "#EXTM3U-1\n");

    // Geração de canais e filmes (streams)
    // Determina o tipo de conteúdo permitido para este usuário com base na coluna c_ocultar_fonte (filmes, series ou completo).
    $tipoConteudo = isset($result['c_ocultar_fonte']) ? strtolower($result['c_ocultar_fonte']) : 'completo';
    if ($tipoConteudo !== 'filmes' && $tipoConteudo !== 'series' && $tipoConteudo !== 'completo') {
        $tipoConteudo = 'completo';
    }

    $query = "
        SELECT s.id, s.name, s.stream_icon, s.category_id, s.stream_type, s.container_extension, c.nome AS category_name
        FROM streams s
        LEFT JOIN categoria c ON s.category_id = c.id
        WHERE s.stream_type IN ('live', 'movie')
    ";

    $stmt = $conexao->prepare($query);
    $stmt->execute();

    while ($stream = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Filtra conforme a seleção de conteúdo:
        // - filmes: apenas filmes (stream_type == 'movie')
        // - series: nenhum item desta lista (somente séries serão tratadas mais adiante)
        // - completo: inclui todos
        if ($tipoConteudo === 'filmes') {
            if ($stream['stream_type'] !== 'movie') {
                continue;
            }
        } elseif ($tipoConteudo === 'series') {
            // Não incluir filmes nem canais
            continue;
        }
        $epg_id = isset($stream['epg_channel_id']) ? htmlspecialchars($stream['epg_channel_id']) : '';
        $logo = isset($stream['stream_icon']) ? htmlspecialchars($stream['stream_icon']) : '';
        $line = "#EXTINF:-1 tvg-id=\"{$epg_id}\" tvg-name=\"{$epg_id}\" tvg-logo=\"{$logo}\" ";
        $line .= "group-title=\"" . htmlspecialchars($stream['category_name']) . "\",";
        $line .= htmlspecialchars($stream['name']) . "\n";
        if ($stream['stream_type'] === "live") {
            $line .= "http://$hostUrl:80/" . htmlspecialchars($stream['stream_type']) . "/$username/$password/" . $stream['id'] . ".".$output."\n";
        } else {
            $line .= "http://$hostUrl:80/" . htmlspecialchars($stream['stream_type']) . "/$username/$password/" . $stream['id'] . ".".$stream['container_extension']."\n";
        }
        fwrite($fileHandle, $line);
    }

    // Geração de séries, apenas se o tipo de conteúdo permitir (não quando selecionado apenas filmes)
    if ($tipoConteudo !== 'filmes') {
        $query = "
            SELECT e.id, e.series_id, e.title, e.container_extension, e.movie_image, s.name AS series_name, s.category_id, c.nome AS category_name
            FROM series_episodes e
            LEFT JOIN series s ON e.series_id = s.id
            LEFT JOIN categoria c ON s.category_id = c.id
        ";
        $stmt = $conexao->prepare($query);
        $stmt->execute();
        while ($episode = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Inclui séries somente quando o usuário escolhe 'series' ou 'completo'
            if ($tipoConteudo === 'series' || $tipoConteudo === 'completo') {
                $name = $episode['series_name'] . " - " . $episode['title'];
                $line = "#EXTINF:-1 tvg-id=\"\" tvg-name=\"" . htmlspecialchars($name) . "\" ";
                $line .= "tvg-logo=\"" . htmlspecialchars($episode['movie_image']) . "\" ";
                $line .= "group-title=\"" . htmlspecialchars((string) ($episode['category_name'] ?? '')) . "\",";
                $line .= htmlspecialchars($name) . "\n";
                $line .= "http://$hostUrl:80/series/$username/$password/" . $episode['id'] . "." . $episode['container_extension'] . "\n";
                fwrite($fileHandle, $line);
            }
        }
    }

    // Fecha o arquivo após escrever todo o conteúdo
    fclose($fileHandle);

    // Define os cabeçalhos para download do arquivo
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.$username.'.m3u"');
    header('Content-Length: ' . filesize($tempFile));

    // Lê o arquivo e envia para o cliente
    readfile($tempFile);

    // Remove o arquivo temporário
    unlink($tempFile);

    exit;
}
